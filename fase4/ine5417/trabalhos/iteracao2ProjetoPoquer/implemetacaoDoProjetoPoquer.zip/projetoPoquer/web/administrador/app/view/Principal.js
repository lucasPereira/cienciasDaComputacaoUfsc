Ext.define('PP.view.Principal', {
	extend: 'Ext.panel.Panel',
	alias: 'widget.principal',
	requires: [
		'PP.view.mantenedores.JanelaMantenedores',
	],
	autoShow: true,
	items: [
		{
			xtype: 'buttongroup',
			items: [
				{
					xtype: 'button',
					scale: 'medium',
					icon: 'recursos/imagens/bustoDePessoa.png',
					text: 'Mantenedores',
					listeners: {
						click: function() {
							Ext.widget('janelamantenedores');
						}
					}
				}
			]
		}
	]
});
