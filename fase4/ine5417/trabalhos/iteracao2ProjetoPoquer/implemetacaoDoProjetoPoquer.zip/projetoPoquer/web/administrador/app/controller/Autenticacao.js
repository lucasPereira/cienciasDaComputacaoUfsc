Ext.define('PP.controller.Autenticacao', {
	extend: 'Ext.app.Controller',
	views: [
		'acesso.Autenticacao',
		'Principal',
		'Viewport'
	],
	refs: [
		{
			ref: 'autenticacao',
			selector: 'autenticacao'
		},
		{
			ref: 'viewport',
			selector: 'viewport'
		}
	],
	
	init: function() {
		this.control({
			'autenticacao button[action=autenticar]': {
				click: this.autenticar
			}
		});
	},
	
	autenticar: function() {
		var formulário = this.getAutenticacao().down('form').getForm();
		var senha = formulário.getValues().senha;
		Ext.Ajax.request({
			scope: this,
			url: '../recursos/administrador/autenticacao',
			method: 'POST',
			jsonData: {
				senha: senha
			},
			successProperty: 'sucesso',
			success: function(respostaDeAutenticacao) {
				var respostaDeAutenticacaoJson = Ext.JSON.decode(respostaDeAutenticacao.responseText);
				if (respostaDeAutenticacaoJson.erro) {
					Ext.MessageBox.show({
						title: 'Autenticação não realizada',
						msg: 'Não foi possível realizar a autenticação. <br /><br />Motivo: '+respostaDeAutenticacaoJson.mensagemDeErro,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.WARNING
					});								
				} else {
					Ext.MessageBox.show({
						title: 'Autenticação realizada com sucesso',
						msg: 'Você já está autenticado no sistema, divirta-se.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO,
						modal: true
					});	
					PP.addStatics({
						senha: senha
					});
					this.getAutenticacao().destroy();
					this.getViewport().add(Ext.widget('principal'));
				}
			},
			failure: function() {
				Ext.MessageBox.show({
				   title: 'Autenticação não realizada',
				   msg: 'Houve um problema interno, por favor volte mais tarde.',
				   buttons: Ext.MessageBox.OK,
				   icon: Ext.MessageBox.ERROR
			   });
			}
		});
	}
});
