Ext.define('PP.model.Mantenedor', {
    extend: 'Ext.data.Model',
    fields: [
    	{
		    name: 'nomeDeMantenedor'
    	}, 
    	{
    		name: 'email'
    	},
    	{
    		name: 'senha'
    	}
    ]
});

