Ext.define('PP.controller.Mantenedores', {
	extend: 'Ext.app.Controller',
	stores: [
		'Mantenedores',
	],
	models: [
		'Mantenedor'
	],
	views: [
		'mantenedores.JanelaMantenedores',
		'mantenedores.ListaMantenedores',
		'mantenedores.CadastroMantenedor',
	],
	refs: [
		{
			ref: 'janelaMantenedores',
			selector: 'janelamantenedores'
		},
		{
			ref: 'listaMantenedores',
			selector: 'listamantenedores'
		},
		{
			ref: 'cadastroMantenedor',
			selector: 'cadastromantenedor'
		}
	],
	
	init: function() {
		this.control({
			'cadastromantenedor button[action=cadastrar]':
			{	
				click: this.cadastrarMantenedor
			},
			'listamantenedores button[action=removerMantenedor]':
			{	
				click: this.removerMantenedor
			},
		});
	},
	
	cadastrarMantenedor: function(botãoCadastrar) {
		var valores = botãoCadastrar.up('form').getForm().getValues();
		if (botãoCadastrar.up('form').getForm().isValid()) {
			Ext.Ajax.request({
				url: '../recursos/mantenedores/'+valores.nomeDeMantenedor,
				method: 'POST',
				jsonData: {
					nomeDeMantenedor: valores.nomeDeMantenedor,
					email: valores.email,
					senhaDoAdministrador: PP.senha
				},
				sucessProperty: 'sucesso', 
				scope: this,
				success: function(resposta) {
					var respostaJson = JSON.parse(resposta.responseText);
					if (respostaJson.sucesso) {
						Ext.MessageBox.show({
							title: 'Mantenedor cadastrado com sucesso',
							msg: 'O mantenedor foi cadastrado com sucesso. Foi enviado para o e-mail cadastrado do mantenedor uma mensagem informando seu nome de mantenedor e uma senha que foi gerada automaticamente.',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
					 	});
					 	this.getCadastroMantenedor().destroy();
					 	this.getMantenedoresStore().load();
					}
				},
				failure: function() {
					Ext.MessageBox.show({
						title: 'Problema Interno',
						msg: 'Houve um problema interno, por favor volte mais tarde.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.ERROR
					});
				}
		   });
		}
   },
   
   removerMantenedor: function() {
   		console.log('entrou');
    	var mantenedor = this.getListaMantenedores().getSelectionModel().getSelection()[0];
    	console.log(mantenedor);
    	if (mantenedor != undefined) {
		   	Ext.Ajax.request({
				url: '../recursos/mantenedores/'+mantenedor.get('nomeDeMantenedor'),
				method: 'DELETE',
				jsonData: {
					senhaDoAdministrador: PP.senha
				},
				sucessProperty: 'sucesso', 
				scope: this,
				success: function(resposta) {
					var respostaJson = JSON.parse(resposta.responseText);
					if (respostaJson.sucesso) {
						Ext.MessageBox.show({
							title: 'Conta removida',
							msg: 'A conta do mantenedor foi removida com sucesso.',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO,
							fn: this.irParaPaginaInicial,
							scope: this
					 	});
					 	this.getMantenedoresStore().load();
					}
				},
				failure: function() {
					Ext.MessageBox.show({
						title: 'Problema Interno',
						msg: 'Houve um problema interno, por favor volte mais tarde.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.ERROR
					});
				}
		   	});
		} else {
			Ext.MessageBox.show({
				title: 'Selecione um mantenedor',
				msg: 'Você deve selecionar um mantenedor.',
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.WARNING
			});
		}
   	}
});
