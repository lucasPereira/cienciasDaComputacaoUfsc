Ext.define('PP.store.Mantenedores', {
	extend: 'Ext.data.Store',
  	requires: [ 
  		'PP.model.Mantenedor' 
  	],
	model: 'PP.model.Mantenedor',
	autoLoad: true,
	autoSync: true,
	proxy: {
    	type: 'rest',
       	url: '../recursos/mantenedores',
        reader: {
            type: 'json',
            root: 'mantenedores'
        }
	}
});
