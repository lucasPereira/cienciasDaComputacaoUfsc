Ext.define('PP.view.mantenedores.JanelaMantenedores', {
	extend: 'PP.view.Janela',
	alias: 'widget.janelamantenedores',
	requires: [
		'PP.view.mantenedores.ListaMantenedores',
		'Ext.grid.Panel'
	],
	title: 'Mantenedores',
	layout: 'fit', 
	border: false,
	autoShow: true,
	items: [
		{
			xtype: 'listamantenedores'
		}	
	]
});
