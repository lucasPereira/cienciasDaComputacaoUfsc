Ext.define('PP.view.acesso.Autenticacao', {
	extend: 'Ext.window.Window',
	alias: 'widget.autenticacao',
	autoShow: true,
	title: 'Autenticação',
	closable: false,
    border: false,
    modal: true,
    bodyStyle:'margin: 0 0 10px 0',
	items: [
		{
			xtype: 'form',
			boder: false,
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'textfield',
					inputType: 'password',
					name: 'senha',
					fieldLabel: 'Senha',
					emptyText: 'Insira a senha do administrador'
				}
			],
			buttons: [
				{
					text: 'Acessar',
					action: 'autenticar'
				}
			]
		}
	]
});
