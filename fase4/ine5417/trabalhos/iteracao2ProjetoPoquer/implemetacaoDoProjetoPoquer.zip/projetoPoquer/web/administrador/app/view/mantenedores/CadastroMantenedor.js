Ext.define('PP.view.mantenedores.CadastroMantenedor', {
	extend: 'Ext.window.Window',
	alias: 'widget.cadastromantenedor',
	title: 'Cadastro De Mantenedor',
	autoShow: true,
    border: false,
    modal: true,
   	resizable: false,
    bodyStyle: 'margin: 0 0 10px 0',
    items: [
		{
			xtype: 'form',
			boder: false,
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'textfield',
					name: 'nomeDeMantenedor',
					fieldLabel: 'Nome De Mantenedor',
					emptyText: 'Digite um nome de mantenedor',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					name: 'email',
					fieldLabel: 'E-mail',
					emptyText: 'Insira o e-mail do mantenedor',
					allowBlank: false,
					vtype: 'email'
				}
			],
			buttons: [
				{
					text: 'Cadastrar',
					action: 'cadastrar'
				}
			]
		}    
    ]
});
