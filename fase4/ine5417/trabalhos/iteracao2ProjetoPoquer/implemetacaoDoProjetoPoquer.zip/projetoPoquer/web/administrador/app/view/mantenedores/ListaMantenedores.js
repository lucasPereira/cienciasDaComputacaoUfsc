Ext.define('PP.view.mantenedores.ListaMantenedores', {
	extend: 'Ext.grid.Panel',
	alias: 'widget.listamantenedores',
	requires: [
		'PP.view.mantenedores.CadastroMantenedor'
	],
	store: 'Mantenedores',
	boder: false,
	multiSelect: false,
	columns: [
		{
			header: 'Nome De Mantenedor',
			dataIndex: 'nomeDeMantenedor',
			flex: 1
		},
		{
			header: 'E-mail',
			dataIndex: 'email',
			flex: 1
		}
	],
	
	tbar: [
		{
			xtype: 'button',
			text: 'Adicionar',
			icon: 'recursos/imagens/adicionar.png',
			listeners: {
				click: function() {
					Ext.widget('cadastromantenedor');
				}
			}
		},
		{
			xtype: 'button',
			text: 'Remover',
			icon: 'recursos/imagens/remover.png',
			action: 'removerMantenedor'
		}
	]
});
