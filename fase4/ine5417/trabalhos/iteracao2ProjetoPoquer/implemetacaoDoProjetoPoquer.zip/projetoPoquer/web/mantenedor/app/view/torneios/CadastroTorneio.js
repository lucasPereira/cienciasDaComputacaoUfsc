Ext.define('PP.view.torneios.CadastroTorneio', {
	extend: 'Ext.window.Window',
	alias: 'widget.cadastrotorneio',
	title: 'Cadastro De Torneio',
	autoShow: true,
    border: false,
    modal: true,
   	resizable: false,
    bodyStyle: 'margin: 0 0 10px 0',
    items: [
		{
			xtype: 'form',
			boder: false,
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'textfield',
					name: 'descricao',
					fieldLabel: 'Descrição',
					emptyText: 'Digite uma descrição',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					name: 'vagas',
					fieldLabel: 'Quantidade de vagas',
					emptyText: 'Insira a quantidade de vagas',
					allowBlank: false,
				},
				{
					xtype: 'textfield',
					name: 'entrada',
					fieldLabel: 'Valor da entrada',
					emptyText: 'Insira o valor da entrada',
					allowBlank: false,
				}
			],
			buttons: [
				{
					text: 'Cadastrar',
					action: 'cadastrar'
				}
			]
		}    
    ]
});
