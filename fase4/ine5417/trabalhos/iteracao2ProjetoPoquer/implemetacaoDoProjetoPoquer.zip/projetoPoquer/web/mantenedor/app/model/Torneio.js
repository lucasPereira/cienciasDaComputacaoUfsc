Ext.define('PP.model.Torneio', {
    extend: 'Ext.data.Model',
    fields: [
    	{
		    name: 'identificador'
    	}, 
    	{
    		name: 'descricao'
    	},
    	{
    		name: 'vagas'
    	},
    	{
    		name: 'entrada'
    	},
    	{
    		name: 'mantenedorCriador'
    	}
    ]
});

