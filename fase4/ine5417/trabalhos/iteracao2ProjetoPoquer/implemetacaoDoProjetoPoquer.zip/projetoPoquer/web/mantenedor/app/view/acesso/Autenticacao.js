Ext.define('PP.view.acesso.Autenticacao', {
	extend: 'Ext.window.Window',
	alias: 'widget.autenticacao',
	autoShow: true,
	title: 'Autenticação',
	closable: false,
    border: false,
    modal: true,
    bodyStyle:'margin: 0 0 10px 0',
	items: [
		{
			xtype: 'form',
			boder: false,
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'textfield',
					inputType: 'text',
					name: 'nomeDeMantenedor',
					fieldLabel: 'Nome De Mantenedor',
					emptyText: 'Insira seu nome de mantenedor'
				},
				{
					xtype: 'textfield',
					inputType: 'password',
					name: 'senha',
					fieldLabel: 'Senha',
					emptyText: 'Insira sua senha'
				}
			],
			buttons: [
				{
					text: 'Acessar',
					action: 'autenticar'
				}
			]
		}
	]
});
