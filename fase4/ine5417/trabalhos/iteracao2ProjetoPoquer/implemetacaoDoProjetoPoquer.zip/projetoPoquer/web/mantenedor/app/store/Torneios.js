Ext.define('PP.store.Torneios', {
	extend: 'Ext.data.Store',
  	requires: [ 
  		'PP.model.Torneio' 
  	],
	model: 'PP.model.Torneio',
	autoLoad: true,
	autoSync: true,
	proxy: {
    	type: 'rest',
       	url: '../recursos/torneios',
        reader: {
            type: 'json',
            root: 'torneios'
        }
	}
});
