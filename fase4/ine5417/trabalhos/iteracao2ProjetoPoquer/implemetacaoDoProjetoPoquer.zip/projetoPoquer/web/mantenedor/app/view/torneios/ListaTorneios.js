Ext.define('PP.view.torneios.ListaTorneios', {
	extend: 'Ext.grid.Panel',
	alias: 'widget.listatorneios',
	requires: [
		'PP.view.torneios.CadastroTorneio'
	],
	store: 'Torneios',
	boder: false,
	multiSelect: false,
	columns: [
		{
			header: 'Identificador',
			dataIndex: 'identificador',
			flex: 0
		},
		{
			header: 'Descrição',
			dataIndex: 'descricao',
			flex: 1
		},
		{
			header: 'Vagas',
			dataIndex: 'vagas',
			flex: 0
		},
		{
			header: 'Entrada',
			dataIndex: 'entrada',
			flex: 0
		},
		{
			header: 'Mantenedor Criador',
			dataIndex: 'mantenedorCriador',
			flex: 1
		}
	],
	
	tbar: [
		{
			xtype: 'button',
			text: 'Adicionar',
			icon: 'recursos/imagens/adicionar.png',
			listeners: {
				click: function() {
					Ext.widget('cadastrotorneio');
				}
			}
		},
		{
			xtype: 'button',
			text: 'Remover',
			icon: 'recursos/imagens/remover.png',
			action: 'removerTorneio'
		}
	]
});
