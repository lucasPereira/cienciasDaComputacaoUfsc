Ext.define('PP.view.Principal', {
	extend: 'Ext.panel.Panel',
	alias: 'widget.principal',
	requires: [
		'PP.view.torneios.JanelaTorneios',
	],
	autoShow: true,
	items: [
		{
			xtype: 'buttongroup',
			items: [
				{
					xtype: 'button',
					scale: 'medium',
					icon: 'recursos/imagens/torneios.png',
					text: 'Torneios',
					listeners: {
						click: function() {
							Ext.widget('janelatorneios');
						}
					}
				}
			]
		}
	]
});
