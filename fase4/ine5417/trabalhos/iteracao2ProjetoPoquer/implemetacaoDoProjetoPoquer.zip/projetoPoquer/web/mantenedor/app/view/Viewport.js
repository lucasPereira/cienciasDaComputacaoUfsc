Ext.define('PP.view.Viewport', {
	extend: 'Ext.container.Viewport',
	requires: [
		'PP.view.acesso.Autenticacao'
	],
	layout: 'fit',
	items: [ 
		{
			xtype: 'autenticacao'
		}
	]
});
