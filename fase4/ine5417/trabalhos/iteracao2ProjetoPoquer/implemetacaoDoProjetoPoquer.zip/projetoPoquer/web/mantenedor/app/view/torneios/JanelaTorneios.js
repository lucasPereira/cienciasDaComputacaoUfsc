Ext.define('PP.view.torneios.JanelaTorneios', {
	extend: 'PP.view.Janela',
	alias: 'widget.janelatorneios',
	requires: [
		'PP.view.torneios.ListaTorneios',
		'Ext.grid.Panel'
	],
	title: 'Torneios',
	layout: 'fit', 
	border: false,
	autoShow: true,
	items: [
		{
			xtype: 'listatorneios'
		}	
	]
});
