Ext.define('PP.controller.Torneios', {
	extend: 'Ext.app.Controller',
	stores: [
		'Torneios',
	],
	models: [
		'Torneio'
	],
	views: [
		'torneios.JanelaTorneios',
		'torneios.ListaTorneios',
		'torneios.CadastroTorneio',
	],
	refs: [
		{
			ref: 'janelaTorneios',
			selector: 'janelatorneios'
		},
		{
			ref: 'listaTorneios',
			selector: 'listatorneios'
		},
		{
			ref: 'cadastroTorneio',
			selector: 'cadastrotorneio'
		}
	],
	
	init: function() {
		this.control({
			'cadastrotorneio button[action=cadastrar]':
			{	
				click: this.cadastrarTorneio
			},
			'listatorneios button[action=removerTorneio]':
			{	
				click: this.removerTorneio
			},
		});
	},
	
	cadastrarTorneio: function(botãoCadastrar) {
		var valores = botãoCadastrar.up('form').getForm().getValues();
		if (botãoCadastrar.up('form').getForm().isValid()) {
			Ext.Ajax.request({
				url: '../recursos/torneios',
				method: 'POST',
				jsonData: {
					nomeDeMantenedor: PP.nomeDeMantenedor,
					senhaDoMantenedor: PP.senha,
					descricao: valores.descricao,
					entrada: valores.entrada,
					vagas: valores.vagas
				},
				sucessProperty: 'sucesso', 
				scope: this,
				success: function(resposta) {
					var respostaJson = JSON.parse(resposta.responseText);
					if (respostaJson.sucesso) {
						Ext.MessageBox.show({
							title: 'Torneio cadastrado com sucesso',
							msg: 'O torneio foi cadastrado com sucesso.',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO
					 	});
					 	this.getCadastroTorneio().destroy();
					 	this.getTorneiosStore().load();
					}
				},
				failure: function() {
					Ext.MessageBox.show({
						title: 'Problema Interno',
						msg: 'Houve um problema interno, por favor volte mais tarde.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.ERROR
					});
				}
		   });
		}
   },
   
   removerTorneio: function() {
    	var torneio = this.getListaTorneios().getSelectionModel().getSelection()[0];
    	if (torneio != undefined) {
		   	Ext.Ajax.request({
				url: '../recursos/torneios/'+torneio.get('identificador'),
				method: 'DELETE',
				jsonData: {
					nomeDeMantenedor: PP.nomeDeMantenedor,
					senhaDoMantenedor: PP.senha
				},
				sucessProperty: 'sucesso', 
				scope: this,
				success: function(resposta) {
					var respostaJson = JSON.parse(resposta.responseText);
					if (respostaJson.sucesso) {
						Ext.MessageBox.show({
							title: 'Torneio removido',
							msg: 'O torneio foi removido com sucesso.',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO,
							fn: this.irParaPaginaInicial,
							scope: this
					 	});
					 	this.getTorneiosStore().load();
					}
				},
				failure: function() {
					Ext.MessageBox.show({
						title: 'Problema Interno',
						msg: 'Houve um problema interno, por favor volte mais tarde.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.ERROR
					});
				}
		   	});
		} else {
			Ext.MessageBox.show({
				title: 'Selecione um torneio',
				msg: 'Você deve selecionar um torneio.',
				buttons: Ext.MessageBox.OK,
				icon: Ext.MessageBox.WARNING
			});
		}
   	}
});
