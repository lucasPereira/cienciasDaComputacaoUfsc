Ext.define('PP.controller.Torneio', {
	extend: 'Ext.app.Controller',
	views: [
		'torneio.jogo.JanelaTorneio',
		'torneio.BotaoTorneioDaBarraDeJanelas',
		'BarraDeJanelas'
	],
	refs: [
		{
			ref: 'janelaTorneio',
			selector: 'janelatorneio'
		},
		{
			ref: 'botaoTorneioDaBarraDeJanelas',
			selector: 'botaotorneiodabarradejanelas'
		},
		{
			ref: 'barraDeJanelas',
			selector: 'barradejanelas'
		}
	],
	
    init: function() {
    	this.control({
    	 	'janelatorneio': {
    			render: this.adicionarBotãoTorneioDaBarraDeJanelas,
    			minimize: this.minimizarJanelaDoTorneio
    		},
    		'janelatorneio button[action=aumentar]': {
    			click: this.aumentar
    		},
    		'janelatorneio button[action=pagar]': {
    			click: this.pagar
    		},
    		'janelatorneio button[action=passar]': {
    			click: this.passar
    		},
    		'janelatorneio button[action=desistir]': {
    			click: this.desistir
    		},
    		'botaotorneiodabarradejanelas': {
    			click: this.mostrarJanelaDoTorneio
    		}
    	});
    },
    
    adicionarBotãoTorneioDaBarraDeJanelas: function(janelaDoTorneio) {
    	var botãoTorneioDaBarraDeJanelas = Ext.widget('botaotorneiodabarradejanelas', {
    		identificadorDoTorneio: janelaDoTorneio.identificadorDoTorneio,
    		janelaDoTorneio: janelaDoTorneio
    	});
		this.getBarraDeJanelas().add(botãoTorneioDaBarraDeJanelas);
		this.adicionarAtualizadorDoTorneio(janelaDoTorneio);
    },
    
    mostrarJanelaDoTorneio: function(botãoTorneioDaBarraDeJanelas) {
    	var janelaDoTorneio = botãoTorneioDaBarraDeJanelas.janelaDoTorneio;
    	if (janelaDoTorneio.isHidden()) {
    		janelaDoTorneio.show();
    	} else {
    		janelaDoTorneio.hide();
    	}
    },
    
    minimizarJanelaDoTorneio: function(janelaDoTorneio) {
    	janelaDoTorneio.hide();
    },
    
    adicionarAtualizadorDoTorneio: function(janelaDoTorneio) {
    	var atualização = {
    		run: this.atualizarTorneio,
    		args: [
    			janelaDoTorneio
    		],
    		scope: this,
    		interval: 500
    	};
    	var execuçãoDeAtualização = Ext.create('Ext.util.TaskRunner');
		execuçãoDeAtualização.start(atualização);
    },
    
    aumentar: function(botãoAumentar) {
    	var aumento = botãoAumentar.up('buttongroup').down('slider').getValue();
    	var janelaDoTorneio = botãoAumentar.up('window');
    	Ext.Ajax.request({
    		url: '../recursos/torneios/'+janelaDoTorneio.identificadorDoTorneio+'/aumento',
    		method: 'POST',
    		sucessProperty: 'sucesso', 
    		scope: this,
    		jsonData: {
				nomeDeUsuario: PP.jogador.get('nomeDeUsuario'),
				chaveDeSecao: PP.jogador.get('chaveDeSecao'),
				aumento: aumento
			},
			success: function(respostaDeAumento) {
				var respostaDeAumentoJson = Ext.JSON.decode(respostaDeAumento.responseText);
				if (respostaDeAumentoJson.erro) {
					Ext.MessageBox.show({
						title: 'Jogada não realizado',
						msg: 'Não foi possível realizar a jogada. <br /><br />Motivo: '+respostaDeAumentoJson.mensagemDeErro,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.WARNING
					});
				}
			},
			failure: function() {
				Ext.MessageBox.show({
					   title: 'Aumento não realizado',
					   msg: 'Houve um problema interno, por favor volte mais tarde.',
					   buttons: Ext.MessageBox.OK,
					   icon: Ext.MessageBox.ERROR
				});
			}
    	});
    },
    
    pagar: function(botãoPagar) {
    	this.realizarJogadaSemAposta(botãoPagar, 'pagamento');
    },
    
    passar: function(botãoPassar) {
    	this.realizarJogadaSemAposta(botãoPassar, 'passo');
    },
    
    desistir: function(botãoDesistir) {
    	this.realizarJogadaSemAposta(botãoDesistir, 'desistencia');
    },
    
    realizarJogadaSemAposta: function(botão, nomeDoRecurso) {
    	var janelaDoTorneio = botão.up('window');
    	Ext.Ajax.request({
    		url: '../recursos/torneios/'+janelaDoTorneio.identificadorDoTorneio+'/'+nomeDoRecurso,
    		method: 'POST',
    		sucessProperty: 'sucesso', 
    		scope: this,
    		jsonData: {
				nomeDeUsuario: PP.jogador.get('nomeDeUsuario'),
				chaveDeSecao: PP.jogador.get('chaveDeSecao'),
			},
			success: function(respostaDeAumento) {
				var respostaDeAumentoJson = Ext.JSON.decode(respostaDeAumento.responseText);
				if (respostaDeAumentoJson.erro) {
					Ext.MessageBox.show({
						title: 'Jogada não realizado',
						msg: 'Não foi possível realizar a jogada. <br /><br />Motivo: '+respostaDeAumentoJson.mensagemDeErro,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.WARNING
					});
				}
			},
			failure: function() {
				Ext.MessageBox.show({
					   title: 'Aumento não realizado',
					   msg: 'Houve um problema interno, por favor volte mais tarde.',
					   buttons: Ext.MessageBox.OK,
					   icon: Ext.MessageBox.ERROR
				});
			}
    	});
    },
    
    atualizarTorneio: function(janelaDoTorneio) {
    	Ext.Ajax.request({
			url: '../recursos/torneios/'+janelaDoTorneio.identificadorDoTorneio+'/completo',
			method: 'POST',
			successProperty: 'sucesso',
			scope: this,
			jsonData: {
				nomeDeUsuario: PP.jogador.get('nomeDeUsuario'),
				chaveDeSecao: PP.jogador.get('chaveDeSecao')
			},
			success: function(respostaDeAtualizaçãoDoTorneio) {
				var respostaDeAtualizaçãoDoTorneioJson = Ext.JSON.decode(respostaDeAtualizaçãoDoTorneio.responseText);
				var itensDaJanelaDoTorneio = janelaDoTorneio.down('panel').items;
				
				var jogadores = respostaDeAtualizaçãoDoTorneioJson.jogadores;
				for (var jogador in jogadores) {
					var áreaDoJogador = itensDaJanelaDoTorneio.getByKey('areadojogador'+jogadores[jogador].posicaoNaMesa);
					áreaDoJogador.setTitle(jogadores[jogador].nomeDeUsuario);
					áreaDoJogador.down('displayfield[name=fichas]').setValue(jogadores[jogador].fichas);
					áreaDoJogador.down('displayfield[name=estado]').setValue(jogadores[jogador].estado);
					áreaDoJogador.down('displayfield[name=fichasNaMesa]').setValue(jogadores[jogador].fichasNaMesa);
				}
				var rodada = respostaDeAtualizaçãoDoTorneioJson.rodada;
				var áreaDeInformações = janelaDoTorneio.down('panel').down('areadeinformacoes');
				áreaDeInformações.down('displayfield[name=pote]').setValue(rodada.pote);
				áreaDeInformações.down('displayfield[name=jogadorDaVez]').setValue(rodada.jogadorDaVez);
				áreaDeInformações.down('displayfield[name=ultimaJogada]').setValue(rodada.ultimaJogada);
				áreaDeInformações.down('displayfield[name=blinds]').setValue(rodada.blinds);			
				var posiçãoDoDealer = respostaDeAtualizaçãoDoTorneioJson.posicaoDoDealer;
				var áreaDoDealer = itensDaJanelaDoTorneio.getByKey('areadojogador'+posiçãoDoDealer);
				var botãoDoDealer = itensDaJanelaDoTorneio.getByKey('dealer');
				if (posiçãoDoDealer >= 0 && posiçãoDoDealer <= 2) {
					var posição = áreaDoDealer.getPosition(true);
					botãoDoDealer.setPosition(posição[0]+150, posição[1]+45);
				}
				if (posiçãoDoDealer >= 3 && posiçãoDoDealer <= 5) {
					var posição = áreaDoDealer.getPosition(true);
					botãoDoDealer.setPosition(posição[0]+75, posição[1]+90);
				}
				if (posiçãoDoDealer >= 6 && posiçãoDoDealer <= 9) {
					var posição = áreaDoDealer.getPosition(true);
					botãoDoDealer.setPosition(posição[0]-150, posição[1]+45);
				}
				var cartasDaMesa = rodada.cartasDaMesa;
				var áreaDeCartasDaMesa = itensDaJanelaDoTorneio.getByKey('cartasDaMesa').items;
				var contador = 0;
				for (var cartaDaMesa in cartasDaMesa) {
					áreaDeCartasDaMesa.getByKey('cartaDaMesa'+contador).setSrc('recursos/imagens/cartas/'+cartasDaMesa[cartaDaMesa]+'.png');
					contador++;
				}
				for (contador; contador < 5; contador++) {
					áreaDeCartasDaMesa.getByKey('cartaDaMesa'+contador).setSrc('recursos/imagens/baralhoVerde.png');			
				}
				var vencedores = rodada.vencedores;
				if (vencedores != "") {
					Ext.MessageBox.show({
						   title: 'Vencedor(es) da rodada',
						   msg: vencedores,
						   buttons: Ext.MessageBox.OK,
						   icon: Ext.MessageBox.INFO
					});
				}
				var jogador = respostaDeAtualizaçãoDoTorneioJson.jogador;
				var áreaDeOpções = janelaDoTorneio.down('panel').down('areadeopcoes');
				áreaDeOpções.down('button[action=desistir]').disable();
				áreaDeOpções.down('button[action=passar]').disable();
				áreaDeOpções.down('button[action=pagar]').disable();
				áreaDeOpções.down('button[action=aumentar]').disable();
				if (jogador.acoesPossiveis.estaNaVez) {
					if (jogador.acoesPossiveis.podeAumentar) {
						áreaDeOpções.down('button[action=aumentar]').enable();
					}
					if (jogador.acoesPossiveis.podePassar) {
						áreaDeOpções.down('button[action=passar]').enable();
					}
					if (jogador.acoesPossiveis.podePagar) {
						áreaDeOpções.down('button[action=pagar]').enable();
					}
					if (jogador.acoesPossiveis.podeDesistir) {
						áreaDeOpções.down('button[action=desistir]').enable();
					}
					áreaDeOpções.down('buttongroup').down('slider').setMinValue(jogador.acoesPossiveis.apostaMinima*2);
					áreaDeOpções.down('buttongroup').down('slider').setMaxValue(jogador.acoesPossiveis.apostaMaxima);
				}
				if (jogador.cartas.length == 2) {
					áreaDeOpções.down('container[id=cartas]').items.getByKey('carta1').setSrc('recursos/imagens/cartas/'+jogador.cartas[0]+'.png');
					áreaDeOpções.down('container[id=cartas]').items.getByKey('carta2').setSrc('recursos/imagens/cartas/'+jogador.cartas[1]+'.png');
				}
				
			},
			failure: function() {
				Ext.MessageBox.show({
					   title: 'Atualização dos jogadores não realizada',
					   msg: 'Houve um problema interno, por favor volte mais tarde.',
					   buttons: Ext.MessageBox.OK,
					   icon: Ext.MessageBox.ERROR
				});
			}
		});
    }
});
