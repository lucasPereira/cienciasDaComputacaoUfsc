Ext.define('PP.view.torneio.jogo.AreaDeOpcoes', {
	extend: 'Ext.container.ButtonGroup',
	alias: 'widget.areadeopcoes',
	width: 375,
	height: 90,
	frame: false,
	border: false,
	baseCls: 'opcoes',
	buttonAlign: 'center',
	padding: '0 20px',
	layout: {
        type: 'hbox',
        align: 'middle'
    },
	config: {
		x: 0,
		y: 0
	},
	items: [
        {
            xtype: 'button',
            text: 'Desistir',
            action: 'desistir',
            scale: 'large',
            flex: 0,
        },
        {
            xtype: 'button',
            text: 'Passar',
            action: 'passar',
            scale: 'large',
            flex: 0,
        },
        {
            xtype: 'button',
            text: 'Pagar',
            action: 'pagar',
            scale: 'large',
            flex: 0
        },
        {
        	xtype: 'buttongroup',
        	frame: false,
        	border: false,
        	height: 100,
        	flex: 1,
			layout: {
				type: 'vbox',
				align: 'stretch',
				pack: 'center'
			},
        	items: [
				{
				    xtype: 'button',
				    text: 'Aumentar',
				    action: 'aumentar',
				    scale: 'large'
				},
				{
					xtype: 'slider'
				}
			]
		},
		{
        	xtype: 'tbspacer',
        	flex: 0.5
        },
        {
        	xtype: 'container',
        	id: 'cartas',
        	width: 100,
        	items: [
				{
					xtype: 'image',
					id: 'carta1',
					src: 'recursos/imagens/baralhoVerde.png'
				},
				{
					xtype: 'image',
					margin: '0 0 0 5px',
					id: 'carta2',
					src: 'recursos/imagens/baralhoVerde.png'
				}
			]
        }
   	],
	
	constructor: function(configuração) {
		this.initConfig(configuração);
		this.callParent();
		
		return this;
	}
});
