Ext.define('PP.view.regras.IconeRegras', {
	extend: 'PP.view.Icone',
	alias: 'widget.iconeregras',
	config: {
		imagem: 'dados2.png',
		texto: 'Regras'
	}
});
