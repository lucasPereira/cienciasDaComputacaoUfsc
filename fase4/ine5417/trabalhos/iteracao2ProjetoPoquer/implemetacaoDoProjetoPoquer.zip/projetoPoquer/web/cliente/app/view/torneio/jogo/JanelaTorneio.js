Ext.define('PP.view.torneio.jogo.JanelaTorneio', {
	extend: 'Ext.window.Window',
	alias: 'widget.janelatorneio',
	requires: [
		'PP.view.torneio.jogo.AreaDoJogador',
		'PP.view.torneio.jogo.AreaDeInformacoes',
		'PP.view.torneio.jogo.AreaDeOpcoes'
	],
	closable: false,
	resizable: false,
	minimizable: true,
	config: {
		identificadorDoTorneio: 0
	},
	border: false,
	layout: 'fit',
	items: [
		{
			xtype: 'panel',
			border: false,
			layout: 'absolute',
			bodyCls: 'torneio',
			frame: false,
			width: 750,
			height: 470,
			items: [
				{
					xtype: 'panel',
					bodyCls: 'mesaTorneio',
					border: false,
					width: 450,
					height: 270,
					x: 150,
					y: 90
				},
				{
					xtype: 'container',
					id: 'cartasDaMesa',
					bodyCls: 'mesaTorneio',
					border: false,
					height: 54,
					x: 253,
					y: 160,
					items: [
						{
							xtype: 'image',
							id: 'cartaDaMesa0',
							src: 'recursos/imagens/baralhoVerde.png'
						},
						{
							xtype: 'image',
							margin: '0 0 0 5px',
							id: 'cartaDaMesa1',
							src: 'recursos/imagens/baralhoVerde.png'
						},
						{
							xtype: 'image',
							margin: '0 0 0 5px',
							id: 'cartaDaMesa2',
							src: 'recursos/imagens/baralhoVerde.png'
						},
						{
							xtype: 'image',
							margin: '0 0 0 15px',
							id: 'cartaDaMesa3',
							src: 'recursos/imagens/baralhoVerde.png'
						},
						{
							xtype: 'image',
							margin: '0 0 0 15px',
							id: 'cartaDaMesa4',
							src: 'recursos/imagens/baralhoVerde.png'
						}
					]
				},
				{
					xtype: 'areadeinformacoes',
					x: 0,
					y: 380
				},
				{
					xtype: 'areadeopcoes',
					x: 375,
					y: 380
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador0',
					x: 0,
					y: 270
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador1',
					x: 0,
					y: 180
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador2',
					x: 0,
					y: 90
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador3',
					x: 150,
					y: 0
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador4',
					x: 300,
					y: 0
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador5',
					x: 450,
					y: 0
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador6',
					x: 600,
					y: 90
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador7',
					x: 600,
					y: 180
				},
				{
					xtype: 'areadojogador',
					id: 'areadojogador8',
					x: 600,
					y: 270
				},
				{
					xtype: 'image',
					id: 'dealer',
					src: 'recursos/imagens/dealer.png',
					x: 365,
					y: 230
				}
			]
		}
	],
	
	constructor: function(configuração) {
		this.initConfig(configuração);
		this.callParent();
		this.title = 'Torneio #'+this.identificadorDoTorneio;
		this.animateTarget = 'bataoTorneio'+this.identificadorDoTorneio+'DaBarraDeJanelas';
		this.show();
		
		return this;
	}
});
