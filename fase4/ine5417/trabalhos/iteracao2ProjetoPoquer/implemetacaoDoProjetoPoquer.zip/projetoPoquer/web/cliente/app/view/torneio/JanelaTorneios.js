Ext.define('PP.view.torneio.JanelaTorneios', {
	extend: 'PP.view.Janela',
	alias: 'widget.janelatorneios',
	requires: [
		'PP.view.torneio.ListaTorneios'
	],
	title: 'Torneios Disponíveis',
	layout: 'fit',
	border: false,
	animateTarget: 'idBotaoTorneiosDaBarraDeJanelas',
	autoShow: false,
	items: [
		{
			xtype: 'listatorneios',
			border: false
		}	
	]
});
