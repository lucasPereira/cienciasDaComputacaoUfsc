Ext.define('PP.view.Icone', {
	extend: 'Ext.container.ButtonGroup',
	alias: 'widget.icone',
	config: {
        imagem: 'iconePadrao.png',
        texto: 'Nome Do Ícone'
    },
    width: 74,
    padding: '5',
    layout: 'fit',
    componentCls: 'icone',
	initComponent: function() {
		this.items = [
			{
				xtype: 'image',
				src: 'recursos/imagens/'+this.config.imagem,
				width: 64,
				height: 64
			}
		];
		this.html = '<span>'+this.config.texto+'</span>';
		this.callParent();
	}
});
