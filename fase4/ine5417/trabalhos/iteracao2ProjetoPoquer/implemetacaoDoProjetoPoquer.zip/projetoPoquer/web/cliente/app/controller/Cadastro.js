Ext.define('PP.controller.Cadastro', {
	extend: 'Ext.app.Controller',
	models: [
		'Jogador' 
	],
	views: [
		'acesso.Cadastro',
		'acesso.Autenticacao',
		'Viewport'
	],
	refs: [
		{
			ref: 'cadastroJogador',
			selector: 'cadastrojogador'
		},
		{
			ref: 'autenticacao',
			selector: 'autenticacao'
		},
		{
			ref: 'viewport',
			selector: 'viewport'
		}
	],
	
	init: function() {
		this.control({
			'cadastrojogador button[action=cadastrar]': {
				click: this.cadastrar
			},
			'cadastrojogador': {
				close: this.fecharJanelaCadastro
			}
		});
	},
	
	cadastrar: function(botãoCadastrar) {
		var formulário = botãoCadastrar.up('form').getForm();
		if (formulário.isValid()) {
			var valores = formulário.getValues();
			var registro = Ext.create('PP.model.Jogador', {
				nome: valores.nome,
				nomeDeUsuario: valores.nomeDeUsuario,
				email: valores.email,
				senha: valores.senha
			});
			registro.save({
				scope: this,
				success: function(registro, resposta) {
					registro.set('nome', valores.nome);
					registro.set('nomeDeUsuario', valores.nomeDeUsuario);
					registro.set('email', valores.email);
					registro.set('senha', valores.senha);
					var respostaJson = Ext.JSON.decode(resposta.response.responseText);
					if (respostaJson.erro) {
						Ext.MessageBox.show({
							title: 'Cadastro não realizado',
							msg: 'Não foi possível realizar o cadastro. <br /><br />Motivo: '+respostaJson.mensagemDeErro,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.WARNING
						});
					} else {
						registro.set('nome', valores.nome);
						registro.set('nomeDeUsuario', valores.nomeDeUsuario);
						this.autenticarJogador(valores, registro);
						registro.phantom = false;
					}
				},
				failure: function() {
					Ext.MessageBox.show({
					   title: 'Cadastro não realizado',
					   msg: 'Houve um problema interno, por favor volte mais tarde.',
					   buttons: Ext.MessageBox.OK,
					   icon: Ext.MessageBox.ERROR
				   });
				}
			});
			PP.addStatics({
				jogador: registro
			});
		}
	},
	
	fecharJanelaCadastro: function(janelaCadastro) {
		janelaCadastro.destroy();
	},
	
	autenticarJogador: function(valores, registro) {
		Ext.Ajax.request({
			scope: this,
			url: '../recursos/jogadores/'+valores.nomeDeUsuario+'/autenticacao',
			method: 'POST',
			jsonData: {
				senha: valores.senha
			},
			successProperty: 'sucesso',
			success: function(respostaDeAutenticacao) {
				var respostaDeAutenticacaoJson = Ext.JSON.decode(respostaDeAutenticacao.responseText);
				if (respostaDeAutenticacaoJson.erro) {
					Ext.MessageBox.show({
						title: 'Autenticação não realizada',
						msg: 'Não foi possível realizar a autenticação. <br /><br />Motivo: '+respostaDeAutenticacaoJson.mensagemDeErro,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.WARNING
					});								
				} else {
					Ext.MessageBox.show({
						title: 'Cadastro realizado com sucesso',
						msg: 'Seus dados cadastrados foram enviados para seu e-mail. Você já está autenticado no sistema, divirta-se.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO,
						modal: true
					});	
					registro.set('chaveDeSecao', respostaDeAutenticacaoJson.chaveDeSecao);
					PP.addStatics({
						jogador: registro
					});
					this.getAutenticacao().destroy();
					this.getCadastroJogador().destroy();
					this.getViewport().add(Ext.widget('principal'));
				}
			},
			failure: function() {
				Ext.MessageBox.show({
				   title: 'Autenticação não realizada',
				   msg: 'Houve um problema interno, por favor volte mais tarde.',
				   buttons: Ext.MessageBox.OK,
				   icon: Ext.MessageBox.ERROR
			   });
			}
		});
	}
});
