Ext.define('PP.view.caixa.IconeCaixa', {
	extend: 'PP.view.Icone',
	alias: 'widget.iconecaixa',
	config: {
		imagem: 'maleta.png',
		texto: 'Caixa'
	}
});
