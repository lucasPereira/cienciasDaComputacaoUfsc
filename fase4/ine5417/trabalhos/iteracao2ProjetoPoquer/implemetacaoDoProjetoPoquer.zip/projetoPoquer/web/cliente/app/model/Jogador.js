Ext.define('PP.model.Jogador', {
	extend: 'Ext.data.Model',
	fields: [
		{
			name: 'nome'
		},
		{
			name: 'nomeDeUsuario'
		},
		{
			name: 'senha'
		},
		{
			name: 'email'
		},
		{
			name: 'chaveDeSecao'
		}
	],
	proxy: {
		type: 'rest',
		url: '../recursos/jogadores',
		reader: {
			type: 'json',
			successProperty: 'sucesso'
		},
		writer: {
			type: 'json'
		}
	}
});
