Ext.define('PP.controller.Autenticacao', {
	extend: 'Ext.app.Controller',
	models: [
		'Jogador'
	],
	views: [
		'acesso.Autenticacao',
		'acesso.Cadastro',
		'Principal',
		'Viewport'
	],
	refs: [
		{
			ref: 'autenticacao',
			selector: 'autenticacao'
		},
		{
			ref: 'viewport',
			selector: 'viewport'
		},
		{
			ref: 'cadastro',
			selector: 'cadastro'
		}
	],
	
	init: function() {
		this.control({
			'autenticacao button[action=autenticar]': {
				click: this.autenticar
			},
			'autenticacao button[action=enviarSenha]': {
				click: this.enviarSenha
			},
			'autenticacao button[action=entrarNoCadastro]': {
				click: this.entrarNoCadastro
			}
		});
	},
	
	autenticar: function() {
		var formulário = this.getAutenticacao().down('form').getForm();
		var valores = formulário.getValues();
		var registro = Ext.create('PP.model.Jogador', {
			nomeDeUsuario: valores.nomeDeUsuario,
			senha: valores.senha
		});
		if (formulário.isValid()) {
			Ext.Ajax.request({
				scope: this,
				url: '../recursos/jogadores/'+valores.nomeDeUsuario+'/autenticacao',
				method: 'POST',
				jsonData: {
					senha: valores.senha
				},
				successProperty: 'sucesso',
				success: function(respostaDeAutenticacao) {
					var respostaDeAutenticacaoJson = Ext.JSON.decode(respostaDeAutenticacao.responseText);
					if (respostaDeAutenticacaoJson.erro) {
						Ext.MessageBox.show({
							title: 'Autenticação não realizada',
							msg: 'Não foi possível realizar a autenticação. <br /><br />Motivo: '+respostaDeAutenticacaoJson.mensagemDeErro,
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.WARNING
						});								
					} else {
						Ext.MessageBox.show({
							title: 'Autenticação realizada com sucesso',
							msg: 'Você já está autenticado no sistema, divirta-se.',
							buttons: Ext.MessageBox.OK,
							icon: Ext.MessageBox.INFO,
							modal: true
						});	
						registro.set('chaveDeSecao', respostaDeAutenticacaoJson.chaveDeSecao);
						registro.set('nome', respostaDeAutenticacaoJson.nome);
						registro.set('email', respostaDeAutenticacaoJson.email);
						PP.addStatics({
							jogador: registro
						});
						this.getAutenticacao().destroy();
						this.getViewport().add(Ext.widget('principal'));
					}
				},
				failure: function() {
					Ext.MessageBox.show({
					   title: 'Autenticação não realizada',
					   msg: 'Houve um problema interno, por favor volte mais tarde.',
					   buttons: Ext.MessageBox.OK,
					   icon: Ext.MessageBox.ERROR
				   });
				}
			});
		}
	},
	
	enviarSenha: function() {
		Ext.MessageBox.show({
           title: 'Senha enviada',
           msg: 'Sua senha foi enviada para seu e-mail cadastrado.',
           buttons: Ext.MessageBox.OK,
           icon: Ext.MessageBox.INFO
       });
	},
	
	entrarNoCadastro: function() {
		var janelaCadastro = this.getCadastro();
		if (janelaCadastro == undefined) {
			Ext.widget('cadastrojogador');
		} else {
			janelaCadastro.show();
		}
	}
});
