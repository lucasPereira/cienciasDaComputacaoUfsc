Ext.define('PP.view.torneio.BotaoTorneioDaBarraDeJanelas', {
	extend: 'PP.view.BotaoDaBarraDeJanelas',
	alias: 'widget.botaotorneiodabarradejanelas',
	config: {	
		identificadorDoTorneio: 0,
		janelaDoTorneio: { }
	},
	
	constructor: function(configuração) {
		this.initConfig(configuração);
		this.callParent();
		this.id = 'bataoTorneio'+this.identificadorDoTorneio+'DaBarraDeJanelas';
		this.text = 'Torneio #'+this.identificadorDoTorneio
		
		return this;
	}
});
