Ext.define('PP.view.torneio.IconeTorneios', {
	extend: 'PP.view.Icone',
	alias: 'widget.iconetorneios',
	config: {
		imagem: 'fichaPreta.png',
		texto: 'Torneios'
	}
});
