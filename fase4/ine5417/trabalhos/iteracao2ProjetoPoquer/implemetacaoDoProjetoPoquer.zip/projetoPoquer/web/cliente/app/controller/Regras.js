Ext.define('PP.controller.Regras', {
	extend: 'Ext.app.Controller',
	views: [
		'regras.IconeRegras',
		'regras.JanelaRegras',
		'regras.BotaoRegrasDaBarraDeJanelas',
		'BarraDeJanelas',
	],
	refs: [
		{
			ref: 'iconeRegras',
			selector: 'iconeregras'
		},
		{
			ref: 'janelaRegras',
			selector: 'janelaregras'
		},
		{
			ref: 'botaoRegrasDaBarraDeJanelas',
			selector: 'botaoregrasdabarradejanelas'
		},
		{
			ref: 'barraDeJanelas',
			selector: 'barradejanelas'
		}
	],
	
	init: function() {
		this.control({
			'iconeregras': {
				render: this.adicionarTratadorDeClick
			},
			'janelaregras': {
				minimize: this.minimizarJanela,
				close: this.fecharJanela
			},
			'botaoregrasdabarradejanelas': {
				click: this.mostrarJanela
			}
		});
	},
	
	adicionarTratadorDeClick: function() {
		this.getIconeRegras().addListener({
			click: this.clicarNoIcone,
			element: 'body',
			scope: this
		});
	},
	
	clicarNoIcone: function() {
		if (this.getJanelaRegras() == undefined) {
			Ext.widget('janelaregras');
			var botaoRegrasDaBarraDeJanelas = Ext.widget('botaoregrasdabarradejanelas');
			this.getBarraDeJanelas().add(botaoRegrasDaBarraDeJanelas);
			this.mostrarJanela();
		}
	},
	
	minimizarJanela: function() {
		this.getJanelaRegras().hide();
	},
	
	mostrarJanela: function() {
		var janela = this.getJanelaRegras();
		if (janela.isHidden()) {
			janela.show();
		} else {
			janela.hide();
		}
	},
	
	fecharJanela: function() {
		this.getBarraDeJanelas().remove('idBotaoRegrasDaBarraDeJanelas');
		this.getJanelaRegras().destroy();
	}
});
