Ext.define('PP.view.acesso.Cadastro', {
	extend: 'Ext.window.Window',
	alias: 'widget.cadastrojogador',
	title: 'Cadastro',
	autoShow: true,
    border: false,
    modal: true,
   	resizable: false,
    bodyStyle: 'margin: 0 0 10px 0',
    items: [
		{
			xtype: 'form',
			boder: false,
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'textfield', 
					name: 'nome',
					dataIndex: 'nome',
					fieldLabel: 'Nome',
					emptyText: 'Digite seu nome',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					name: 'nomeDeUsuario',
					dataIndex: 'nomeDeUsuario',
					fieldLabel: 'Usuário',
					emptyText: 'Digite um nome de usuário',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					inputType: 'password',
					name: 'senha',
					dataIndex: 'senha',
					fieldLabel: 'Senha',
					emptyText: 'Insira uma senha',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					name: 'email',
					dataIndex: 'email',
					fieldLabel: 'E-mail',
					emptyText: 'Insira seu e-mail',
					allowBlank: false,
					vtype: 'email'
				}
			],
			buttons: [
				{
					text: 'Cadastrar',
					action: 'cadastrar'
				}
			]
		}    
    ]
});
