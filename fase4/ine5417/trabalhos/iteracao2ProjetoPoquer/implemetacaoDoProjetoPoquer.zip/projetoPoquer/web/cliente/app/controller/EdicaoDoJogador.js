Ext.define('PP.controller.EdicaoDoJogador', {
	extend: 'Ext.app.Controller',
	views: [
        'caixa.EdicaoDoJogador'
    ],
    refs: [
       {
    	   ref: 'edicaoDoJogador',
    	   selector: 'edicaodojogador'
       }
   ],
   
   init: function() {
	   this.control({
		   'edicaodojogador': {
			  render: this.carregarDados
		   },
		   'edicaodojogador button[action=salvar]': {
			   click: this.salvar
		   },
		   'edicaodojogador button[action=excluir]': {
			   click: this.excluir
		   }
	   });
   },
   
   carregarDados: function() {
	   	Ext.Ajax.request({
			url: '../recursos/jogadores/'+PP.jogador.get('nomeDeUsuario'),
			method: 'GET',
			sucessProperty: 'sucesso', 
			scope: this,
			success: function(resposta) {
				var formulário = this.getEdicaoDoJogador().down('form').getForm();
				var respostaJson = JSON.parse(resposta.responseText);
				formulário.setValues({
					nome: respostaJson.jogador.nome,
					senha: '',
					email: respostaJson.jogador.email
				});
			},
			failure: function() {
				Ext.MessageBox.show({
					title: 'Problema Interno',
					msg: 'Houve um problema interno, por favor volte mais tarde.',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
			}
	   	});
   },
   
   salvar: function() {
	   var valores = this.getEdicaoDoJogador().down('form').getForm().getValues();
	   console.log(valores);
	   Ext.Ajax.request({
			url: '../recursos/jogadores/'+PP.jogador.get('nomeDeUsuario'),
			method: 'PUT',
			jsonData: {
				nome: valores.nome,
				email: valores.email,
				senha: valores.senha,
				chaveDeSecao: PP.jogador.get('chaveDeSecao'),
			},
			sucessProperty: 'sucesso', 
			scope: this,
			success: function(resposta) {
				var respostaJson = JSON.parse(resposta.responseText);
				if (respostaJson.sucesso) {
					Ext.MessageBox.show({
						title: 'Conta atualizada',
						msg: 'Sua conta atualizada com sucesso.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO
				 	});
				}
			},
			failure: function() {
				Ext.MessageBox.show({
					title: 'Problema Interno',
					msg: 'Houve um problema interno, por favor volte mais tarde.',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
			}
	   });
   },
  
   excluir: function() {
	   	Ext.Ajax.request({
			url: '../recursos/jogadores/'+PP.jogador.get('nomeDeUsuario'),
			method: 'DELETE',
			jsonData: {
				chaveDeSecao: PP.jogador.get('chaveDeSecao'),
			},
			sucessProperty: 'sucesso', 
			scope: this,
			success: function(resposta) {
				var respostaJson = JSON.parse(resposta.responseText);
				if (respostaJson.sucesso) {
					Ext.MessageBox.show({
						title: 'Conta removida',
						msg: 'Sua conta foi removida com sucesso.',
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.INFO,
						fn: this.irParaPaginaInicial,
						scope: this
				 	});
				}
			},
			failure: function() {
				Ext.MessageBox.show({
					title: 'Problema Interno',
					msg: 'Houve um problema interno, por favor volte mais tarde.',
					buttons: Ext.MessageBox.OK,
					icon: Ext.MessageBox.ERROR
				});
			}
	   	});
   },
   
   irParaPaginaInicial: function() {
	   window.location = '';
   }
});