Ext.define('PP.controller.Torneios', {
	extend: 'Ext.app.Controller',
	stores: [
		'Torneios',
	],
	models: [
		'Torneio'
	],
	views: [
		'torneio.IconeTorneios',
		'torneio.JanelaTorneios',
		'torneio.ListaTorneios',
		'torneio.jogo.JanelaTorneio',
		'torneio.jogo.AreaDoJogador',
		'torneio.BotaoTorneiosDaBarraDeJanelas',
		'BarraDeJanelas'
	],
	refs: [
		{
			ref: 'iconeTorneios',
			selector: 'iconetorneios'
		},
		{
			ref: 'janelaTorneios',
			selector: 'janelatorneios'
		},
		{
			ref: 'listaTorneios',
			selector: 'listatorneios'
		},
		{
			ref: 'botaoTorneiosDaBarraDeJanelas',
			selector: 'botaotorneiosdabarradejanelas'
		},
		{
			ref: 'barraDeJanelas',
			selector: 'barradejanelas'
		}
	],
	
	init: function() {
		this.control({
			'iconetorneios': {
				render: this.adicionarTratadorDeClick
			},
			'janelatorneios': {
				minimize: this.minimizarJanela,
				close: this.fecharJanela
			},
			'listatorneios':
			{	
				itemdblclick: this.entrarNoTorneio
			},
			'botaotorneiosdabarradejanelas': {
				click: this.mostrarJanela
			},
			'janelatorneios button[action=atualizarListaTorneios]':	{
				click: this.atualizarListaTorneios
			}
		});
	},
	
	adicionarTratadorDeClick: function() {
		this.getIconeTorneios().addListener({
			click: this.clicarNoIcone,
			element: 'body',
			scope: this
		});
	},
	
	clicarNoIcone: function() {
		if (this.getJanelaTorneios() == undefined) {
			Ext.widget('janelatorneios');
			var botaoTorneiosDaBarraDeJanelas = Ext.widget('botaotorneiosdabarradejanelas');
			this.getBarraDeJanelas().add(botaoTorneiosDaBarraDeJanelas);
			this.mostrarJanela();
		}
	},
	
	entrarNoTorneio: function(listaDeTorneios, torneio) {
		Ext.Ajax.request({
			url: '../recursos/torneios/'+torneio.get('identificador')+'/inscricao',
			method: 'POST',
			jsonData: {
				nomeDeUsuario: PP.jogador.get('nomeDeUsuario'),
				chaveDeSecao: PP.jogador.get('chaveDeSecao')
			},
			successProperty: 'sucesso',
			scope: this,
			success: function(respostaDeInscrição) {
				var respostaDeInscriçãoJson = Ext.JSON.decode(respostaDeInscrição.responseText);
				if (respostaDeInscriçãoJson.erro) {
					Ext.MessageBox.show({
						title: 'Inscrição não realizada',
						msg: 'Não foi possível se inscrever no torneio. <br /><br />Motivo: '+respostaDeInscriçãoJson.mensagemDeErro,
						buttons: Ext.MessageBox.OK,
						icon: Ext.MessageBox.WARNING
					});		
				} else {
					var janelaTorneio = Ext.widget('janelatorneio', {
						identificadorDoTorneio: torneio.get('identificador')
					});
					/*
					var itensDaJanelaTorneio = janelaTorneio.down('panel').items;
					var jogadores = respostaDeInscriçãoJson.jogadores;
					for (var jogador in jogadores) {
						var áreaDoJogador = itensDaJanelaTorneio.getByKey('areadojogador'+jogadores[jogador].posicaoNaMesa);
						áreaDoJogador.setTitle(jogadores[jogador].nomeDeUsuario);
						áreaDoJogador.down('displayfield[name=fichas]').setValue(jogadores[jogador].fichas);
						áreaDoJogador.down('displayfield[name=estado]').setValue(jogadores[jogador].estado);
						áreaDoJogador.down('displayfield[name=fichasNaMesa]').setValue(jogadores[jogador].fichasNaMesa);
					}
					*/
				}
			},
			failure: function() {
				Ext.MessageBox.show({
					   title: 'Cadastro não realizado',
					   msg: 'Houve um problema interno, por favor volte mais tarde.',
					   buttons: Ext.MessageBox.OK,
					   icon: Ext.MessageBox.ERROR
				});
			}
		});
	},
	
	minimizarJanela: function() {
		this.getJanelaTorneios().hide();
	},
	
	mostrarJanela: function() {
		var janela = this.getJanelaTorneios();
		if (janela.isHidden()) {
			janela.show();
		} else {
			janela.hide();
		}
	},
	
	fecharJanela: function() {
		this.getBarraDeJanelas().remove('idBotaoTorneiosDaBarraDeJanelas');
		this.getJanelaTorneios().destroy();
	},
	
	atualizarListaTorneios: function(botãoAtualizar) {
		this.getTorneiosStore().load();
	}
});
