Ext.define('PP.view.BotaoDaBarraDeJanelas', {
	extend: 'Ext.button.Button',
	alias: 'widget.botaodabarradejanelas',
	icon: 'recursos/imagens/copasPequeno.png'
});
