Ext.define('PP.view.Janela', {
	extend: 'Ext.window.Window',
	alias: 'widget.janela',
	width: 600,
	height: 400,
	minimizable: true,
	resizable: false
});
