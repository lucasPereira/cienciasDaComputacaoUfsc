Ext.define('PP.view.caixa.JanelaCaixa', {
	extend: 'PP.view.Janela',
	alias: 'widget.janelacaixa',
	requires: [
       'PP.view.caixa.EdicaoDoJogador'
   	],
	title: 'Caixa',
	animateTarget: 'idBotaoCaixaDaBarraDeJanelas',
	items: 
	[
        {
        	xtype: 'edicaodojogador'
        }
	]
});
