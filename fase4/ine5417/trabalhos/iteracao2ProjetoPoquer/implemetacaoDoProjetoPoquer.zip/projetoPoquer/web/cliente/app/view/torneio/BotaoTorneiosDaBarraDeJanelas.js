Ext.define('PP.view.torneio.BotaoTorneiosDaBarraDeJanelas', {
	extend: 'PP.view.BotaoDaBarraDeJanelas',
	alias: 'widget.botaotorneiosdabarradejanelas',
	text: 'Torneios',
	id: 'idBotaoTorneiosDaBarraDeJanelas'
});
