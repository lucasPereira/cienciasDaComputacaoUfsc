Ext.define('PP.view.regras.JanelaRegras', {
	extend: 'PP.view.Janela',
	alias: 'widget.janelaregras',
	title: 'Regras',
	animateTarget: 'idBotaoRegrasDaBarraDeJanelas',
});
