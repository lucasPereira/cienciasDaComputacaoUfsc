Ext.define('PP.view.BarraDeJanelas', {
	extend: 'Ext.toolbar.Toolbar',
	alias: 'widget.barradejanelas',
	requires: [
		'Ext.window.MessageBox'
	],
	items: [
		{
			xtype: 'button',
			id: 'idBotaoProjetoPoquerDaBarraDeJanelas',
			icon: 'recursos/imagens/fichaPretaPequena.png',
			text: 'Projeto Poquêr',
			handler: function() {
				Ext.MessageBox.show({
					title: 'Projeto Pôquer',
					msg: 'Projeto realizado para a disciplina de Engenharia de Software. <br /><br /><strong style="font-weight: bold">Alunos:</strong><br />Chrystian Guth<br />Diego Gonçalves<br />Gabriel Gava<br />Lucas Pereira.',
					buttons: Ext.MessageBox.OK,
					animateTarget: 'idBotaoProjetoPoquerDaBarraDeJanelas',
				});
			}
		}
	]
});
