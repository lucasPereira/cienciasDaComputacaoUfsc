Ext.define('PP.view.caixa.BotaoCaixaDaBarraDeJanelas', {
	extend: 'PP.view.BotaoDaBarraDeJanelas',
	alias: 'widget.botaocaixadabarradejanelas',
	text: 'Caixa',
	id: 'idBotaoCaixaDaBarraDeJanelas'
});
