Ext.define('PP.view.caixa.EdicaoDoJogador', {
	extend: 'Ext.panel.Panel',
	alias: 'widget.edicaodojogador',
	border: false,
	items: [
		{
			xtype: 'form',
			store: PP.jogador,
			boder: false,
			bodyStyle:'padding: 10px',
			items: [
				{
					xtype: 'textfield', 
					name: 'nome',
					dataIndex: 'nome',
					fieldLabel: 'Nome',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					inputType: 'password',
					name: 'senha',
					dataIndex: 'senha',
					fieldLabel: 'Senha',
					emptyText: 'Insira uma senha',
					allowBlank: false
				},
				{
					xtype: 'textfield',
					name: 'email',
					dataIndex: 'email',
					fieldLabel: 'E-mail',
					allowBlank: false,
					vtype: 'email'
				},
				{
	    	        xtype: 'displayfield',
	    		 	fieldLabel: 'Dinheiro Fictício',
	    		 	value: 'D$ 0,00'
        	    }
			]
		}
	],
	dockedItems: 
	[
		{	
			xtype: 'toolbar',
			boder: false,
			dock: 'bottom',
			items: [
				{
					xtype: 'button',
					text: 'Salvar Edição',
					action: 'salvar',
					icon: 'recursos/imagens/editar.png'
				},
				{
					xtype: 'button',
					text: 'Excluir Conta',
					action: 'excluir',
					icon: 'recursos/imagens/remover.png'
				}
			]
		}
	]
});