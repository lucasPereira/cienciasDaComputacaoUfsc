Ext.define('PP.controller.Caixa', {
	extend: 'Ext.app.Controller',
	views: [
		'caixa.IconeCaixa',
		'caixa.JanelaCaixa',
		'caixa.BotaoCaixaDaBarraDeJanelas',
		'BarraDeJanelas',
	],
	refs: [
		{
			ref: 'iconeCaixa',
			selector: 'iconecaixa'
		},
		{
			ref: 'janelaCaixa',
			selector: 'janelacaixa'
		},
		{
			ref: 'botaoCaixaDaBarraDeJanelas',
			selector: 'botaocaixadabarradejanelas'
		},
		{
			ref: 'barraDeJanelas',
			selector: 'barradejanelas'
		}
	],
	
	init: function() {
		this.control({
			'iconecaixa': {
				render: this.adicionarTratadorDeClick
			},
			'janelacaixa': {
				minimize: this.minimizarJanela,
				close: this.fecharJanela
			},
			'botaocaixadabarradejanelas': {
				click: this.mostrarJanela
			}
		});
	},
	
	adicionarTratadorDeClick: function() {
		this.getIconeCaixa().addListener({
			click: this.clicarNoIcone,
			element: 'body',
			scope: this
		});
	},
	
	clicarNoIcone: function() {
		if (this.getJanelaCaixa() == undefined) {
			Ext.widget('janelacaixa');
			var botaoCaixaDaBarraDeJanelas = Ext.widget('botaocaixadabarradejanelas');
			this.getBarraDeJanelas().add(botaoCaixaDaBarraDeJanelas);
			this.mostrarJanela();
		}
	},
	
	minimizarJanela: function() {
		this.getJanelaCaixa().hide();
	},
	
	mostrarJanela: function() {
		var janela = this.getJanelaCaixa();
		if (janela.isHidden()) {
			janela.show();
		} else {
			janela.hide();
		}
	},
	
	fecharJanela: function() {
		this.getBarraDeJanelas().remove('idBotaoCaixaDaBarraDeJanelas');
		this.getJanelaCaixa().destroy();
	}
});
