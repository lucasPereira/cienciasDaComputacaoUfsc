Ext.define('PP.view.torneio.ListaTorneios', {
	extend: 'Ext.grid.Panel',
	alias: 'widget.listatorneios',
	store: 'Torneios',
	boder: false,
	multiSelect: false,
	columns: [
		{
			header: 'Identificador',
			dataIndex: 'identificador',
			flex: 0
		},
		{
			header: 'Descrição',
			dataIndex: 'descricao',
			flex: 1
		},
		{
			header: 'Vagas',
			dataIndex: 'vagas',
			flex: 0
		},
		{
			header: 'Valor Da Entrada',
			dataIndex: 'entrada',
			flex: 0
		}
	],
	
	tbar: [
		{
			xtype: 'button',
			text: 'Atualizar',
			icon: 'recursos/imagens/atualizar.png',
			action: 'atualizarListaTorneios'
		},
		'->',
		'Para participar de um torneio dê dois cliques no torneio desejado.'
	]
});
