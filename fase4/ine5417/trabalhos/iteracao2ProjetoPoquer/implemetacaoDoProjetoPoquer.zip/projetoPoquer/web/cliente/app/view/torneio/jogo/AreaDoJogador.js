Ext.define('PP.view.torneio.jogo.AreaDoJogador', {
	extend: 'Ext.form.Panel',
	alias: 'widget.areadojogador',
	width: 150,
	height: 90,
	border: true,
	collapsible: true,
	layout: {
        type: 'vbox',
        align: 'center'
    },
	config: {
		id: 'areadojogador',
		x: 0,
		y: 0
	},
	items: [
		{
            xtype: 'displayfield',
            width: 150,
            formItemCls: 'dadoDoJogadorNoTorneioImpar',
            fieldCls: 'fichasDoJogadorNoTorneio',
            name: 'fichas',
            fieldLabel: '',
            value: ' ',
            flex: 1
        },
        {
            xtype: 'displayfield',
            width: 150,
            formItemCls: 'dadoDoJogadorNoTorneioPar',
            fieldCls: 'estadoDoJogadorNoTorneio',
            name: 'estado',
            fieldLabel: '',
            value: ' ',
            flex: 1
        },
        {
            xtype: 'displayfield',
            width: 150,
            formItemCls: 'dadoDoJogadorNoTorneioImpar',
            fieldCls: 'fichasNaMesaDoJogadorNoTorneio',
            name: 'fichasNaMesa',
            fieldLabel: '',
            value: ' ',
            flex: 1
        }
	],
	
	constructor: function(configuração) {
		this.initConfig(configuração);
		this.callParent();
		
		return this;
	}
});
