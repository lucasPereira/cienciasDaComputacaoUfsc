Ext.define('PP.view.Principal', {
	extend: 'Ext.panel.Panel',
	alias: 'widget.principal',
	autoShow: true,
	requires: [
		'PP.view.BarraDeJanelas',
		'PP.view.regras.IconeRegras',
		'PP.view.torneio.IconeTorneios',
		'PP.view.caixa.IconeCaixa'
	],
	bodyCls: 'principal',
	items: [
		{
			xtype: 'iconetorneios'
		},
		{
			xtype: 'iconeregras'
		},
		{
			xtype: 'iconecaixa'
		}
	],
	dockedItems: [
		{
			xtype: 'barradejanelas',
			dock: 'bottom'
		}
	]
});
