Ext.define('PP.view.torneio.jogo.AreaDeInformacoes', {
	extend: 'Ext.form.Panel',
	alias: 'widget.areadeinformacoes',
	width: 375,
	height: 90,
	frame: false,
	border: false,
	layout: {
        type: 'vbox',
        align: 'stretch'
    },
	config: {
		x: 0,
		y: 0
	},
	items: [
		{
            xtype: 'displayfield',
            baseCls: 'dadoDaRodadaNoTorneio',
            formItemCls: 'dadoDaRodadaNoTorneioImpar',
            baseBodyCls: 'dadoDaRodadaNoTorneioValor',
            name: 'pote',
            fieldLabel: 'Pote',
            value: '1500',
            flex: 1
        },
        {
            xtype: 'displayfield',
            baseCls: 'dadoDaRodadaNoTorneio',
            formItemCls: 'dadoDaRodadaNoTorneioPar',
            baseBodyCls: 'dadoDaRodadaNoTorneioValor',
            name: 'jogadorDaVez',
            fieldLabel: 'Jogador da vez',
            value: 'pslucasps',
            flex: 1
        },
        {
            xtype: 'displayfield',
            baseCls: 'dadoDaRodadaNoTorneio',
            formItemCls: 'dadoDaRodadaNoTorneioImpar',
            baseBodyCls: 'dadoDaRodadaNoTorneioValor',
            name: 'ultimaJogada',
            fieldLabel: 'Última jogada',
            value: 'Jacaré apostou 10',
            flex: 1
        },
        {
            xtype: 'displayfield',
            baseCls: 'dadoDaRodadaNoTorneio',
            formItemCls: 'dadoDaRodadaNoTorneioPar',
            baseBodyCls: 'dadoDaRodadaNoTorneioValor',
            name: 'blinds',
            fieldLabel: 'Blinds',
            value: '50/100',
            flex: 1
        }
   	],
	
	constructor: function(configuração) {
		this.initConfig(configuração);
		this.callParent();
		
		return this;
	},
});
