Ext.define('PP.view.regras.BotaoRegrasDaBarraDeJanelas', {
	extend: 'PP.view.BotaoDaBarraDeJanelas',
	alias: 'widget.botaoregrasdabarradejanelas',
	text: 'Regras',
	id: 'idBotaoRegrasDaBarraDeJanelas'
});
