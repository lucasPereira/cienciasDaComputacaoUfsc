package br.ufsc.es.projetoPoquer.recursos.torneio;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Post;

import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.JogadorFeijao;
import br.ufsc.es.projetoPoquer.modelo.resposta.RespostaDeJogada;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.TorneioFeijao;

public class RecursoPassoNoTorneio extends RecursoJogadaSemApostaAbstrata {
	
	@Post
	public JSONObject passar(JSONObject dados) throws JSONException {
		return realizarJogada(dados);
	}

	@Override
	protected RespostaDeJogada realizarJogadaConcreta(JogadorFeijao jogadorFeijão, TorneioFeijao torneioFeijão) {
		return Poquer.fornecerInstância().receberPasso(jogadorFeijão, torneioFeijão);
	}
}