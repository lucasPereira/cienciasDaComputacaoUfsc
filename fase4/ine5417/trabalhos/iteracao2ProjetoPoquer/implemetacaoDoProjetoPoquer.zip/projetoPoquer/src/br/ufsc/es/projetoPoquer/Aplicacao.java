package br.ufsc.es.projetoPoquer;

import org.restlet.Application;
import org.restlet.Restlet;
import org.restlet.routing.Router;

import br.ufsc.es.projetoPoquer.recursos.administrador.RecursoAutenticacaoAdministrador;
import br.ufsc.es.projetoPoquer.recursos.jogador.RecursoAutenticacaoJogador;
import br.ufsc.es.projetoPoquer.recursos.jogador.RecursoJogadores;
import br.ufsc.es.projetoPoquer.recursos.mantenedor.RecursoAutenticacaoMantenedor;
import br.ufsc.es.projetoPoquer.recursos.mantenedor.RecursoMantenedores;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoAumentoNoTorneio;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoDesistenciaNoTorneio;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoInscricaoNoTorneio;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoPagamentoNoTorneio;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoPassoNoTorneio;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoTorneioCompleto;
import br.ufsc.es.projetoPoquer.recursos.torneio.RecursoTorneios;

public class Aplicacao extends Application {
	
	@Override
	public Restlet createInboundRoot() {
		Router roteador = new Router(getContext());
		roteador.attach("/jogadores", RecursoJogadores.class);
		roteador.attach("/jogadores/{nomeDeUsuario}", RecursoJogadores.class);
		roteador.attach("/jogadores/{nomeDeUsuario}/autenticacao", RecursoAutenticacaoJogador.class);
		roteador.attach("/torneios", RecursoTorneios.class); 
		roteador.attach("/torneios/{identificador}", RecursoTorneios.class); 
		roteador.attach("/torneios/{identificador}/inscricao", RecursoInscricaoNoTorneio.class);
		roteador.attach("/torneios/{identificador}/aumento", RecursoAumentoNoTorneio.class);
		roteador.attach("/torneios/{identificador}/pagamento", RecursoPagamentoNoTorneio.class);
		roteador.attach("/torneios/{identificador}/passo", RecursoPassoNoTorneio.class);
		roteador.attach("/torneios/{identificador}/desistencia", RecursoDesistenciaNoTorneio.class);
		roteador.attach("/torneios/{identificador}/completo", RecursoTorneioCompleto.class);
		roteador.attach("/administrador/autenticacao", RecursoAutenticacaoAdministrador.class);
		roteador.attach("/mantenedores", RecursoMantenedores.class);
		roteador.attach("/mantenedores/{nomeDeMantenedor}", RecursoMantenedores.class);
		roteador.attach("/mantenedores/{nomeDeMantenedor}/autenticacao", RecursoAutenticacaoMantenedor.class);
		
		return roteador;
	}
}