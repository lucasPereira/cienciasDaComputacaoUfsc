package br.ufsc.es.projetoPoquer.recursos.mantenedor;

import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.bancoDeDados.BancoDeDados;
import br.ufsc.es.projetoPoquer.bancoDeDados.OperacaoDeDados;
import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.adminitracao.MantenedorFeijao;

public class RecursoMantenedores extends ServerResource {
	
	@Post
	public JSONObject adicionar(JSONObject dados) throws JSONException {
		MantenedorFeijao mantenedorFeijão = new MantenedorFeijao();
		JSONObject resposta = new JSONObject();
		try {
			mantenedorFeijão.fixarNomeDeMantenedor(getRequestAttributes().get("nomeDeMantenedor").toString());
			mantenedorFeijão.fixarEmail(dados.getString("email"));
			mantenedorFeijão.fixarSenha("mantenedor");
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
		}
		boolean administradorAutenticado = Poquer.fornecerInstância().autenticarAdministrador(dados.getString("senhaDoAdministrador"));
		OperacaoDeDados<MantenedorFeijao> operaçãoDeDados = BancoDeDados.fornecerInstância()
				.adicionarMantenedor(mantenedorFeijão);
		if (administradorAutenticado && operaçãoDeDados.sucesso()) {
			resposta.put("erro", false);
		} else {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", operaçãoDeDados.fornecerMensagemDeErro());
		}
		resposta.put("sucesso", true);
		
		return resposta;
	}
	
	@Get
	public JSONObject fornecerTodos() throws JSONException {
		JSONObject resposta = new JSONObject();
		OperacaoDeDados<MantenedorFeijao> operaçãoDeDados =  BancoDeDados.fornecerInstância().
				fornecerMantenedores();
		resposta.put("sucesso", operaçãoDeDados.sucesso());
		JSONArray mantenedores = new JSONArray();
		if (operaçãoDeDados.sucesso()) {
			List<MantenedorFeijao> mantenedoresFeijão = operaçãoDeDados.fornecerConsultas();
			for (MantenedorFeijao  mantenedorFeijão : mantenedoresFeijão) {
				JSONObject mantenedor = new JSONObject();
				mantenedor.put("nomeDeMantenedor", mantenedorFeijão.fornecerNomeDeMantenedor());
				mantenedor.put("email", mantenedorFeijão.fornecerEmail());
				mantenedores.put(mantenedor);
			}
			resposta.put("mantenedores", mantenedores);
		}
		
		return resposta;
	}
	
	@Delete
	public JSONObject remover(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		boolean sucessoNaAutenticacao = Poquer.fornecerInstância().autenticarAdministrador(dados.getString("senhaDoAdministrador"));
		boolean erroDeRemoção = true;
		if (sucessoNaAutenticacao) {
			erroDeRemoção = !BancoDeDados.fornecerInstância().removerMantenedor(getRequestAttributes().get("nomeDeMantenedor").toString()).sucesso();
		}
		resposta.put("sucesso", sucessoNaAutenticacao && !erroDeRemoção);
		
		return resposta;
	}
}
