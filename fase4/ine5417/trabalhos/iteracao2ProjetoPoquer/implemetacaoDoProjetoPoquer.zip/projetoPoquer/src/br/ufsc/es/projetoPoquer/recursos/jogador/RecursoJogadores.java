package br.ufsc.es.projetoPoquer.recursos.jogador;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.Put;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.bancoDeDados.BancoDeDados;
import br.ufsc.es.projetoPoquer.bancoDeDados.OperacaoDeDados;
import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.ChaveDeSecao;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.NomeDeUsuario;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.Email;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.JogadorFeijao;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.Nome;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.Senha;

public class RecursoJogadores extends ServerResource {
	
	@Post
	public JSONObject adicionar(JSONObject dados) throws JSONException {
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		JSONObject resposta = new JSONObject();
		try {
			jogadorFeijão.fixarNome(new Nome(dados.getString("nome")));
			jogadorFeijão.fixarNomeDeUsuário(new NomeDeUsuario(dados.getString("nomeDeUsuario")));
			jogadorFeijão.fixarEmail(new Email(dados.getString("email")));
			jogadorFeijão.fixarSenha(new Senha(dados.getString("senha")));
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
		}
		OperacaoDeDados<JogadorFeijao> operaçãoDeDados = BancoDeDados.fornecerInstância().adicionarJogador(jogadorFeijão);
		if (operaçãoDeDados.sucesso()) {
			resposta.put("erro", false);
		} else {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", operaçãoDeDados.fornecerMensagemDeErro());
		}
		resposta.put("sucesso", true);
		
		return resposta;
	}
	
	@Put
	public JSONObject atualizar(JSONObject dados) throws JSONException {
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		JSONObject resposta = new JSONObject();
		try {
			jogadorFeijão.fixarNome(new Nome(dados.getString("nome")));
			jogadorFeijão.fixarNomeDeUsuário(new NomeDeUsuario(getRequestAttributes().get("nomeDeUsuario").toString()));
			jogadorFeijão.fixarEmail(new Email(dados.getString("email")));
			jogadorFeijão.fixarSenha(new Senha(dados.getString("senha")));
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
		}
		jogadorFeijão.fornecerNome().fornecerComoTexto();
		OperacaoDeDados<JogadorFeijao> operaçãoDeDados = BancoDeDados.fornecerInstância().atualizarJogador(jogadorFeijão);
		if (operaçãoDeDados.sucesso()) {
			resposta.put("erro", false);
		} else {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", operaçãoDeDados.fornecerMensagemDeErro());
		}
		resposta.put("sucesso", true);
		
		return resposta;
	}
	
	@Get
	public JSONObject fornecer() throws JSONException {
		JSONObject resposta = new JSONObject();
		OperacaoDeDados<JogadorFeijao> operaçãoDeDados =  BancoDeDados.fornecerInstância().
				fornecerJogador(new NomeDeUsuario(getRequestAttributes().get("nomeDeUsuario").toString()));
		resposta.put("sucesso", operaçãoDeDados.sucesso());
		if (operaçãoDeDados.sucesso()) {
			JSONObject jogador = new JSONObject();
			JogadorFeijao jogadorFeijão = operaçãoDeDados.fornecerConsulta();
			jogador.put("nome", jogadorFeijão.fornecerNome().fornecerComoTexto());
			jogador.put("email", jogadorFeijão.fornecerEmail().fornecerComoTexto());
			resposta.put("jogador", jogador);
		}
		
		return resposta;
	}
	
	@Delete
	public JSONObject remover(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		NomeDeUsuario nomeDeUsuário = new NomeDeUsuario(getRequestAttributes().get("nomeDeUsuario").toString());
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		jogadorFeijão.fixarNomeDeUsuário(nomeDeUsuário);
		jogadorFeijão.fixarChaveDeSeção(new ChaveDeSecao(dados.getString("chaveDeSecao")));
		boolean erroDeAutenticação = Poquer.fornecerInstância().autenticarJogador(jogadorFeijão).possuiErro();
		boolean erroDeRemoção = false;
		if (!erroDeAutenticação) {
			erroDeRemoção = !BancoDeDados.fornecerInstância().removerJogador(nomeDeUsuário).sucesso();
		}
		resposta.put("sucesso", !erroDeRemoção && !erroDeAutenticação);
		
		return resposta;
	}
}