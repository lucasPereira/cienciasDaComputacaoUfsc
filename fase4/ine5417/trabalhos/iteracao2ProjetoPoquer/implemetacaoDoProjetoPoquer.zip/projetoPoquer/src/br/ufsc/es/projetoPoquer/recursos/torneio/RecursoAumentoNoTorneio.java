package br.ufsc.es.projetoPoquer.recursos.torneio;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.ChaveDeSecao;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.NomeDeUsuario;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.JogadorFeijao;
import br.ufsc.es.projetoPoquer.modelo.resposta.RespostaDeJogada;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.Identificador;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.TorneioFeijao;
import br.ufsc.es.projetoPoquer.modelo.torneio.torneioDeUmaMesa.rodada.jogo.Aposta;

public class RecursoAumentoNoTorneio extends ServerResource {
	
	@Post
	public JSONObject aumentar(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		jogadorFeijão.fixarNomeDeUsuário(new NomeDeUsuario(dados.getString("nomeDeUsuario")));
		jogadorFeijão.fixarChaveDeSeção(new ChaveDeSecao(dados.getString("chaveDeSecao")));
		TorneioFeijao torneioFeijão = new TorneioFeijao();
		int identificador;
		try {
			identificador = Integer.parseInt(getRequestAttributes().get("identificador").toString());
		} catch (NumberFormatException erro) {
			resposta.put("sucesso", false);
			return resposta;
		}
		torneioFeijão.fixarIdentificador(new Identificador(identificador));
		Aposta aposta = new Aposta(dados.getInt("aumento")); 
		RespostaDeJogada respostaDeJogada = Poquer.fornecerInstância().receberAumento(jogadorFeijão, torneioFeijão, aposta);
		if (respostaDeJogada == null) {
			resposta.put("sucesso", false);
			return resposta;
		}
		if (respostaDeJogada.possuiErro()) {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", respostaDeJogada.fornecerMensagemDeErro());
		} else {
			resposta.put("erro", false);
		}
		
		return resposta;
	}
}
