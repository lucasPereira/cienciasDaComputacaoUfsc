package br.ufsc.es.projetoPoquer.recursos.torneio;

import java.util.Collection;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Delete;
import org.restlet.resource.Get;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.bancoDeDados.BancoDeDados;
import br.ufsc.es.projetoPoquer.bancoDeDados.OperacaoDeDados;
import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.adminitracao.MantenedorFeijao;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.Descricao;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.QuantidadeDeVagas;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.TorneioFeijao;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.ValorDaEntrada;

public final class RecursoTorneios extends ServerResource {
	
	@Get
	public JSONObject fornecerTodos() throws JSONException {
		JSONObject torneios = new JSONObject();
		JSONArray torneiosArray = new JSONArray();
		Collection<TorneioFeijao> torneiosFeijão = BancoDeDados.fornecerInstância().fornecerTorneios().fornecerConsultas();
		for (TorneioFeijao torneioFeijão : torneiosFeijão) {
			JSONObject torneio = new JSONObject();
			torneio.put("identificador", torneioFeijão.fornecerIdentificador().fornecerComoNúmero());
			torneio.put("descricao", torneioFeijão.fornecerDescrição().fornecerComoTexto());
			torneio.put("entrada", torneioFeijão.fornecerValorDaEntrada().fornecerComoNúmero());
			torneio.put("vagas", torneioFeijão.fornecerQuantidadeDeVagas().fornecerComoTexto());
			torneio.put("mantenedorCriador", torneioFeijão.fornecerMantenedorCriador().fornecerNomeDeMantenedor());
			torneiosArray.put(torneio);
		}
		torneios.put("torneios", torneiosArray);
		torneios.put("sucesso", true);
		
		return torneios;
	}
	
	@Post
	public JSONObject adicionar(JSONObject dados) throws JSONException {
		TorneioFeijao torneioFeijão = new TorneioFeijao();
		JSONObject resposta = new JSONObject();
		try {
			MantenedorFeijao mantenedorCriador = new MantenedorFeijao();
			mantenedorCriador.fixarNomeDeMantenedor(dados.getString(("nomeDeMantenedor")));
			torneioFeijão.fixarMantenedorCriador(mantenedorCriador);
			torneioFeijão.fixarDescricao(new Descricao(dados.getString("descricao")));
			torneioFeijão.fixarQuantidadeDeVagas(new QuantidadeDeVagas(dados.getInt("vagas"), dados.getInt("vagas")));
			torneioFeijão.fixarValorDaEntrada(new ValorDaEntrada(dados.getInt("entrada")));
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
		}
		boolean mantenedorAutenticado = Poquer.fornecerInstância().autenticarMantenedor(dados.getString("nomeDeMantenedor"), dados.getString("senhaDoMantenedor"));
		OperacaoDeDados<TorneioFeijao> operaçãoDeDados = BancoDeDados.fornecerInstância()
				.adicionarTorneio(torneioFeijão);
		if (mantenedorAutenticado && operaçãoDeDados.sucesso()) {
			Poquer.fornecerInstância().abrirTorneio(torneioFeijão);
			resposta.put("erro", false);
		} else {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", operaçãoDeDados.fornecerMensagemDeErro());
		}
		resposta.put("sucesso", true);
		
		return resposta;
	}
	
	@Delete
	public JSONObject remover(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		boolean sucessoNaAutenticacao = Poquer.fornecerInstância().autenticarMantenedor(dados.getString("nomeDeMantenedor"), dados.getString("senhaDoMantenedor"));
		boolean erroDeRemoção = true;
		if (sucessoNaAutenticacao) {
			erroDeRemoção = !BancoDeDados.fornecerInstância().removerTorneio(getRequestAttributes().get("identificador").toString()).sucesso();
		}
		resposta.put("sucesso", sucessoNaAutenticacao && !erroDeRemoção);
		
		return resposta;
	}
}