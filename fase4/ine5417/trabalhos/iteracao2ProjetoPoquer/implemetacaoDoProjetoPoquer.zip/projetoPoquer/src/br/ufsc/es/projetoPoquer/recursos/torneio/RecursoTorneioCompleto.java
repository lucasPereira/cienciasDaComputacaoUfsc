package br.ufsc.es.projetoPoquer.recursos.torneio;

import java.util.Collection;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.ChaveDeSecao;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.NomeDeUsuario;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.JogadorFeijao;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.Identificador;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.JogadorFeijaoEmTorneio;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.TorneioFeijao;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.TorneioFeijaoCompleto;
import br.ufsc.es.projetoPoquer.modelo.torneio.torneioDeUmaMesa.rodada.dados.feijao.JogadorFeijaoEmRodada;
import br.ufsc.es.projetoPoquer.modelo.torneio.torneioDeUmaMesa.rodada.dados.feijao.RodadaFeijao;
import br.ufsc.es.projetoPoquer.modelo.torneio.torneioDeUmaMesa.rodada.jogo.dados.feijao.AcoesPossiveisFeijaoDoJogador;
import br.ufsc.es.projetoPoquer.modelo.torneio.torneioDeUmaMesa.rodada.jogo.dados.feijao.CartaFeijao;

public class RecursoTorneioCompleto extends ServerResource {
	
	@Post
	public JSONObject fornecer(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		jogadorFeijão.fixarNomeDeUsuário(new NomeDeUsuario(dados.getString("nomeDeUsuario")));
		jogadorFeijão.fixarChaveDeSeção(new ChaveDeSecao(dados.getString("chaveDeSecao")));
		TorneioFeijao torneioFeijão = new TorneioFeijao();
		torneioFeijão.fixarIdentificador(new Identificador(Integer
				.parseInt(getRequestAttributes().get("identificador").toString())));
		TorneioFeijaoCompleto torneioFeijãoCompleto = Poquer.fornecerInstância()
				.fornecerTorneioFeijãoCompleto(jogadorFeijão, torneioFeijão);
		if (torneioFeijãoCompleto == null) {
			return resposta.put("sucesso", false);
		}
		JSONArray jogadores = fornecerJogadores(torneioFeijãoCompleto.fornecerJogadoresFeijãoEmTorneio());
		JSONObject rodada = fornecerRodada(torneioFeijãoCompleto.fornecerRodadaFeijão());
		JSONObject jogador = fornecerJogador(torneioFeijãoCompleto.fornecerJogadorFeijãoEmRodada());
		resposta.put("jogadores", jogadores);
		resposta.put("rodada", rodada);
		resposta.put("jogador", jogador);
		resposta.put("posicaoDoDealer", torneioFeijãoCompleto.fornecerPosiçãoDoDealerNaMesa().fornecerComoNúmero());
		
		return resposta;
	}
	
	private JSONArray fornecerJogadores(Collection<JogadorFeijaoEmTorneio> jogadoresFeijãoEmTorneio) throws JSONException {
		JSONArray jogadores = new JSONArray();
		for (JogadorFeijaoEmTorneio jogadorFeijãoEmTorneio : jogadoresFeijãoEmTorneio) {
			JSONObject jogador = new JSONObject();
			jogador.put("nomeDeUsuario", jogadorFeijãoEmTorneio.fornecerNomeDeUsuário().fornecerComoTexto());
			jogador.put("posicaoNaMesa", jogadorFeijãoEmTorneio.fornecerPosiçãoDoJogadorNaMesa()
					.fornecerComoNúmero());
			jogador.put("fichas", jogadorFeijãoEmTorneio.fornecerQuantidadeDeFichas().fornecerComoNúmero());
			jogador.put("fichasNaMesa", jogadorFeijãoEmTorneio.fornecerQuantidadeDeFichasNaMesa()
					.fornecerComoNúmero());
			jogador.put("estado", jogadorFeijãoEmTorneio.fornecerEstadoDoJogador().fornecerComoTexto());
			jogadores.put(jogador);
		}
		
		return jogadores;
	}
	
	private JSONObject fornecerRodada(RodadaFeijao rodadaFeijão) throws JSONException {
		JSONObject rodada = new JSONObject();
		rodada.put("jogadorDaVez", rodadaFeijão.fornecerJogadorDaVez().fornecerNomeDeUsuário().fornecerComoTexto());
		rodada.put("pote", rodadaFeijão.fornecerValorDoPote().fornecerComoNúmero());
		rodada.put("ultimaJogada", rodadaFeijão.fornecerÚltimaJogada().fornecerComoTexto());
		rodada.put("blinds", rodadaFeijão.fornecerBlinds().fornecerComoTexto());
		rodada.put("vencedores", rodadaFeijão.fornecerVencedores());
		JSONArray cartasDaMesa = new JSONArray();
		for (CartaFeijao cartaFejão : rodadaFeijão.fornecerCartasFeijão()) {
			cartasDaMesa.put(cartaFejão.fornecerComoTexto());
		}
		rodada.put("cartasDaMesa", cartasDaMesa); 
		
		return rodada;
	}
	
	private JSONObject fornecerJogador(JogadorFeijaoEmRodada jogadorFeijãoEmRodada) throws JSONException {
		JSONObject jogador = new JSONObject();
		JSONObject açõesPossíveis = new JSONObject();
		AcoesPossiveisFeijaoDoJogador açõesPossíveisFeijãoDoJogador = jogadorFeijãoEmRodada
				.fornecerAçõesPossíveisFeijãoDoJogador();
		açõesPossíveis.put("estaNaVez", açõesPossíveisFeijãoDoJogador.estáNaVez());
		if (açõesPossíveisFeijãoDoJogador.estáNaVez()) {
			açõesPossíveis.put("podeAumentar", açõesPossíveisFeijãoDoJogador.podeAumentar());
			açõesPossíveis.put("podeDesistir",açõesPossíveisFeijãoDoJogador.podeDeisitir());
			açõesPossíveis.put("podePassar", açõesPossíveisFeijãoDoJogador.podePassar());
			açõesPossíveis.put("podePagar", açõesPossíveisFeijãoDoJogador.podePagar());
			açõesPossíveis.put("apostaMinima", açõesPossíveisFeijãoDoJogador.fornecerApostaMínima()
					.fornecerComoNúmero());
			açõesPossíveis.put("apostaMaxima", açõesPossíveisFeijãoDoJogador.fornecerApostaMáxima()
					.fornecerComoNúmero());
		}
		jogador.put("acoesPossiveis", açõesPossíveis);
		JSONArray cartas = new JSONArray();
		List<CartaFeijao> cartasFeijão = jogadorFeijãoEmRodada.fornecerCartasFeijão();
		if (cartasFeijão != null) {
			for (CartaFeijao cartaFeijão : cartasFeijão) {
				cartas.put(cartaFeijão.fornecerComoTexto());
			}
		}
		jogador.put("cartas", cartas);
		
		return jogador;
	}
}