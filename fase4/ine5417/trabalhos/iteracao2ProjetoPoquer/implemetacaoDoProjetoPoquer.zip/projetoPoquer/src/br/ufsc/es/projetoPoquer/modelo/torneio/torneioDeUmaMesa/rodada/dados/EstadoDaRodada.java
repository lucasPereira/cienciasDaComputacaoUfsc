package br.ufsc.es.projetoPoquer.modelo.torneio.torneioDeUmaMesa.rodada.dados;

public enum EstadoDaRodada {
	
	NÃO_INICIADA,
	PRÉ_FLOP,
	FLOP,
	PRÉ_TURN,
	TURN,
	PRÉ_RIVER,
	RIVER,
	PRÉ_SHOWDOWN,
	SHOW_DOWN,
	TERMINADA;
}