package br.ufsc.es.projetoPoquer.recursos.administrador;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.modelo.Poquer;

public class RecursoAutenticacaoAdministrador extends ServerResource {
	
	@Post
	public JSONObject autenticar(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		try {
			boolean autenticado = Poquer.fornecerInstância().autenticarAdministrador(dados.getString("senha"));
			if (!autenticado) {
				resposta.put("erro", true);
				resposta.put("mensagemDeErro", "Senha inválida.");
			} else {
				resposta.put("erro", false);
			}
			resposta.put("sucesso", true);
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
		}
		
		return resposta;
	}
}
