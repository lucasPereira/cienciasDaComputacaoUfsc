package br.ufsc.es.projetoPoquer.recursos.torneio;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.ChaveDeSecao;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.NomeDeUsuario;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.JogadorFeijao;
import br.ufsc.es.projetoPoquer.modelo.resposta.RespostaDeInscricaoNoTorneio;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.Identificador;
import br.ufsc.es.projetoPoquer.modelo.torneio.dados.feijao.TorneioFeijao;

public class RecursoInscricaoNoTorneio extends ServerResource {
	
	@Post
	public JSONObject inscrever(JSONObject dados) throws JSONException {
		JSONObject resposta = new JSONObject();
		int identificador;
		try {
			identificador = Integer.parseInt(getRequestAttributes().get("identificador").toString());
		} catch (NumberFormatException erro) {
			resposta.put("sucesso", false);
			return resposta;
		}
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		TorneioFeijao torneioFeijão = new TorneioFeijao();
		try {
			jogadorFeijão.fixarNomeDeUsuário(new NomeDeUsuario(dados.getString("nomeDeUsuario")));
			jogadorFeijão.fixarChaveDeSeção(new ChaveDeSecao(dados.getString("chaveDeSecao")));
			torneioFeijão.fixarIdentificador(new Identificador(identificador));
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
			return resposta;
		}
		RespostaDeInscricaoNoTorneio respostaDeIsncriçãoNoTorneio = Poquer.fornecerInstância()
				.inscreverJogadorNoTorneio(jogadorFeijão, torneioFeijão);
		if (respostaDeIsncriçãoNoTorneio.possuiErro()) {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", respostaDeIsncriçãoNoTorneio.fornecerMensagemDeErro());
		} else {
			resposta.put("erro", false);
		}
		resposta.put("sucesso", true);
		
		return resposta;
	}
}