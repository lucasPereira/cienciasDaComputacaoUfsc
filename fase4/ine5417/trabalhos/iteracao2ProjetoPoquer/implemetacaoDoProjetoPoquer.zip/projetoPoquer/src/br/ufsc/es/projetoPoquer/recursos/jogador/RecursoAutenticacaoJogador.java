package br.ufsc.es.projetoPoquer.recursos.jogador;

import org.json.JSONException;
import org.json.JSONObject;
import org.restlet.resource.Post;
import org.restlet.resource.ServerResource;

import br.ufsc.es.projetoPoquer.modelo.Poquer;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.NomeDeUsuario;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.JogadorFeijao;
import br.ufsc.es.projetoPoquer.modelo.jogador.dados.feijao.Senha;
import br.ufsc.es.projetoPoquer.modelo.resposta.RespostaDeAutenticacao;

public class RecursoAutenticacaoJogador extends ServerResource {
	
	@Post
	public JSONObject autenticar(JSONObject dados) throws JSONException {
		NomeDeUsuario nomeDeUsuário = new NomeDeUsuario(getRequestAttributes().get("nomeDeUsuario").toString());
		JSONObject resposta = new JSONObject();
		JogadorFeijao jogadorFeijão = new JogadorFeijao();
		try {
			jogadorFeijão.fixarSenha(new Senha(dados.getString("senha")));
		} catch (JSONException erro) {
			resposta.put("sucesso", false);
			return resposta;
		}
		jogadorFeijão.fixarNomeDeUsuário(nomeDeUsuário);		
		RespostaDeAutenticacao respostaDeAutenticação = Poquer.fornecerInstância().autenticarJogador(jogadorFeijão);
		if (respostaDeAutenticação.possuiErro()) {
			resposta.put("erro", true);
			resposta.put("mensagemDeErro", respostaDeAutenticação.fornecerMensagemDeErro());
		} else {
			resposta.put("erro", false);
			resposta.put("chaveDeSecao", respostaDeAutenticação.fornecerChaveDeSecao().fornecerComoTexto());
		}
		resposta.put("sucesso", true);
		
		return resposta;
	}
}