package br.ufsc.es.projetoPoquer.modelo.torneio.dados;

public enum EstadoDoTorneio {
	
	NÃO_INICIADO,
	INICIADO,
	FINALIZADO;
}
