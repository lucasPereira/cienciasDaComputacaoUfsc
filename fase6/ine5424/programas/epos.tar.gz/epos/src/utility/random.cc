#include <utility/random.h>

__BEGIN_SYS

unsigned long int Pseudo_Random::_seed;

__END_SYS
