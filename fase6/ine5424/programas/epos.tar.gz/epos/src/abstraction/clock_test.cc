// EPOS Clock Abstraction Test Program

#include <utility/ostream.h>
#include <clock.h>

__USING_SYS;

int main()
{
    OStream cout;

    cout << "Clock test\n";

    Clock timepiece;

    return 0;
}
