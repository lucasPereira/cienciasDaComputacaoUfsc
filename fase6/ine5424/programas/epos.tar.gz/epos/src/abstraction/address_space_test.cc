// EPOS Address Space Test Program

#include <utility/ostream.h>
#include <address_space.h>

__USING_SYS

int main()
{
    OStream cout;

    cout << "Address Space test\n";

    return 0;
}
