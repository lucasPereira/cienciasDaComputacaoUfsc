// EPOS IA32_MMU Test Program

#include <utility/ostream.h>
#include <mmu.h>

using namespace System;

int main()
{
    OStream cout;

    cout << "IA32_MMU test\n";

    IA32_MMU mmu;

    return 0;
}
