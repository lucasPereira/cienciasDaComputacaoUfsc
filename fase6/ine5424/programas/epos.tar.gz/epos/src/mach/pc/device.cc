// EPOS PC Device Common Package Implementation

#include <mach/pc/machine.h>
#include <mach/pc/device.h>

__BEGIN_SYS

// Class attributes
PC_Device::List PC_Device::_devices;

__END_SYS

