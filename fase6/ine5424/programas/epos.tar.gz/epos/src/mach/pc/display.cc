// EPOS PC Display Mediator Implementation

#include <display.h>

__BEGIN_SYS

// Class attributes
PC_Display::Frame_Buffer PC_Display::_frame_buffer;

__END_SYS
