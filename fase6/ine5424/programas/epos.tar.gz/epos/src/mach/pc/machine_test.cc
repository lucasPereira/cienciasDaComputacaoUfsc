// EPOS PC Test Program

#include <utility/ostream.h>
#include <machine.h>

__USING_SYS

int main()
{
    OStream cout;

    cout << "PC test\n";

    PC machine;

    return 0;
}
