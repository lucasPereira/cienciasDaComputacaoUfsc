// EPOS PC Display Mediator Test Program

#include <utility/ostream.h>
#include <display.h>

__USING_SYS

int main()
{
    OStream cout;

    cout << "PC_Display test\n";

    PC_Display display;

    return 0;
}
