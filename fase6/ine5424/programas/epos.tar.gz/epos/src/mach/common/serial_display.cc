// EPOS Serial Display Mediator Implementation

#include <display.h>

__BEGIN_SYS

// Class attributes
UART Serial_Display::_uart;
int Serial_Display::_line;
int Serial_Display::_column;

__END_SYS
