// EPOS Radio Mediator Common Package Implementation

#include <radio.h>

__BEGIN_SYS

const Radio_Common::Address Radio_Common::BROADCAST(0xffff);

__END_SYS

