#include <machine.h>

#ifdef __neighborhood_h

__BEGIN_SYS

Neighborhood * Neighborhood::_instance = 0;

__END_SYS

#endif

