// EPOS UART Mediator Common Package

#ifndef __uart_h
#define __uart_h

#include <system/config.h>

__BEGIN_SYS

class UART_Common
{
protected:
    UART_Common() {}
};

__END_SYS

#ifdef __UART_H
#include __UART_H
#endif

#endif
