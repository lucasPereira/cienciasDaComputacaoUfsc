// EPOS Battery Mediator Common Package

#ifndef __battery_h
#define __battery_h

#include <system/config.h>

__BEGIN_SYS

class Battery_Common
{
protected:
    Battery_Common() {}
};

__END_SYS

#ifdef __BATTERY_H
#include __BATTERY_H
#endif

#endif
