// EPOS PMU Mediator Common Package

#ifndef __pmu_h
#define __pmu_h

#include <system/config.h>

__BEGIN_SYS

class PMU_Common
{
protected:
    PMU_Common() {}

};

__END_SYS

#ifdef __PMU_H
#include __PMU_H
#endif

#endif