// EPOS USART Mediator Common Package

#ifndef __usart_h
#define __usart_h

#include <system/config.h>

__BEGIN_SYS

class USART_Common
{
protected:
    USART_Common() {}
};

__END_SYS

#ifdef __USART_H
#include __USART_H
#endif

#endif
