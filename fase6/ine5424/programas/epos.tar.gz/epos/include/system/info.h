// EPOS Run-Time System Information

#ifndef __info_h
#define __info_h

#include <system/config.h>

__BEGIN_SYS

template <class Machine>
struct System_Info {};

__END_SYS

#include __HEADER_MACH(info)

#endif
