function (chaves, valores, rereduce) {
	if (rereduce) {
		return sum(valores);
	} else {
		return valores.length;
	}
}
