function (documento) {
	if (documento.tipo === "time") {
		emit(documento._id, [documento.nome, documento.dataDeFundacao]);
	}
}
