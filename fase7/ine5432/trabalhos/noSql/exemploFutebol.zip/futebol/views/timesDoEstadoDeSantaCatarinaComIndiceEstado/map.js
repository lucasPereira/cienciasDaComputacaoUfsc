function (documento) {
	if (documento.tipo === "time") {
		emit(documento.estado, documento.nome);
	}
}
