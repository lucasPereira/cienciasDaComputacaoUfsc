function (documento) {
	if (documento.tipo === "time") {
		if (documento.estado === "SC") {
			emit(documento._id, [documento.nome]);
		}
	}
}
