function (documento) {
	if (documento.tipo === "time") {
		emit(documento.capacidadeDoEstadio, [documento.nome, documento.capacidadeDoEstadio]);
	}
}
