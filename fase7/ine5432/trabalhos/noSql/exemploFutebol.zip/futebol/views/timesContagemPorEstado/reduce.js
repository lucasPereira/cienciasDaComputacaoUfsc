function (chaves, valores, rereduce) {
	return valores.length;
}
