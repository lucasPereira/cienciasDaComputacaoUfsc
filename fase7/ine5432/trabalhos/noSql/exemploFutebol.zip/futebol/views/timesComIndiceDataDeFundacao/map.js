function (documento) {
	if (documento.tipo === "time") {
		emit(documento.dataDeFundacao, documento.nome);
	}
}
