function (chaves, valores, rereduce) {
	var maximo = -Infinity;
	for (var indice in valores) {
		var valor = valores[indice];
		if (valor > maximo) {
			maximo = valor;
		}
	}
	return maximo;
}
