function (documento) {
	if (documento.tipo === "time" && documento.identificadorDosJogadores) {
		var jogadores = documento.identificadorDosJogadores;
		for (var indice in jogadores) {
			emit([jogadores[indice], 0], documento.nome);
		}
	} else if (documento.tipo === "jogador") {
		emit([documento._id, 1], documento.nome);
	}
}
