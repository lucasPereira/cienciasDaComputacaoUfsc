function (documento) {
	if (documento.tipo === "time") {
		emit([documento._id, 0], documento.nome);
	} else if (documento.tipo === "jogador") {
		emit([documento.identificadorDoTime, 1], documento.nome);
	}
}
