function (documento) {
	if (documento.tipo === "time") {
		var nomes = documento.nome.split(" ");
		for (var indice in nomes) {
			emit(nomes[indice], documento.nome);
		}
	}
}
