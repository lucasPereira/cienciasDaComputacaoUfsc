(function () {
	"user strict";

	function inicializar() {
		popularJogadores();
		console.log("Documentos populados.");
	}

	function popularTimes() {
		var requisicaoDeTimes = new RequisicaoJson("json/times.json");
		requisicaoDeTimes.fixarAtributoDeCabecalho(AtributoHttp.ACCEPT, TipoDeMidia.JSON.comoTexto());
		var times = requisicaoDeTimes.enviarGet(false);
		times.paraCada(function (time) {
			var requisicaoDeCriacaoDeTime = new RequisicaoJson("/futebol");
			requisicaoDeCriacaoDeTime.fixarAtributoDeCabecalho(AtributoHttp.ACCEPT, TipoDeMidia.JSON.comoTexto());
			requisicaoDeCriacaoDeTime.fixarAtributoDeCabecalho(AtributoHttp.CONTENT_TYPE, TipoDeMidia.JSON.comoTexto());
			requisicaoDeCriacaoDeTime.enviarPost(JSON.stringify(time), true);
		});
	}

	function popularJogadores() {
		var requisicaoDeJogadores = new RequisicaoJson("json/jogadores.json");
		requisicaoDeJogadores.fixarAtributoDeCabecalho(AtributoHttp.ACCEPT, TipoDeMidia.JSON.comoTexto());
		var times = requisicaoDeJogadores.enviarGet(false);
		times.paraCada(function (jogador) {
			var requisicaoDeCriacaoDeJogador = new RequisicaoJson("/futebol");
			requisicaoDeCriacaoDeJogador.fixarAtributoDeCabecalho(AtributoHttp.ACCEPT, TipoDeMidia.JSON.comoTexto());
			requisicaoDeCriacaoDeJogador.fixarAtributoDeCabecalho(AtributoHttp.CONTENT_TYPE, TipoDeMidia.JSON.comoTexto());
			requisicaoDeCriacaoDeJogador.enviarPost(JSON.stringify(jogador), true);
		});
	}

	addEventListener("load", inicializar);
}());
