import jason.asSyntax.*;
import jason.environment.Environment;
import java.util.logging.Logger;

public class DummyEnv extends Environment {

	public static final Term    ac = Literal.parseLiteral("acao(qq)");
	public static final Literal per = Literal.parseLiteral("percepcaoQQ");
	private int veryDummy;
	private boolean dummy2;
	
	static Logger logger = Logger.getLogger(DummyEnv.class.getName());
	
	@Override
    public void init(String[] args) {
		dummy2 = true;
        updatePercepts();
    }
	
	@Override
    public boolean executeAction(String ag, Structure action) {
        logger.info(ag+" doing: "+ action);
        try {
			
			/*if (action.getFunctor().equals("acao")) {
				logger.info(ag+" really doing: "+ action);
				return true;
            }
			
            else*/ if (action.equals(ac)) {
                //model.nextSlot();
				
            } else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        updatePercepts();

        /*try {
            Thread.sleep(200);
        } catch (Exception e) {}*/
        return true;
    }
	
	void updatePercepts() {
        clearPercepts();
		if (dummy2){
			Literal p = Literal.parseLiteral("percepcao1");
			addPercept(p);
			dummy2 = false;
		}
		veryDummy++;
		Literal p = Literal.parseLiteral("percepcaoQQ(" + veryDummy + ")");
		
		addPercept(p);
        
    }

}
