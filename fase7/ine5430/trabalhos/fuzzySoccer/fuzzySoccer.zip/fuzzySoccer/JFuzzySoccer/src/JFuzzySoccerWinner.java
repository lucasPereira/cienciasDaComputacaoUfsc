
public class JFuzzySoccerWinner {

//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
	public enum Reg {
		E, F, D;
	}
	
	static Reg E = Reg.E;
	static Reg F = Reg.F;
	static Reg D = Reg.D;

	static Reg regras[][] = {{F,E,E},{D,F,E},{D,D,F}};
	
	static float abs(float a) { return a>0 ? a : -a; }
	static float min(float a, float b) { return a<b ? a : b; }
	static float med(float a, float b) { return a+b/2.0f; }
	static float max(float a, float b) { return a>b ? a : b; }
	static float fesq(float ang){
		if( ang > 0 )
			//return (ang / (float)Math.PI)*(ang / (float)Math.PI);
			return ang / (float)Math.PI;
		return 0;
	}
	static float ffrente(float ang){
		if( abs(ang) < (float)Math.PI/18 ) // 40 graus no total
			return ((float)Math.PI/18 - abs(ang)) / (float)(Math.PI/18); //[-30,30], com 1 no 0 graus
		return 0;
	}
	static float fdir(float ang){
		if( ang < 0 )
			return -ang / (float)Math.PI;
		return 0;
	}

	
	public static void control(float dist, float obstacleAngle, float ballAngle, float targetAngle, float controlAction[]) {

		System.out.println("Method inputs: ");
		System.out.println(ballAngle);
		System.out.println(targetAngle);
		System.out.println(" ");
		
		
        // A partir dos dados obtidos, deve inferir que ações executar. Neste
        // exemplo as forças destinadas a cada robô são guardadas em leftMotor e
        // rightMotor. Esta etapa deve ser substituida pelo controlador fuzzy.
	
		//Normalizando os angulos para [-180,180]
		if ( ballAngle <= - Math.PI ) {
			ballAngle += 2 * Math.PI;
		}
		if ( ballAngle > Math.PI ) {
			ballAngle -= 2 * Math.PI;
		}
		if ( targetAngle <= - Math.PI ) {
			targetAngle += 2 * Math.PI;
		}
		if ( targetAngle > Math.PI ) {
			targetAngle -= 2 * Math.PI;
		}
		
		//Fuzzificacao

		//Bola
		float bola[] = new float[3];
		bola[0] = fesq(ballAngle);
		bola[1] = ffrente(ballAngle);
		bola[2] = fdir(ballAngle);

		//Alvo
		float alvo[] = new float[3];
		alvo[0] =  fesq(targetAngle);
		alvo[1] =  ffrente(targetAngle);
		alvo[2] =  fdir(targetAngle);


		//Aplicacao das regras
		float saida[] = new float[3];
		for(int i = 0; i < 3; i++)
			saida[i] = 0;

		for(int i = 0; i < 3; i++){
			for(int j = 0; j < 3; j++){
				float unif = med(bola[i],alvo[j]); //aplicacao do E para unificacao dos resultados
				saida[regras[i][j].ordinal()] = max(saida[regras[i][j].ordinal()], unif); //a saida quanto ao movimento eh feita usando o OU
			}
		}

		//Defuzzificacao

		float minv,maxv,x,passo = (float)Math.PI/360;
		float acumy = 0, acumxy = 0;
		for(x = -(float)Math.PI; x <= (float)Math.PI; x += passo){
			maxv = 0;
			minv = 100;
			for(int i=0; i<3; i++){
				switch (i){
				case 0:
					minv = min(saida[i],fesq(x));	
					break;	
				case 1:
					minv = min(saida[i],ffrente(x));	
					break;
				case 2:
					minv = min(saida[i],fdir(x));	
					break;
				}
				if(minv > maxv)
					maxv = minv;
			}
			acumy += maxv;
			acumxy += maxv * x;
		}

		float angDesejado = (acumxy / acumy);
		
		System.out.println("Angulo desejado de virada = " + (angDesejado*180)/(float)Math.PI );

		float leftMotor, rightMotor;
		leftMotor = (-angDesejado/((float)Math.PI*2)) + 0.5f;
		rightMotor = (angDesejado/((float)Math.PI*2)) + 0.5f;

		if(dist < 30 && abs(obstacleAngle) <= (float)Math.PI*50/180){
			leftMotor = -1;
			rightMotor = -1.5f;
		}
		//TODO

        // substituir até aqui
        
        
        // colocar no array para ser retornado por referencia
        	controlAction[0] = leftMotor;
        	controlAction[1] = rightMotor;
        
        // printar as saidas
		System.out.println("Method return: ");
		System.out.println(controlAction[0]);
		System.out.println(controlAction[1]);
		System.out.println(" ");

		
	}

}
