
public class JFuzzySoccer {

//	/**
//	 * @param args
//	 */
//	public static void main(String[] args) {
//		// TODO Auto-generated method stub
//
//	}
	
	
	public static void control(float ballAngle, float targetAngle, float controlAction[]) {

		System.out.println("Method inputs: ");
		System.out.println(ballAngle);
		System.out.println(targetAngle);
		System.out.println(" ");
		
		
        // A partir dos dados obtidos, deve inferir que ações executar. Neste
        // exemplo as forças destinadas a cada robô são guardadas em leftMotor e
        // rightMotor. Esta etapa deve ser substituida pelo controlador fuzzy.
		ballAngle = ballAngle - targetAngle;
		
		if ( ballAngle < - Math.PI ) {
			ballAngle += 2 * Math.PI;
		}
		if ( ballAngle > Math.PI ) {
			ballAngle -= 2 * Math.PI;
		}
		if ( ballAngle < ( -Math.PI / 2 ) ) {
			ballAngle = (float) (-Math.PI / 2);
		}
		if ( ballAngle > ( Math.PI / 2 ) ) {
			ballAngle = (float) (Math.PI / 2);
		}
		
		
        float leftMotor  = (float) (Math.cos( ballAngle ) - Math.sin( ballAngle ));
        float rightMotor = (float) (Math.cos( ballAngle ) + Math.sin( ballAngle ));
        // substituir até aqui
        
        
        // colocar no array para ser retornado por referencia
        controlAction[0] = leftMotor;
        controlAction[1] = rightMotor;
        
        // printar as saidas
		System.out.println("Method return: ");
		System.out.println(controlAction[0]);
		System.out.println(controlAction[1]);
		System.out.println(" ");

		
	}

}
