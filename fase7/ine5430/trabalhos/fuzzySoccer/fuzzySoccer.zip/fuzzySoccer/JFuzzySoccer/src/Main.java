public class Main {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		float ballAngle = (float) -(Math.PI)*180/360, targetAngle = (float) -(Math.PI)*180/360;
		float[] controlAction = new float[2];
		
		System.out.println("Angulo da bola = " + ballAngle
				+ ", angulo do alvo = " + targetAngle);
		
		JFuzzySoccerWinner.control(ballAngle, targetAngle, controlAction);
		
		System.out.println("Motor esquerdo = " + controlAction[0]
				+ ", Motor direito = " + controlAction[1] + "\n");
	}

}
