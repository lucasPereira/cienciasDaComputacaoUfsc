public class ReturnData
{
	int returnValue;
	String Log;
	
	public ReturnData(int nRetVal, String szLog)
	{
		this.returnValue = nRetVal;
		this.Log = szLog;
	}
}