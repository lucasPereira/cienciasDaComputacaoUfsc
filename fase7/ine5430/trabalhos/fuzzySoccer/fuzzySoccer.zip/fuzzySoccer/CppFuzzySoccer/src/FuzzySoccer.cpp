//------------------------------------------------------------------------------
// Inclusão da biblioteca que implementa a interface com o SoccerMatch.
#include "lib/environm.h"

#include "stdio.h"
#include "stdlib.h"
#include "math.h"
#include <jni.h>
#include <iostream>



// método para criar a JVM do java
JNIEnv* create_vm(JavaVM ** jvm) {

    JNIEnv *env;
    JavaVMInitArgs vm_args;
    JavaVMOption options;
    options.optionString = "-Djava.class.path=../../JFuzzySoccer/bin:/../../JFuzzySoccer/lib/jFuzzyLogic_v2.1a.jar"; //Path to the java source code
    vm_args.version = JNI_VERSION_1_6; //JDK version. This indicates version 1.6
    vm_args.nOptions = 1;
    vm_args.options = &options;
    vm_args.ignoreUnrecognized = 0;

    int ret = JNI_CreateJavaVM(jvm, (void**)&env, &vm_args);
    if(ret < 0)
    	printf("\nUnable to Launch JVM\n");
	return env;
}



// Recebe por parâmetro o endereço e a porta do SoccerMatch.
int main( int argc, char* argv[] ) {

	// pra pegar os valores float depois
	jfloat* elements;

	// Declaracao e criacao da JVM do java
	JNIEnv *env;
	JavaVM * jvm;
	env = create_vm(&jvm);

	// Encontrar referencia dos metodos
	jclass jfsClass = env->FindClass("JFuzzySoccerWinner");
	jmethodID jfsControl;
	if (jfsClass != NULL){
		jfsControl = env->GetStaticMethodID(jfsClass, "control", "(FFFF[F)V");
	} else {
		std::cout << "Classe java nao encontrada " << jfsClass <<  std::endl ;
		return 1;
	}

	jfloatArray controlAction = env->NewFloatArray(2);



    float   ang, dist, ballAngle, targetAngle, leftMotor, rightMotor;

    // Declaração do objeto que representa o ambiente.
    environm::soccer::clientEnvironm environment;

    if ( argc != 3 ) {
        printf( "\nSoccerPlayer SERVER_ADDRESS_STRING SERVER_PORT_NUMBER\n" );
        return 0; // Cancela a execução se parâmetros inválidos.
    }

    // Conecta-se ao SoccerMatch. Supõe que SoccerMatch está rodando na máquina
    // local e que um dos robôs esteja na porta 1024. Porta e local podem mudar.
    if ( ! environment.connect( argv[1], atoi( argv[2] ) ) ) {
        printf( "\nFail connecting to the SoccerMatch.\n" );
        return 0; // Cancela a execução se não conseguiu conectar-se.
    }

    // Laço de execução de ações.
    while ( 1 ) {

        // Deve obter os dados desejados do ambiente. Métodos do clientEnvironm.
        // Exemplos de métodos que podem ser utilizados.
        ballAngle = environment.getBallAngle();
        targetAngle = environment.getTargetAngle( environment.getOwnGoal() );
	dist = environment.getCollision();
	ang = environment.getObstacleAngle();

        // Chama o método java que controla
        env->CallStaticVoidMethod(jfsClass,jfsControl,dist,ang,ballAngle,targetAngle,controlAction);

printf("DIST AQUI: %f\n",dist);
        // Chama o método java que controla
        // pega os elementos do array controlAction passado por referencia
        elements = env->GetFloatArrayElements(controlAction,0);
        leftMotor  = elements[0];
        rightMotor = elements[1];

        // Transmite ação do robô ao ambiente. Fica bloqueado até que todos os
        // robôs joguem. Se erro, retorna false (neste exemplo, sai do laço).
        if ( ! environment.act( leftMotor, rightMotor ) ) {
            break; // Termina a execução se falha ao agir.
        }
    }

    return 0;
}


//------------------------------------------------------------------------------
