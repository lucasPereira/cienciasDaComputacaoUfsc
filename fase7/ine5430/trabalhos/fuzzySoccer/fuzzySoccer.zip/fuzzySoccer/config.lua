config={
  width=400;
  height=400*9/16; -- 16/9 eh o aspect ratio que eu uso
};

