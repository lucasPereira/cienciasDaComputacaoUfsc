package br.ufsc.edugraf.webis.testesWeb;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import org.junit.Test;

import br.ufsc.edugraf.webis.ambiente.recursos.RecursoCarregamentoDeSom;
import br.ufsc.edugraf.webis.suporteAosTestes.TesteDeRecursoWeb;
import br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo;

public class TesteCarregamentoDeSom extends TesteDeRecursoWeb {
	@Test
	public void obterRepresentacaoHtmlComUsuarioAutenticado() {
		fixarUsuarioAutenticado(UsuariosDeExemplo.JOAO);
		esperoQue()
			.statusCode(Status.OK.getStatusCode())
			.contentType(MediaType.TEXT_HTML)
		.when()
			.get(UriBuilder.fromResource(RecursoCarregamentoDeSom.class).build().toString());
	}
	
	@Test
	public void obterRepresentacaoHtmlComUsuarioDesautenticado() {
		esperoQue()
			.statusCode(Status.UNAUTHORIZED.getStatusCode())
		.when()
			.get(UriBuilder.fromResource(RecursoCarregamentoDeSom.class).build().toString());
	}
}
