package br.ufsc.edugraf.webis.integracao;

import static com.google.common.collect.Maps.newHashMap;

import java.io.File;
import java.util.HashMap;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.NotFoundException;
import com.sun.jersey.api.view.Viewable;

@Path("/{autor}/aplique/{nome}/teste")
public class RecursoTesteDeIntegracao {
	
	private @PathParam("nome") String nome;
	
	@GET
	@Path("/qunit/{qunit: .*}")
	public Response qunit(@PathParam("qunit") String qunit) {
		File arquivo = new File("src/test/javascript/qunit/" + qunit);
		if (!arquivo.exists()) {
			throw new NotFoundException();
		}
		return Response.ok(arquivo).build();
	}
	
	@GET
	@Path("/sinon/{sinon: .*}")
	public Response sinon(@PathParam("sinon") String sinon) {
		File arquivo = new File("src/test/javascript/sinon/" + sinon);
		if (!arquivo.exists()) {
			throw new NotFoundException();
		}
		return Response.ok(arquivo).build();
	}
	
	@GET
	@Path("teste.js")
	public Response testeJs() {
		HashMap<Object, Object> parametros = newHashMap();
		parametros.put("nomeDoTeste", nome);
		return Response.ok(new Viewable("/br/ufsc/edugraf/webis/integracao/templates/teste.js.tpl", parametros)).build();
	}
}
