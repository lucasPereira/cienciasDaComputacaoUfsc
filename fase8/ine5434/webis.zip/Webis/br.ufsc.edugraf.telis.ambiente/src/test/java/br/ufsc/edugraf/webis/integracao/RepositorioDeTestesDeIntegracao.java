package br.ufsc.edugraf.webis.integracao;

import static com.google.common.collect.Lists.newArrayList;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.FileUtils;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

import com.google.common.io.Files;

public class RepositorioDeTestesDeIntegracao implements RepositorioDoAmbiente {
	private List<Aplique> apliques = newArrayList();
	
	public RepositorioDeTestesDeIntegracao() throws IOException {
		File pastaDeTestes = new File(RepositorioDeTestesDeIntegracao.class.getResource("/webis").getFile());
		for (File conjuntoDeTestes : pastaDeTestes.listFiles()) {
			if (conjuntoDeTestes.isDirectory()) {
				for (File teste : conjuntoDeTestes.listFiles()) {
					if ("webis".equals(Files.getFileExtension(teste.getName()))) {
						Aplique aplique = new Aplique(teste.getName().replace(".webis", ""));
						aplique.obterModelo().fixarCódigoFonte(FileUtils.readFileToString(teste, "utf-8"));
						aplique.fixarAutor(obterUsuarioPorIdentificadorDoOpenId("integrador"));
						apliques.add(aplique);
					}
				}
			}
		}
	}
	
	@Override
	public List<Aplique> obterApliques() {
		return apliques;
	}
	
	@Override
	public List<Som> obterSons() {
		//TODO
		return null;
	}
	
	@Override
	public List<Aplique> obterApliquesPorAutor(Usuario autor) {
		List<Aplique> apliquesDoUsuario = newArrayList();
		for (Aplique aplique : apliques) {
			if (aplique.obterAutor().equals(autor)) {
				apliquesDoUsuario.add(aplique);
			}
		}
		return apliquesDoUsuario;
	}
	
	@Override
	public Aplique obterApliquePorNomeEAutor(String nome, Usuario autor) {
		String identificadorDoAutorNoCouch = autor.obterIdentificadorDoCouch();
		for (Aplique aplique : apliques) {
			if (nome.equals(aplique.obterNome()) && identificadorDoAutorNoCouch.equals(aplique.obterIdentificadorDoCouchDoAutor())) {
				return aplique;
			}
		}
		return null;
	}
	
	@Override
	public Usuario obterUsuarioPorIdentificadorDoOpenId(String identificadorDoOpenId) {
		return new Usuario(identificadorDoOpenId, identificadorDoOpenId, identificadorDoOpenId, identificadorDoOpenId);
	}
	
	@Override
	public Usuario obterUsuarioPorIdentificadorDoCouch(String identificadorDoCouch) {
		return new Usuario(identificadorDoCouch, identificadorDoCouch, identificadorDoCouch, identificadorDoCouch);
	}
	
	@Override
	public Usuario obterUsuarioPorEmail(String email) {
		return new Usuario(email, email, email, email);
	}
	
	@Override
	public void salvarAplique(Aplique aplique) {
		//TODO
	}
	
	@Override
	public void salvarUsuario(Usuario usuario) {
		throw new UnsupportedOperationException("Repositorio de testes de integração não permite salvamento de usuários.");
	}
	
	@Override
	public List<Som> obterSonsPorAutor(Usuario autor) {
		//TODO
		return null;
	}
	
	@Override
	public Som obterSomPorAutorENome(Usuario autor, String nome) {
		//TODO
		return null;
	}
	
	@Override
	public void salvarSom(Som som) {
		//TODO
	}
}
