package br.ufsc.edugraf.webis.testesWeb;

import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.ApliquesDeExemplo.aplique;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOAO;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOAO_IDENTIFICADOR_COUCH;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOAO_NOME;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;

import org.junit.Test;

import br.ufsc.edugraf.webis.suporteAosTestes.TesteDeRecursoWeb;

import com.jayway.restassured.http.ContentType;

public class TestePaginaListaDeApliques extends TesteDeRecursoWeb {
	
	@Test
	public void quandoNãoEstáAutenticado_deveMostrarListaDeApliques() throws Exception {
		obterRepositorio().salvarAplique(aplique("Primeiro aplique", JOAO));
		obterRepositorio().salvarAplique(aplique("Segundo aplique", JOAO));
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.**.find{it.name()=='a' && it.text()=='Primeiro aplique'}.@href", is(uri("/%s/aplique/Primeiro aplique", JOAO_IDENTIFICADOR_COUCH)))
			.and().body("html.body.**.find{it.name()=='a' && it.text()=='Segundo aplique'}.@href", is(uri("/%s/aplique/Segundo aplique", JOAO_IDENTIFICADOR_COUCH)))
		.when()
			.get("/");
	}
	
	@Test
	public void quandoAutenticado_deveMostrarNomeDoUsuario() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.**.find{it.@id == 'autenticação'}.children()[0]", is("(" + JOAO_NOME + ") Sair"))
		.when()
			.get("/");
	}
	
	@Test
	public void quandoAutenticado_deveExistirEnlaceParaSair() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.**.find{it.@id=='autenticação'}.a", is("(" + JOAO_NOME + ") Sair"))
			.body("html.body.**.find{it.@id=='autenticação'}.a.@href", equalTo(uri("/autenticacao/desassociar")))
		.when()
			.get("/");
	}
	
	@Test
	public void quandoNãoEstáAutenticado_nãoDeveMostrarOpçãoParaCriarApliques() throws Exception {
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.**.findAll{ it.@id=='novoAplique'}", is(empty()))
		.when()
			.get("/");
	}
	
	@Test
	public void quandoEstáAutenticado_deveMostrarOpçãoParaCriarApliques() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.**.findAll{it.name() == 'section' && it.@id=='secaoOperacoesDeUsuarioAutenticado'}", is(not(empty())))
		.when()
			.get("/");
	}
}
