package br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados;

import java.io.File;
import java.io.UnsupportedEncodingException;

import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;

public class FormulariosDeSomDeExemplo {
	private static final String NOME_DO_SOM = "alarme.mp3";
	private static final String CAMINHO_DO_SOM = "src/main/webapp/som/" + NOME_DO_SOM;
	
	public static MultipartEntity obterFormularioDeSom() throws UnsupportedEncodingException {
		MultipartEntity formularioDeSom = new MultipartEntity();
		formularioDeSom.addPart("nome", new FileBody(new File(CAMINHO_DO_SOM)));
		formularioDeSom.addPart("som", new StringBody(NOME_DO_SOM));
		return formularioDeSom;
	}
}
