package br.ufsc.edugraf.webis.suporteAosTestes.stubs;

import javax.ws.rs.core.SecurityContext;

public interface FabricaDeContextosDeSeguranca {
	
	public SecurityContext criarContextoDeSegurança();
}
