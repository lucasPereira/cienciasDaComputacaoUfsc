package br.ufsc.edugraf.webis.testesWeb;

import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.UriBuilder;

import org.junit.Test;

import br.ufsc.edugraf.webis.ambiente.recursos.RecursoUsuario;
import br.ufsc.edugraf.webis.suporteAosTestes.TesteDeRecursoWeb;
import br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo;

public class TesteRecursoUsuario extends TesteDeRecursoWeb {
	@Test
	public void obterRepresentacaoHtmlDeUsuarioNaoExistente() {
		String identificadorDoCouchDoJose = UsuariosDeExemplo.JOSE_IDENTIFICADOR_COUCH;
		assert(obterRepositorio().obterUsuarioPorIdentificadorDoCouch(identificadorDoCouchDoJose) == null);
		obterRepresentacaoHtmlDeUsuario(identificadorDoCouchDoJose, Status.NOT_FOUND);
	}
	
	@Test
	public void obterRepresentacaoHtmlDeUsuarioExistente() {
		obterRepositorio().salvarUsuario(UsuariosDeExemplo.JOAO);
		obterRepresentacaoHtmlDeUsuario(UsuariosDeExemplo.JOAO_IDENTIFICADOR_COUCH, Status.OK);
	}
	
	private void obterRepresentacaoHtmlDeUsuario(String identificadorDoCouch, Status estadoEsperado) {
		esperoQue()
			.statusCode(estadoEsperado.getStatusCode())
			.contentType(MediaType.TEXT_HTML)
		.when()
			.get(UriBuilder.fromResource(RecursoUsuario.class).build(identificadorDoCouch).toString());
	}
}
