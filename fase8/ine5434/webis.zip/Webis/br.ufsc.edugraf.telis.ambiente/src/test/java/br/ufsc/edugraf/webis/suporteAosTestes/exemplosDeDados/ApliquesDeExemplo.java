package br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class ApliquesDeExemplo {
	public static Aplique aplique(String nomeDoAplique, Usuario autor) {
		Aplique aplique = new Aplique(nomeDoAplique);
		aplique.fixarAutor(autor);
		aplique.obterModelo().fixarCódigoFonte(códigoDaAgendaIniciar(nomeDoAplique));
		return aplique;
	}
	
	public static String códigoDaAgendaIniciar(String nomeDoAplique) {
		return "Código da agenda iniciar de " + nomeDoAplique;
	}
}
