package br.ufsc.edugraf.webis.suporteAosTestes.stubs;

import java.security.Principal;

import javax.ws.rs.core.SecurityContext;

public class AdaptadorPrincipalParaSecurityContext implements SecurityContext {
	
	private Principal usuarioAutenticado;
	
	public AdaptadorPrincipalParaSecurityContext(Principal usuarioAutenticado) {
		this.usuarioAutenticado = usuarioAutenticado;
	}
	
	public Principal getUserPrincipal() {
		return usuarioAutenticado;
	}
	
	public boolean isUserInRole(String papel) {
		return true;
	}
	
	public boolean isSecure() {
		return true;
	}
	
	public String getAuthenticationScheme() {
		return SecurityContext.FORM_AUTH;
	}
}
