package br.ufsc.edugraf.webis.suporteAosTestes.stubs;

import com.google.inject.Inject;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;

public class FiltroDeAutenticacaoParaTestes implements ContainerRequestFilter {
	
	private @Inject FabricaDeContextosDeSeguranca fabrica;
	
	public ContainerRequest filter(ContainerRequest request) {
		request.setSecurityContext(fabrica.criarContextoDeSegurança());
		return request;
	}
}
