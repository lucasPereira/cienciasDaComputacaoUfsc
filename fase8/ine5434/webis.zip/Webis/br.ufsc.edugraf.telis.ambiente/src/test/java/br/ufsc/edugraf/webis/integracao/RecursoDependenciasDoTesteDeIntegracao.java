package br.ufsc.edugraf.webis.integracao;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.core.Response;

import com.sun.jersey.api.view.Viewable;

@Path("/{autor}/aplique/{nome}/teste.html")
public class RecursoDependenciasDoTesteDeIntegracao {
	
	@GET
	public Response testeHtml() {
		return Response.ok(new Viewable("/br/ufsc/edugraf/webis/integracao/templates/teste.html.tpl")).build();
	}
}
