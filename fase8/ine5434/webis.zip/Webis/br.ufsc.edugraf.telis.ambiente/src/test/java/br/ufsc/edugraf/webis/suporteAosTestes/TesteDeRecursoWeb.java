package br.ufsc.edugraf.webis.suporteAosTestes;

import org.junit.After;
import org.junit.Before;

import br.ufsc.edugraf.webis.ambiente.ServidorJetty;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.servlet.ModuloDeRecursos;
import br.ufsc.edugraf.webis.suporteAosTestes.stubs.FabricaDeContextosDeSeguranca;
import br.ufsc.edugraf.webis.suporteAosTestes.stubs.FiltroDeAutenticacaoParaTestes;
import br.ufsc.edugraf.webis.suporteAosTestes.stubs.ImplementacaoDeFabricaDeContextosDeSeguranca;
import br.ufsc.edugraf.webis.suporteAosTestes.stubs.RepositorioEmMemoria;

import com.google.inject.Binder;
import com.google.inject.Module;
import com.jayway.restassured.RestAssured;
import com.jayway.restassured.specification.RequestSpecification;
import com.jayway.restassured.specification.ResponseSpecification;

public class TesteDeRecursoWeb {
	private ServidorJetty servidorJetty;
	private RepositorioEmMemoria repositorio;
	private ImplementacaoDeFabricaDeContextosDeSeguranca fabricaDeContextosDeSegurança;
	
	@Before
	public void iniciarServidor() throws Exception {
		repositorio = new RepositorioEmMemoria();
		fabricaDeContextosDeSegurança = new ImplementacaoDeFabricaDeContextosDeSeguranca();
		servidorJetty = new ServidorJetty(9090, criarModulos());
		servidorJetty.iniciar();
	}
	
	private Module[] criarModulos() {
		Module servicos = new Module() {
			public void configure(Binder binder) {
				binder.bind(RepositorioDoAmbiente.class).toInstance(repositorio);
				binder.bind(FabricaDeContextosDeSeguranca.class).toInstance(fabricaDeContextosDeSegurança);
			}
		};
		ModuloDeRecursos moduloDeRecursos = new ModuloDeRecursos();
		moduloDeRecursos.adicionarFiltro(FiltroDeAutenticacaoParaTestes.class);
		return new Module[] {servicos, moduloDeRecursos};
	}
	
	protected RepositorioDoAmbiente obterRepositorio() {
		return repositorio;
	}
	
	protected void fixarUsuarioAutenticado(Usuario usuario) {
		repositorio.salvarUsuario(usuario);
		fabricaDeContextosDeSegurança.fixarUsuarioAutenticado(usuario);
	}
	
	@After
	public void desligarServidor() throws Exception {
		servidorJetty.desligar();
	}
	
	protected final ResponseSpecification esperoQue() {
		return dadoQue().expect();
	}
	
	protected final RequestSpecification dadoQue() {
		return RestAssured.given().port(9090);
	}
	
	protected final String uri(String recurso, Object ... dados) {
		return String.format(recurso, dados);
	}
}
