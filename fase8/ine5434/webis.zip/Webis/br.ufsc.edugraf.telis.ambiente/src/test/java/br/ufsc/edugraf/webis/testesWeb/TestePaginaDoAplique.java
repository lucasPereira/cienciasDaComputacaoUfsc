package br.ufsc.edugraf.webis.testesWeb;

import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.ApliquesDeExemplo.aplique;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOSE;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOSE_IDENTIFICADOR_COUCH;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOAO;
import static br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados.UsuariosDeExemplo.JOAO_IDENTIFICADOR_COUCH;
import static org.hamcrest.Matchers.empty;
import static org.hamcrest.Matchers.is;

import org.junit.Test;

import br.ufsc.edugraf.webis.suporteAosTestes.TesteDeRecursoWeb;

import com.jayway.restassured.http.ContentType;

public class TestePaginaDoAplique extends TesteDeRecursoWeb {
	@Test
	public void quandoAutorDoApliqueEstáAutenticado_deveMostrarOpçãoSalvar() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		obterRepositorio().salvarAplique(aplique("Aplique", JOAO));
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.section.form.**.find{it.@type=='submit'}.@value", is("Salvar"))
			.body("html.body.section.form.@action", is(uri("/%s/apliques", JOAO_IDENTIFICADOR_COUCH)))
		.when()
			.get("/{autor}/aplique/Aplique", JOAO_IDENTIFICADOR_COUCH);
	}
	
	@Test
	public void quandoNãoHáNinguemAutenticado_nãoDeveSerPossívelSalvarOuApropriarSe() throws Exception {
		obterRepositorio().salvarUsuario(JOAO);
		obterRepositorio().salvarAplique(aplique("Aplique", JOAO));
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.form.**.findAll{it.@type=='submit'}", is(empty()))
		.when()
			.get("/{autor}/aplique/Aplique", JOAO_IDENTIFICADOR_COUCH);
	}
	
	@Test
	public void quandoJoãoEstáAutenticado_deveSerPossívelApropriarSeDoApliqueDeJosé() throws Exception {
		obterRepositorio().salvarUsuario(JOSE);
		obterRepositorio().salvarAplique(aplique("Aplique", JOSE));
		fixarUsuarioAutenticado(JOAO);
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.section.form.**.findAll{it.@type=='submit'}.@value", is("Apropriar-se"))
			.body("html.body.section.form.@action", is(uri("/%s/apliques", JOAO_IDENTIFICADOR_COUCH)))
		.when()
			.get(JOSE_IDENTIFICADOR_COUCH + "/aplique/Aplique");
	}
	
	@Test
	public void quandoNãoHáNinguemAutenticado_postRetornaAutenticacaoNecessaria() throws Exception {
		obterRepositorio().salvarUsuario(JOAO);
		obterRepositorio().salvarAplique(aplique("Aplique", JOAO));
		esperoQue()
			.statusCode(405)
		.when()
			.post(JOAO_IDENTIFICADOR_COUCH + "/aplique/Aplique");
	}
	
	@Test
	public void quandoJoãoEstáAutenticado_postEmApliqueDeJoséNãoPermitido() throws Exception {
		obterRepositorio().salvarUsuario(JOSE);
		fixarUsuarioAutenticado(JOAO);
		obterRepositorio().salvarAplique(aplique("Aplique", JOSE));
		dadoQue()
			.parameter("nome", "Aplique")
		.expect()
			.statusCode(403)
		.when()
			.post(JOSE_IDENTIFICADOR_COUCH + "/apliques");
	}
	
	@Test
	public void quandoJoãoEstáAutenticado_postEmApliqueDeJoãoModificaOCódigo() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		obterRepositorio().salvarAplique(aplique("Aplique", JOAO));
		dadoQue()
			.parameter("codigoFonte", "codigo")
			.parameter("nome", "Aplique")
		.expect()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.section.form.**.find{it.@name=='codigoFonte'}", is("codigo"))
		.when()
			.post(JOAO_IDENTIFICADOR_COUCH + "/apliques");
	}
	
	@Test
	public void quandoJoãoEstáAutenticado_deveSerMostradoOBotãoSalvarAplique() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		obterRepositorio().salvarAplique(aplique("Aplique", JOAO));
		esperoQue()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.section.form.**.find{it.@type=='submit'}.@value", is("Salvar"))
		.when()
			.get(JOAO_IDENTIFICADOR_COUCH + "/aplique/Aplique");
	}
	
	@Test
	public void quandoJoãoEstáAutenticado_postCriarNovoAplique() throws Exception {
		fixarUsuarioAutenticado(JOAO);
		dadoQue()
			.parameter("codigoFonte", "codigo")
			.parameter("nome", "Aplique")
		.expect()
			.statusCode(200)
			.contentType(ContentType.HTML)
			.body("html.body.section.form.**.find{it.@name=='codigoFonte'}", is("codigo"))
		.when()
			.post(JOAO_IDENTIFICADOR_COUCH + "/apliques");
	}
	
	@Test
	public void quandoUsuarioAnonimo_deveRetornar404SeApliqueNãoExistir() throws Exception {
		esperoQue()
			.statusCode(404)
		.when()
			.get(JOAO_IDENTIFICADOR_COUCH + "/aplique/Aplique");
	}
}
