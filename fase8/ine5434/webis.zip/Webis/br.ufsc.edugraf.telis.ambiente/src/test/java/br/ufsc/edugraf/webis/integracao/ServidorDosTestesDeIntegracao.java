package br.ufsc.edugraf.webis.integracao;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.DefaultHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.server.handler.RequestLogHandler;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletContextHandler;

import br.ufsc.edugraf.webis.ambiente.servlet.ConfiguracaoJUL;
import ch.qos.logback.access.jetty.RequestLogImpl;

import com.google.inject.servlet.GuiceFilter;

public class ServidorDosTestesDeIntegracao {
	
	public static void main(String[] args) throws Exception {
		int porta = 8080;
		if (args.length == 1) {
			porta = Integer.parseInt(args[0]);
		}
		Server server = new Server(porta);
		HandlerCollection handlers = new HandlerCollection();
		ServletContextHandler servletContextHandler = new ServletContextHandler(server, "/", true, false);
		servletContextHandler.setResourceBase("src/main/webapp");
		servletContextHandler.addEventListener(new ConfiguracaoJUL());
		servletContextHandler.addEventListener(new ConfiguracaoDoServletDeTestesDeIntegracao());
		servletContextHandler.addFilter(GuiceFilter.class, "/*", null);
		servletContextHandler.addServlet(DefaultServlet.class, "/");
		RequestLogHandler requestLogHandler = new RequestLogHandler();
		RequestLogImpl requestLog = new RequestLogImpl();
		requestLog.setResource("/logback-access.xml");
		requestLogHandler.setRequestLog(requestLog);
		handlers.setHandlers(new org.eclipse.jetty.server.Handler[]{servletContextHandler, new DefaultHandler(), requestLogHandler});
		server.setHandler(handlers);
		try {
			server.start();
		} catch (Exception e) {
			server.stop();
		}
	}
}
