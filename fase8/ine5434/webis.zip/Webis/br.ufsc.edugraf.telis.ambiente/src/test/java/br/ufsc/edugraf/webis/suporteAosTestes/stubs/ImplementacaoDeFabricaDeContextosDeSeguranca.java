package br.ufsc.edugraf.webis.suporteAosTestes.stubs;

import java.security.Principal;

import javax.ws.rs.core.SecurityContext;

public class ImplementacaoDeFabricaDeContextosDeSeguranca implements FabricaDeContextosDeSeguranca {
	private Principal usuarioAutenticado;
	
	public void fixarUsuarioAutenticado(Principal usuarioAutenticado) {
		this.usuarioAutenticado = usuarioAutenticado;
	}
	
	public SecurityContext criarContextoDeSegurança() {
		return new AdaptadorPrincipalParaSecurityContext(usuarioAutenticado);
	}
}
