package br.ufsc.edugraf.webis.integracao;

import javax.ws.rs.GET;
import javax.ws.rs.Path;

@Path("/desligamento")
public class RecursoDesligamento {
	
	@GET
	public void desligar() {
		System.exit(0);
	}
}
