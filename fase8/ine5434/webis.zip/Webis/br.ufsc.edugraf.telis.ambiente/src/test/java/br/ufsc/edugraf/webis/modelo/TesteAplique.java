package br.ufsc.edugraf.webis.modelo;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.nullValue;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

import java.util.Calendar;

import org.junit.Test;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class TesteAplique {
	
	@Test
	public void nomeDoAplique() {
		Aplique aplique = new Aplique("nome");
		assertThat(aplique.obterNome(), is(equalTo("nome")));
	}
	
	@Test
	public void modeloDoApliqueTemNomeInicial() {
		Aplique aplique = new Aplique("nome");
		assertThat(aplique.obterModelo().obterNome(), is(equalTo("inicial")));
	}
	
	@Test
	public void modeloDoApliqueTemCódigoVazio() {
		Aplique aplique = new Aplique("nome");
		assertThat(aplique.obterModelo().obterCodigoFonte(), is(equalTo("")));
	}
	
	@Test
	public void autorDoApliqueComeçaNulo() {
		Aplique aplique = new Aplique("nome");
		assertThat(aplique.obterAutor(), is(nullValue()));
	}
	
	@Test
	public void dataDeModificacaoDoApliqueComecaVazia() {
		Aplique aplique = new Aplique("nome");
		assertThat(aplique.obterDataDeModificacao(), is(equalTo("")));
	}
	
	@Test
	public void dataDeModificacaoDoApliquePodeSerAtualizada() {
		Aplique aplique = new Aplique("nome");
		aplique.atualizarDataDeModificacao();
		assertThat(aplique.obterDataDeModificacao(), not(nullValue()));
	}
	
	@Test
	public void dataDeModificacaoPorExtensoComeçaVazia() {
		Aplique aplique = new Aplique("nome");
		assertThat(aplique.obterDataDeModificacaoPorExtenso(), is(equalTo("")));
	}
	
	@Test
	public void dataDeModificacaoMostraDiaMesAnoEHorario() {
		Aplique aplique = new Aplique("nome");
		aplique.atualizarDataDeModificacao();
		final String expressãoRegularDeData = "(2[0-9]{3,})-(0[1-9]|1[0-2])-(0[1-9]|[1-2][0-9]|3[0-1]) ([0-1][0-9]|2[0-3]):([0-5][0-9])";
		assertTrue(aplique.obterDataDeModificacao().matches(expressãoRegularDeData));
	}
	
	@Test
	public void dataDeMoficiacaoPorExtensoDeApliqueModificadoHoje() {
		Aplique aplique = new Aplique("nome");
		aplique.atualizarDataDeModificacao();
		final String expressãoRegularDeData = "Hoje às ([0-1][0-9]|2[0-3]):([0-5][0-9])";
		assertTrue(aplique.obterDataDeModificacaoPorExtenso().matches(expressãoRegularDeData));
	}
	
	@Test
	public void dataDeMoficiacaoPorExtensoDeApliqueModificadoOntem() {
		Calendar ontem = Calendar.getInstance();
		ontem.add(Calendar.DATE, -1);
		ontem.set(Calendar.HOUR, 5);
		ontem.set(Calendar.MINUTE, 0);
		ontem.set(Calendar.AM_PM, Calendar.AM);
		Aplique aplique = new Aplique("nome");
		aplique.fixarDataDeModificacao(ontem.getTime());
		final String expressãoRegularDeData = "Ontem às ([0-1][0-9]|2[0-3]):([0-5][0-9])";
		assertTrue(aplique.obterDataDeModificacaoPorExtenso().matches(expressãoRegularDeData));
	}
	
	@Test
	public void dataDeModificacaoPorExtensoDeApliqueModificadoAMaisDeDoisDiasAtras() {
		Calendar antesDeOntem = Calendar.getInstance();
		antesDeOntem.add(Calendar.DATE, -2);
		antesDeOntem.set(Calendar.HOUR, 10);
		antesDeOntem.set(Calendar.MINUTE, 0);
		antesDeOntem.set(Calendar.AM_PM, Calendar.PM);
		Aplique aplique = new Aplique("nome");
		aplique.fixarDataDeModificacao(antesDeOntem.getTime());
		final String expressãoRegularDeData = "(0[1-9]|[1-2][0-9]|3[0-1]) de (Janeiro|Fevereiro|Março|Abril|Junho|Julho|Agosto|Setembro|Outubro|Novembro|Dezembro) de (2[0-9]{3,}) às ([0-1][0-9]|2[0-3]):([0-5][0-9])";
		assertTrue(aplique.obterDataDeModificacaoPorExtenso().matches(expressãoRegularDeData));
	}
	
	@Test
	public void autorDoApliquePodeSerModificado() {
		Aplique aplique = new Aplique("nome");
		Usuario usuario = new Usuario("identificador", "autor", "autor@edugraf.ufsc.br");
		aplique.fixarAutor(usuario);
		assertThat(aplique.obterAutor(), is(equalTo(usuario)));
	}
}
