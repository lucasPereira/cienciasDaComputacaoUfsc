package br.ufsc.edugraf.webis.suporteAosTestes.exemplosDeDados;

import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class UsuariosDeExemplo {
	public static final String JOAO_EMAIL = "joao@gmail.com";
	public static final String JOAO_NOME = "João";
	public static final String JOAO_IDENTIFICADOR_COUCH = "1";
	public static final String JOAO_IDENTIFICADOR_OPEN_ID = "identificadorOpenIdJoao";
	public static final Usuario JOAO = new Usuario(JOAO_IDENTIFICADOR_COUCH, JOAO_IDENTIFICADOR_COUCH, JOAO_NOME, JOAO_EMAIL);
	public static final String JOSE_EMAIL = "jose@gmail.com";
	public static final String JOSE_NOME = "José";
	public static final String JOSE_IDENTIFICADOR_COUCH = "2";
	public static final String JOSE_IDENTIFICADOR_OPEN_ID = "identificadorOpenIdJose";
	public static final Usuario JOSE = new Usuario(JOSE_IDENTIFICADOR_COUCH, JOSE_IDENTIFICADOR_OPEN_ID, JOSE_NOME, JOSE_EMAIL);
}
