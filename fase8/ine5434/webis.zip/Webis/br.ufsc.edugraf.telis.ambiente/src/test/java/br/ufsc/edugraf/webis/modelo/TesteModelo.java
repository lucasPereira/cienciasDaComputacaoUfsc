package br.ufsc.edugraf.webis.modelo;

import static org.hamcrest.Matchers.equalTo;
import static org.junit.Assert.assertThat;

import org.junit.Test;

import br.ufsc.edugraf.webis.ambiente.modelo.Modelo;

public class TesteModelo {
	
	@Test
	public void nomeDoModelo() {
		Modelo modelo = new Modelo("nome");
		assertThat(modelo.obterNome(), equalTo("nome"));
	}
	
	@Test
	public void nomeECódigoDoModelo() {
		Modelo modelo = new Modelo("nome", "código");
		assertThat(modelo.obterNome(), equalTo("nome"));
		assertThat(modelo.obterCodigoFonte(), equalTo("código"));
	}
	
	@Test
	public void trocaDoCódigoDoModelo() {
		Modelo modelo = new Modelo("nome", "código");
		modelo.fixarCódigoFonte("outroCódigo");
		assertThat(modelo.obterCodigoFonte(), equalTo("outroCódigo"));
	}
}
