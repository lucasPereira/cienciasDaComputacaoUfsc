package br.ufsc.edugraf.webis.suporteAosTestes.stubs;

import static com.google.common.collect.Lists.newArrayList;

import java.util.List;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class RepositorioEmMemoria implements RepositorioDoAmbiente {
	private List<Aplique> apliques = newArrayList();
	private List<Usuario> usuarios = newArrayList();
	
	public RepositorioEmMemoria() {
		
	}
	
	@Override
	public List<Aplique> obterApliques() {
		return apliques;
	}
	
	@Override
	public List<Som> obterSons() {
		//TODO
		return null;
	}
	
	@Override
	public List<Aplique> obterApliquesPorAutor(Usuario autor) {
		List<Aplique> apliquesDoUsuario = newArrayList();
		for (Aplique aplique : apliques) {
			if (aplique.obterAutor().equals(autor)) {
				apliquesDoUsuario.add(aplique);
			}
		}
		return apliquesDoUsuario;
	}
	
	@Override
	public Aplique obterApliquePorNomeEAutor(String nome, Usuario autor) {
		String identificadorDoAutorNoCouch = autor.obterIdentificadorDoCouch();
		for (Aplique aplique : apliques) {
			if (nome.equals(aplique.obterNome()) && identificadorDoAutorNoCouch.equals(aplique.obterIdentificadorDoCouchDoAutor())) {
				return aplique;
			}
		}
		Aplique aplique = new Aplique(nome);
		aplique.obterModelo().fixarCódigoFonte("");
		return aplique;
	}
	
	@Override
	public Usuario obterUsuarioPorIdentificadorDoOpenId(String identificadorDoOpenId) {
		for (Usuario usuario: usuarios) {
			if (usuario.obterIdentificadorDoOpenId().equals(identificadorDoOpenId)) {
				return usuario;
			}
		}
		return null;
	}
	
	@Override
	public Usuario obterUsuarioPorIdentificadorDoCouch(String identificadorDoCouch) {
		for (Usuario usuario: usuarios) {
			if (usuario.obterIdentificadorDoCouch().equals(identificadorDoCouch)) {
				return usuario;
			}
		}
		return null;
	}
	
	@Override
	public Usuario obterUsuarioPorEmail(String email) {
		for (Usuario usuario: usuarios) {
			if (usuario.obterEmail().equals(email)) {
				return usuario;
			}
		}
		return null;
	}
	
	@Override
	public void salvarAplique(Aplique aplique) {
		if (!apliques.contains(aplique)) {
			apliques.add(aplique);
		}
	}
	
	@Override
	public void salvarUsuario(Usuario usuario) {
		usuarios.add(usuario);
	}
	
	@Override
	public List<Som> obterSonsPorAutor(Usuario autor) {
		//TODO
		return null;
	}
	
	@Override
	public Som obterSomPorAutorENome(Usuario autor, String nome) {
		//TODO
		return null;
	}
	
	@Override
	public void salvarSom(Som som) {
		//TODO
	}
}
