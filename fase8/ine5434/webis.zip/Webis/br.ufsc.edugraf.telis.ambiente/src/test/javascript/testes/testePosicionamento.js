/*global Ator*/
/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("posicionamento");

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("posicao")
			.comValor({x: 0, y: 0, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("direcao")
			.comValor({x: 0, y: 1, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("velocidade")
			.comValor({x: 0, y: 0, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("rotacao")
			.comValor(90)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("tamanhoDoPasso")
			.comValor(10)
			.testar();
	}());

	(function () {
		QUnit.module("direita");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("direita")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("direita")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("direita")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("direita")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("direita")
			.comComandos(0)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 6.123031769111886e-17, y: 1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("direita")
			.comComandos(90)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 1, y: 0, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(0)
			.daPropriedade("direcao")
			.comValor({x: 6.123031769111886e-17, y: 1, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(90)
			.daPropriedade("direcao")
			.comValor({x: 1, y: 0, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(180)
			.daPropriedade("direcao")
			.comValor({x: -1.836909530733566e-16, y: -1, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(270)
			.daPropriedade("direcao")
			.comValor({x: -1, y: 1.2246063538223773e-16, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(360)
			.daPropriedade("direcao")
			.comValor({x: 6.123031769111886e-17, y: 1, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(450)
			.daPropriedade("direcao")
			.comValor({x: 1, y: 0, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(540)
			.daPropriedade("direcao")
			.comValor({x: -1.836909530733566e-16, y: -1, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(630)
			.daPropriedade("direcao")
			.comValor({x: -1, y: 1.2246063538223773e-16, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("direita")
			.comComandos(720)
			.daPropriedade("direcao")
			.comValor({x: 6.123031769111886e-17, y: 1, z: 0})
			.testar();
	}());

	(function () {
		QUnit.module("frente");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("frente")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("frente")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("frente")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("frente")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("frente")
			.comComandos(0)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 0, y: 1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("frente")
			.comComandos(10)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 10, z: 0}, direcao: {x: 0, y: 1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("frente")
			.comComandos(0)
			.daPropriedade("posicao")
			.comValor({x: 0, y: 0, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("frente")
			.comComandos(10)
			.daPropriedade("posicao")
			.comValor({x: 0, y: 10, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("frente")
			.comComandos(-10)
			.daPropriedade("posicao")
			.comValor({x: 0, y: -10, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("frente")
			.comComandos(180, new Simbolo("direita"), 10)
			.daPropriedade("posicao")
			.comValor({x: -1.836909530733566e-15, y: -10, z: 0})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("frente")
			.comComandos(-90, new Simbolo("direita"), 10)
			.daPropriedade("posicao")
			.comValor({x: -10, y: 1.2246063538223773e-15, z: 0})
			.testar();
	}());

	(function () {
		QUnit.module("obterPosição");

		TesteWebis
			.dePilha()
			.daPrimitiva("obterPosição")
			.deixaNaPilha([0, 0])
			.testar();
	}());

	(function () {
		QUnit.module("fixarDireção");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarDireção")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarDireção")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarDireção")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarDireção")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(0)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 1, y: 0, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(90)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 6.123031769111886e-17, y: 1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(180)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: -1, y: 1.2246063538223773e-16, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(270)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: -1.836909530733566e-16, y: -1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(360)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 1, y: 0, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(450)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 6.123031769111886e-17, y: 1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(540)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: -1, y: 1.2246063538223773e-16, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(630)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: -1.836909530733566e-16, y: -1, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarDireção")
			.comComandos(720)
			.doComando("MOVER")
			.comDados({posicao: {x: 0, y: 0, z: 0}, direcao: {x: 1, y: 0, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(0)
			.daPropriedade("rotacao")
			.comValor(0)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(90)
			.daPropriedade("rotacao")
			.comValor(90)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(180)
			.daPropriedade("rotacao")
			.comValor(180)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(270)
			.daPropriedade("rotacao")
			.comValor(270)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(360)
			.daPropriedade("rotacao")
			.comValor(0)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(450)
			.daPropriedade("rotacao")
			.comValor(90)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(540)
			.daPropriedade("rotacao")
			.comValor(180)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(630)
			.daPropriedade("rotacao")
			.comValor(270)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(720)
			.daPropriedade("rotacao")
			.comValor(0)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(-1)
			.daPropriedade("rotacao")
			.comValor(359)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(-360)
			.daPropriedade("rotacao")
			.comValor(0)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarDireção")
			.comComandos(-1170)
			.daPropriedade("rotacao")
			.comValor(270)
			.testar();
	}());

	(function () {
		QUnit.module("obterDireção");

		TesteWebis
			.dePilha()
			.daPrimitiva("obterDireção")
			.deixaNaPilha(90)
			.testar();
	}());

	(function () {
		QUnit.module("andarPara");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("andarPara")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("andarPara")
			.comParametros("texto")
			.dosTipos(Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("andarPara")
			.comParametros(10)
			.dosTipos(Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("andarPara")
			.comParametros(true)
			.dosTipos(Array)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos([])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos([10])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos([10, 20, 30])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos([new Simbolo("SIMBOLO"), 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos([[], 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos(["texto", 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("andarPara")
			.comComandos([true, 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDePosicaoInvalida())
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("andarPara")
			.comComandos([100, 0])
			.doComando("MOVER")
			.comDados({posicao: {x: 100, y: 0, z: 0}, direcao: {x: 1, y: 0, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.vezes(1)
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("andarPara")
			.comComandos(new Simbolo("comSom"), [100, 0])
			.doComando("MOVER")
			.comDados({posicao: {x: 100, y: 0, z: 0}, direcao: {x: 1, y: 0, z: 0}, velocidade: {x: 0, y: 0, z: 0}})
			.vezes(12)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("posicao")
			.comValor({x: 10.000000000000002, y: 10, z: 0})
			.daPrimitiva("andarPara")
			.comComandos([10, 10])
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("direcao")
			.comValor({x: 1, y: 0, z: 0})
			.daPrimitiva("andarPara")
			.comComandos([10, 0])
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("velocidade")
			.comValor({x: 0, y: 0, z: 0})
			.daPrimitiva("andarPara")
			.comComandos([10, 0])
			.testar();
	}());

	(function () {
		QUnit.module("fixarVelocidade");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarVelocidade")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarVelocidade")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarVelocidade")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarVelocidade")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("fixarVelocidade")
			.comComandos(0)
			.lancaExcecao(Checagem.obterMensagemDeVelocidadeInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("fixarVelocidade")
			.comComandos(-10)
			.lancaExcecao(Checagem.obterMensagemDeVelocidadeInvalida())
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarVelocidade")
			.comComandos(20)
			.daPropriedade("tamanhoDoPasso")
			.comValor(20)
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPrimitiva("fixarVelocidade")
			.comComandos(20.5)
			.daPropriedade("tamanhoDoPasso")
			.comValor(20.5)
			.testar();
	}());
}(this));
