/*global Associar*/
/*global Checagem*/
/*global QUnit*/
/*global PacoteDeSimbolo*/
/*global Simbolo*/
/*global TabelaDeTratadores*/
/*global TesteWebis*/
/*global TratadorDeEstimulo*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		TabelaDeTratadores.splice(0);
		global.postMessage = sinon.stub();
	});

	QUnit.testDone(function () {
		TabelaDeTratadores.splice(0);
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("seDito");

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros([], 10)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros("texto", "texto")
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(10, [])
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(10, 10)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(10, true)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(false, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(false, [])
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(false, "texto")
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(false, 10)
			.dosTipos(Array, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("seDito")
			.comParametros(false, true)
			.dosTipos(Array, Array)
			.testar();
	}());

	(function () {
		QUnit.module("dizer");

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("dizer")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("dizer")
			.comParametros("texto")
			.dosTipos(Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("dizer")
			.comParametros(10)
			.dosTipos(Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("dizer")
			.comParametros(true)
			.dosTipos(Array)
			.testar();

		TesteWebis.deMensagem()
			.daPrimitiva("dizer")
			.doComando("DIZER")
			.comDados({listaDita: ["texto", [1], 0, new Simbolo("Número"), true]})
			.comComandos(["texto", [1], 0, new Simbolo("Número"), true])
			.testar();

		TesteWebis.dePropriedade()
			.daPrimitiva("seDito")
			.comComandos([[], "nomeDoEstimulo", 1, true, new Simbolo("Símbolo"), new Simbolo("Lista"), new Simbolo("Texto"), new Simbolo("Número"), new Simbolo("Booleano")])
			.comComandos([])
			.doElemento(global)
			.daPropriedade("TabelaDeTratadores")
			.comValor([new TratadorDeEstimulo([[], "nomeDoEstimulo", 1, true, new Simbolo("Símbolo"), new Simbolo("Lista"), new Simbolo("Texto"), new Simbolo("Número"), new Simbolo("Booleano")], [])])
			.testar();

		TesteWebis.dePropriedade()
			.daPrimitiva("seDito")
			.comComandos(["estimulo"], [0, "textoA"], new Simbolo("seDito"))
			.comComandos(["estimulo"], ["textoB", true, 2])
			.doElemento(global)
			.daPropriedade("TabelaDeTratadores")
			.comValor([new TratadorDeEstimulo(["estimulo"], ["textoB", true, 2]), new TratadorDeEstimulo(["estimulo"], [0, "textoA"])])
			.testar();

		TesteWebis.dePropriedade()
			.daPrimitiva("seDito")
			.comComandos([1], [true], new Simbolo("seDito"))
			.comComandos([1], [true])
			.doElemento(global)
			.daPropriedade("TabelaDeTratadores")
			.comValor([new TratadorDeEstimulo([1], [true]), new TratadorDeEstimulo([1], [true])])
			.testar();
	}());

	(function () {
		QUnit.module("receberEstimulo");

		TesteWebis.deEstimulo()
			.comComandos(5)
			.comTratador(["tratadorMostrar"], ["texto", new Simbolo("mostrar"), 1])
			.comEstimulo(["tratadorMostrar"])
			.doComando("MOSTRAR")
			.comDados({mensagem: "texto"})
			.deixaNaPilha(5)
			.testar();

		TesteWebis.deEstimulo()
			.comComandos(10, new Associar("variavel"))
			.comTratador(["tratadorMostrar"], [2, new Simbolo("variavel"), new Simbolo("mostrar")])
			.comEstimulo(["tratadorMostrar"])
			.doComando("MOSTRAR")
			.comDados({mensagem: "10"})
			.testar();

		TesteWebis.deEstimulo()
			.comComandos(15, new Associar("variavel"))
			.comTratador(["tratadorMostrar"], [3, new Associar("variavel"), new Simbolo("variavel"), new Simbolo("mostrar")])
			.comEstimulo(["tratadorMostrar"])
			.doComando("MOSTRAR")
			.comDados({mensagem: "3"})
			.testar();

		TesteWebis.deEstimulo()
			.comTratador([new Simbolo("Número"), new Simbolo("Número"), new Simbolo("Número")], [new Simbolo("+"), new Simbolo("+"), new Simbolo("mostrar")])
			.comEstimulo([1, 2, 3])
			.doComando("MOSTRAR")
			.comDados({mensagem: "6"})
			.testar();

		TesteWebis.deEstimulo()
			.comTratador(["tratador", new Simbolo("Número")], [new Simbolo("+"), new Simbolo("mostrar")])
			.comTratador(["tratador", 10], [new Simbolo("+"), new Simbolo("mostrar")])
			.comEstimulo(["tratador", 10])
			.doComando("MOSTRAR")
			.comDados({mensagem: "tratador10"})
			.vezes(2)
			.testar();

		TesteWebis.deEstimulo()
			.comTratador([new Simbolo("TECLADO"), "teclaPressionada", new Simbolo("Número"), new Simbolo("Número")], ["recebeuTeclado", new Simbolo("mostrar")])
			.comEstimulo([new Simbolo("TECLADO"), "teclaPressionada", 97, 0])
			.doComando("MOSTRAR")
			.comDados({mensagem: "recebeuTeclado"})
			.testar();
	}());
}(this));
