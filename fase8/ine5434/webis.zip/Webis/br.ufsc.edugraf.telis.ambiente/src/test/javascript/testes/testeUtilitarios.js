/*global Checagem*/
/*global Contexto*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global Webis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("gerarAleatório");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarAleatório")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarAleatório")
			.comParametros("texto")
			.dosTipos(Array)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarAleatório")
			.comParametros(true)
			.dosTipos(Array)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([1])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([1, 2, 3])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([1, new PacoteDeSimbolo("SIMBOLO")])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([1, []])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([1, "texto"])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarAleatório")
			.comComandos([1, true])
			.lancaExcecao(Checagem.obterMensagemDeListaComIntervalosInvalida())
			.testar();

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[1, new Simbolo("gerarAleatório")], 5, new Simbolo("vezesRepetir")];
			Webis.inicializar(contexto, comandos, function () {
				QUnit.deepEqual(contexto.pilha, [1, 1, 1, 1, 1], "1 gerarAleatório deve gerar apenas o Número 1.");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [2, new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= 1 && numeroGerado <= 2, "2 gerarAleatório deve gerar números entre 1 e 2 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [10, new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= 1 && numeroGerado <= 10, "10 gerarAleatório deve gerar números entre 1 e 10 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [0, new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= 0 && numeroGerado <= 1, "0 gerarAleatório deve gerar números entre 0 e 1 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [-1, new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= -1 && numeroGerado <= 1, "-1 gerarAleatório deve gerar números entre -1 e 1 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [-10, new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= -10 && numeroGerado <= 1, "-10 gerarAleatório deve gerar números entre -10 e 1 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[0, 0], new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado === 0, "[0 0] gerarAleatório gera apenas o número 0.");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[10, 10], new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado === 10, "[10 10] gerarAleatório gera apenas o número 10.");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[1, 0], new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= 0 && numeroGerado <= 1, "[1 0] gerarAleatório gera um número entre 0 e 1 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[0, -1], new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= -1 && numeroGerado <= 0, "[0 -1] gerarAleatório gera um número entre -1 e 0 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[-1, 1], new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= -1 && numeroGerado <= 1, "[-1 1] gerarAleatório gera um número entre -1 e 1 (incluindo extremos).");
				QUnit.start();
			});
		});

		QUnit.asyncTest("Teste personalizado.", function () {
			var contexto = new Contexto();
			var comandos = [[30, -20], new Simbolo("gerarAleatório")];
			Webis.inicializar(contexto, comandos, function () {
				var numeroGerado = contexto.pilha.tirar();
				QUnit.ok(numeroGerado >= -20 && numeroGerado <= 30, "[30 -20] gerarAleatório gera um número entre -30 e 20 (incluindo extremos).");
				QUnit.start();
			});
		});
	}());

	(function () {
		QUnit.module("descansar");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("descansar")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("descansar")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("descansar")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("descansar")
			.comParametros(true)
			.dosTipos(Number)
			.testar();
	}());
}(this));
