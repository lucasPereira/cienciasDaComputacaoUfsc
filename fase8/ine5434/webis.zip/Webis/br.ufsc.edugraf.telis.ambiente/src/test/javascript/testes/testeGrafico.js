/*global Ator*/
/*global QUnit*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("gráfico");

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("visivel")
			.comValor(false)
			.testar();
	}());

	(function () {
		QUnit.module("visível");

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("visível")
			.doComando("VISIVEL")
			.comDados()
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("visivel")
			.comValor(true)
			.daPrimitiva("visível")
			.testar();
	}());

	(function () {
		QUnit.module("invisível");

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("invisível")
			.doComando("INVISIVEL")
			.comDados()
			.testar();

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("visivel")
			.comValor(false)
			.daPrimitiva("invisível")
			.testar();
	}());

	(function () {
		QUnit.module("carimbar");

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("carimbar")
			.doComando("CARIMBAR")
			.comDados()
			.testar();
	}());
}(this));
