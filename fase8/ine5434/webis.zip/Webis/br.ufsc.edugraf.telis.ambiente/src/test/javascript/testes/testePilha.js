/*global QUnit*/
/*global TesteWebis*/
/*global sinon*/

(function () {
	"use strict";

	QUnit.begin(function (global) {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("obterNúmeroDeElementosNaPilha");

		TesteWebis
			.dePilha()
			.daPrimitiva("obterNúmeroDeElementosNaPilha")
			.comComandos()
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterNúmeroDeElementosNaPilha")
			.comComandos(10, "texto", true, [])
			.deixaNaPilha(10, "texto", true, [], 4)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterNúmeroDeElementosNaPilha")
			.comComandos([10, "texto", true, []])
			.deixaNaPilha([10, "texto", true, []], 1)
			.testar();
	}());
}(this));
