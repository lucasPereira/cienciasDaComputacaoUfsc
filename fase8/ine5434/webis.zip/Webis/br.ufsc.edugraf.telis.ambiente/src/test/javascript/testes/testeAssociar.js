/*global Associar*/
/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Palavra*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("associar");

		TesteWebis
			.dePilha()
			.comComandos("texto", 1, new PacoteDeSimbolo("SIMBOLO"), false, ["outra lista"], new Associar("nomeDaVariável"))
			.deixaNaPilha("texto", 1, new Simbolo("SIMBOLO"), false)
			.testar();

		TesteWebis
			.dePilha()
			.comComandos("texto", 1, new PacoteDeSimbolo("SIMBOLO"), ["outra lista"], false, new Associar("nomeDaVariável"))
			.deixaNaPilha("texto", 1, new Simbolo("SIMBOLO"), ["outra lista"])
			.testar();

		TesteWebis
			.dePilha()
			.comComandos("texto", 1, ["outra lista"], false, new PacoteDeSimbolo("SIMBOLO"), new Associar("nomeDaVariável"))
			.deixaNaPilha("texto", 1, ["outra lista"], false)
			.testar();

		TesteWebis
			.dePilha()
			.comComandos("texto", ["outra lista"], false, new PacoteDeSimbolo("SIMBOLO"), 1, new Associar("nomeDaVariável"))
			.deixaNaPilha("texto", ["outra lista"], false, new Simbolo("SIMBOLO"))
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(["outra lista"], false, new PacoteDeSimbolo("SIMBOLO"), 1, "texto", new Associar("nomeDaVariável"))
			.deixaNaPilha(["outra lista"], false, new Simbolo("SIMBOLO"), 1)
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(["outra lista"], new Associar("nomeDaVariável"), new Simbolo("nomeDaVariável"))
			.deixaNaPilha(["outra lista"])
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(false, new Associar("nomeDaVariável"), new Simbolo("nomeDaVariável"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), new Associar("nomeDaVariável"), new Simbolo("nomeDaVariável"))
			.deixaNaPilha(new Simbolo("SIMBOLO"))
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(1, new Associar("nomeDaVariável"), new Simbolo("nomeDaVariável"))
			.deixaNaPilha(1)
			.testar();

		TesteWebis
			.dePilha()
			.comComandos("texto", new Associar("nomeDaVariável"), new Simbolo("nomeDaVariável"))
			.deixaNaPilha("texto")
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(1, new Associar("variável"), new Simbolo("variável"))
			.deixaNaPilha(1)
			.testar();

		TesteWebis
			.deExcecao()
			.comComandos(1, new Associar("variável"), new Simbolo("variávelComOutroNome"))
			.lancaExcecao(Checagem.obterMensagemDePalavraNaoEncontrada("variávelComOutroNome"))
			.testar();

		TesteWebis
			.dePilha()
			.comComandos(true, 50, "texto", 1, new Simbolo("+"), new Simbolo("associar"), new Simbolo("texto1"), new Simbolo("texto1"))
			.deixaNaPilha(true, 50, 50)
			.testar();

		TesteWebis
			.dePilha()
			.comComandos([true, "texto", 1], ["a", new Simbolo("b"), new Simbolo("c")], new Simbolo("associar"), new Simbolo("b"), new Simbolo("c"), new Simbolo("a"))
			.deixaNaPilha("texto", 1, true)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("associar")
			.comComandos([1, 2], ["a"])
			.lancaExcecao(Checagem.obterMensagemDeEstruturaDeListaParaAssociarInvalida())
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.dosTipos(Palavra, Simbolo)
			.dosTipos(Palavra, String)
			.dosTipos(Array, Simbolo)
			.dosTipos(Array, Array)
			.dosTipos(Array, String)
			.daPrimitiva("associar")
			.comParametros("texto", 4)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.dosTipos(Palavra, Simbolo)
			.dosTipos(Palavra, String)
			.dosTipos(Array, Simbolo)
			.dosTipos(Array, Array)
			.dosTipos(Array, String)
			.daPrimitiva("associar")
			.comParametros(["texto", 4], ["nome", 2])
			.testar();
	}());
}(this));
