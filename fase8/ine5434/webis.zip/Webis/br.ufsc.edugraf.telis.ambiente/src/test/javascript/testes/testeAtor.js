/*global Associar*/
/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Palavra*/
/*global Simbolo*/
/*global TabelaDeAgendas*/
/*global TesteWebis*/
/*global Webis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("incluirModelo");

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros([], [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros([], "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros([], 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros([], true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros("texto", "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros("texto", 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros("texto", true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(10, [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(10, "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(10, 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(10, true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(false, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(false, [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(false, "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(false, 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirModelo")
			.comParametros(false, true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deMensagem()
			.daPrimitiva("incluirModelo")
			.comComandos("nomeDoModelo", ["nomeDaAgenda", [1, 2, 3], new Simbolo("incluirAgenda")])
			.doComando("INCLUIR_MODELO")
			.comDados({nomeDoModelo: "nomeDoModelo", agendas: {"nomeDaAgenda": [1, 2, 3]}})
			.testar();

		TesteWebis.deMensagem()
			.daPrimitiva("incluirModelo")
			.comComandos("nomeDoModelo", [], new Simbolo("incluirModelo"))
			.comComandos("nomeDoModelo", ["nomeDaAgenda", [1, 2, 3], new Simbolo("incluirAgenda")])
			.vezes(2)
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("incluirModelo")
			.comComandos("modeloQualquer", [new Simbolo("SIMBOLO"), "agenda", [1], new Simbolo("incluirAgenda")])
			.lancaExcecao(Checagem.obterMensagemDeDefinicaoDeModeloInvalida())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("incluirModelo")
			.comComandos("modeloQualquer", ["agenda", [1], new Simbolo("incluirAgenda"), []])
			.lancaExcecao(Checagem.obterMensagemDeDefinicaoDeModeloInvalida())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("incluirModelo")
			.comComandos("modeloQualquer", ["agenda", [1], new Simbolo("incluirAgenda"), "textoQualquer"])
			.lancaExcecao(Checagem.obterMensagemDeDefinicaoDeModeloInvalida())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("incluirModelo")
			.comComandos("modeloQualquer", ["agenda", [1], new Simbolo("incluirAgenda"), 1])
			.lancaExcecao(Checagem.obterMensagemDeDefinicaoDeModeloInvalida())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("incluirModelo")
			.comComandos("modeloQualquer", [true, "agenda", [1], new Simbolo("incluirAgenda")])
			.lancaExcecao(Checagem.obterMensagemDeDefinicaoDeModeloInvalida())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("incluirModelo")
			.comComandos("modeloQualquer", ["agenda", [1], new Simbolo("incluirAgemda")])
			.lancaExcecao(Checagem.obterMensagemDeDefinicaoDeModeloInvalida())
			.testar();
	}());

	(function () {
		QUnit.module("novo, nova");

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("novo")
			.comParametros([])
			.dosTipos(Simbolo)
			.dosTipos(String)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("nova")
			.comParametros(0)
			.dosTipos(Simbolo)
			.dosTipos(String)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("novo")
			.comParametros(true)
			.dosTipos(Simbolo)
			.dosTipos(String)
			.testar();

		TesteWebis.deMensagem()
			.daPrimitiva("nova")
			.comComandos("texto", 3, [3, "texto", new Simbolo("SIMBOLO"), false, [2]], "modelo")
			.doComando("NOVO")
			.comDados({nomeDoModelo: "modelo", parametros: [3, "texto", new Simbolo("SIMBOLO"), false, [2]], posicaoNoCodigo: Webis.posicaoDoSimboloExecutado})
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("novo")
			.comComandos("texto", 3, [3, "texto", new Simbolo("SIMBOLO"), false, [2]], new PacoteDeSimbolo("modelo"))
			.deixaNaPilha("texto", 3, [3, "texto", new Simbolo("SIMBOLO"), false, [2]])
			.testar();
	}());

	(function () {
		QUnit.module("iniciarAtor");

		TesteWebis.dePilha()
			.comAgenda("agendaA", [2, true, [], "texto", {nome: "inserirNoInício", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}])
			.comAgenda("agendaB", [5, {nome: "variavel", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Associar.tipo}, {nome: "variavel", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, {nome: "variavel", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, {nome: "+", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}])
			.comAgenda("agendaC", [[[[{ nome: "simbolo", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}]]], [4, 5], [{nome: "variavel1", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, "variavel2"], {nome: "associar", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, {nome: "variavel1", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, {nome: "variavel2", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}])
			.comAgenda("iniciar", [{nome: "agendaA", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, {nome: "agendaB", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}, {nome: "agendaC", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}])
			.deixaNaPilha(2, true, ["texto"], 10, [[[new Simbolo("simbolo", {linha: 0, coluna: 0})]]], 4, 5)
			.testar();

		TesteWebis.dePropriedade()
			.comAgenda("agendaA", [2, true, [], "texto", {nome: "inserirNoInício", posicaoNoCodigo: {linha: 0, coluna: 0}, tipo: Simbolo.tipo}])
			.daPropriedade("agendaA")
			.doElemento(TabelaDeAgendas)
			.testar();

		TesteWebis.dePropriedade()
			.daPropriedade("iniciar")
			.doElemento(TabelaDeAgendas)
			.testar();
	}());

	(function () {
		QUnit.module("suicidar");

		TesteWebis.deMensagem()
			.doAtor("identificadorDoAtor")
			.comComandos(5, new Simbolo("suicidar"), 10, new Simbolo("frente"))
			.doComando("SUICIDAR")
			.comDados({identificadorDoAtor: "identificadorDoAtor"})
			.testar();

		TesteWebis.dePilha()
			.doAtor("identificadorDoAtor")
			.comComandos(5, new Simbolo("suicidar"), 10, new Simbolo("frente"))
			.deixaNaPilha(5)
			.testar();
	}());
}(this));
