/*global Checagem*/
/*global Class*/
/*global Contexto*/
/*global QUnit*/
/*global Simbolo*/
/*global TabelaDeTratadores*/
/*global TratadorDeEstimulo*/
/*global Util*/
/*global Webis*/
/*global sinon*/

(function (global) {
	"use strict";

	var TesteDePrimitiva = new Class({
		initialize: function () {
			this.comandos = [];
			this.agendas = {};
			this.nomeDaPrimitiva = null;
			this.nomeDoAtor = undefined;
		},

		daPrimitiva: function (nomeDaPrimitiva) {
			this.nomeDaPrimitiva = nomeDaPrimitiva;
			return this;
		},

		doAtor: function (nomeDoAtor) {
			this.nomeDoAtor = nomeDoAtor;
			if (this.mensagem !== undefined) {
				this.mensagem.identificadorDoAtor = nomeDoAtor;
			}
			return this;
		},

		comComandos: function () {
			this.comandos.push.apply(this.comandos, arguments);
			return this;
		},

		comAgendas: function (agendas) {
			Object.merge(this.agendas, agendas);
			return this;
		},

		comAgenda: function (nome, agenda) {
			this.agendas[nome] = agenda;
			return this;
		},

		montarComandos: function () {
			if (Object.keys(this.agendas).length > 0) {
				return this.agendas;
			}
			var comandos = [];
			comandos.push.apply(comandos, arguments);
			comandos.push.apply(comandos, this.comandos);
			if (this.nomeDaPrimitiva !== null) {
				comandos.push(new Simbolo(this.nomeDaPrimitiva));
			}
			return comandos;
		}
	});

	var TesteDePilha = new Class({
		Extends: TesteDePrimitiva,

		initialize: function () {
			this.parent();
			this.pilha = [];
		},

		deixaNaPilha: function () {
			this.pilha.push.apply(this.pilha, arguments);
			return this;
		},

		testar: function () {
			var contexto = new Contexto();
			var comandos = this.montarComandos();
			var nomeDoAtor = this.nomeDoAtor;
			var pilha = this.pilha;
			var tituloDoTeste = String.formatar("Teste de pilha.");
			QUnit.asyncTest(tituloDoTeste, function () {
				Webis.inicializar(contexto, comandos, function () {
					var comandosTextual = Util.obterRepresentacaoTextualWebis(comandos);
					var pilhaTextual = Util.obterRepresentacaoTextualWebis(pilha);
					var mensagemDoTeste = "Comandos %@ deixam a pilha igual a: %@.";
					var mensagemFormatadaDoTeste = String.formatar(mensagemDoTeste, comandosTextual, pilhaTextual);
					QUnit.deepEqual(contexto.pilha, pilha, mensagemFormatadaDoTeste);
					QUnit.start();
				}, nomeDoAtor);
			});
		}
	});

	var TesteDeTiposDeParametros = new Class({
		Extends: TesteDePrimitiva,

		initialize: function () {
			this.parent();
			this.parametros = [];
			this.tipos = [];
		},

		comParametros: function () {
			this.parametros.push.apply(this.parametros, arguments);
			return this;
		},

		dosTipos: function () {
			var novosTipos = [];
			novosTipos.push.apply(novosTipos, arguments);
			this.tipos.push(novosTipos);
			return this;
		},

		testar: function () {
			var contexto = new Contexto();
			var comandos = this.montarComandos.apply(this, this.parametros);
			var nomeDoAtor = this.nomeDoAtor;
			var tipos = this.tipos;
			var parametros = this.parametros;
			var tituloDoTeste = String.formatar("Teste de tipos de parâmetros.");
			QUnit.asyncTest(tituloDoTeste, function () {
				Webis.inicializar(contexto, comandos, function (excecao) {
					var comandosTextual = Util.obterRepresentacaoTextualWebis(comandos);
					var tiposRecebidosTextual = Checagem.obterTiposDosElementosTextual(parametros);
					var tiposDesejadosTextual = Checagem.obterTiposTextual(tipos);
					var mensagemDoTeste = "Comandos %@ lançam uma exceção Webis. Tipos recebidos: %@. Tipos desejados %@.";
					var mensagemFormatadaDoTeste = String.formatar(mensagemDoTeste, comandosTextual, tiposRecebidosTextual, tiposDesejadosTextual);
					if (excecao !== undefined) {
						QUnit.equal(excecao.mensagem, Checagem.obterMensagemDeTiposDeParametrosInvalidos(tipos), mensagemFormatadaDoTeste);
					} else {
						QUnit.ok(false, "Não foi lançada nenhuma exceção.");
					}
					QUnit.start();
				}, nomeDoAtor);
			});
		}
	});

	var TesteDeExcecao = new Class({
		Extends: TesteDePrimitiva,

		initialize: function () {
			this.parent();
			this.excecao = undefined;
		},

		lancaExcecao: function (excecao) {
			this.excecao = excecao;
			return this;
		},

		testar: function () {
			var contexto = new Contexto();
			var comandos = this.montarComandos();
			var nomeDoAtor = this.nomeDoAtor;
			var mensagemDaExcecao = this.excecao;
			var tituloDoTeste = String.formatar("Teste de exceção.");
			QUnit.asyncTest(tituloDoTeste, function () {
				Webis.inicializar(contexto, comandos, function (excecao) {
					var comandosTextual = Util.obterRepresentacaoTextualWebis(comandos);
					var mensagemDoTeste = "Comandos %@ lançam a exceção Webis: %@";
					var mensagemFormatadaDoTeste = String.formatar(mensagemDoTeste, comandosTextual, mensagemDaExcecao);
					if (excecao !== undefined) {
						QUnit.equal(excecao.mensagem, mensagemDaExcecao, mensagemFormatadaDoTeste);
					} else {
						QUnit.ok(false, "Não foi lançada nenhuma exceção.");
					}
					QUnit.start();
				}, nomeDoAtor);
			});
		}
	});

	var TesteDePropriedade = new Class({
		Extends: TesteDePrimitiva,

		initialize: function () {
			this.parent();
			this.nomeDaPropriedade = undefined;
			this.elemento = undefined;
			this.valorEsperado = undefined;
		},

		daPropriedade: function (nomeDaPropriedade) {
			this.nomeDaPropriedade = nomeDaPropriedade;
			return this;
		},

		doElemento: function (elemento) {
			this.elemento = elemento;
			return this;
		},

		comValor: function (valorEsperado) {
			this.valorEsperado = valorEsperado;
			return this;
		},

		testar: function () {
			var contexto = new Contexto();
			var comandos = this.montarComandos();
			var nomeDoAtor = this.nomeDoAtor;
			var elemento = this.elemento;
			var nomeDaPropriedade = this.nomeDaPropriedade;
			var valorEsperado = this.valorEsperado;
			var tituloDoTeste = String.formatar("Teste de propriedade.");
			QUnit.asyncTest(tituloDoTeste, function () {
				Webis.inicializar(contexto, comandos, function (excecao) {
					var comandosTextual = Util.obterRepresentacaoTextualWebis(comandos);
					var mensagemDoTeste;
					var mensagemFormatadaDoTeste;
					if (valorEsperado !== undefined) {
						mensagemDoTeste = "Comandos %@ fixam a propriedade %@ do sistema com o valor: %@.";
						mensagemFormatadaDoTeste = String.formatar(mensagemDoTeste, comandosTextual, nomeDaPropriedade, Util.obterRepresentacaoTextualWebis(valorEsperado));
						QUnit.deepEqual(elemento[nomeDaPropriedade], valorEsperado, mensagemFormatadaDoTeste);
					} else {
						mensagemDoTeste = "Comandos %@ fixam a propriedade %@ do sistema.";
						mensagemFormatadaDoTeste = String.formatar(mensagemDoTeste, comandosTextual, nomeDaPropriedade);
						QUnit.ok(elemento[nomeDaPropriedade], mensagemFormatadaDoTeste);
					}
					QUnit.start();
				}, nomeDoAtor);
			});
		}
	});

	var TesteDeMensagem = new Class({
		Extends: TesteDePrimitiva,

		initialize: function () {
			this.parent();
			this.mensagem = {};
			this.quantidadeDeVezes = 1;
			this.testarArgumentos = false;
		},

		comDado: function (nome, valor) {
			this.mensagem[nome] = valor;
			this.testarArgumentos = true;
			return this;
		},

		comDados: function (dados) {
			Object.merge(this.mensagem, dados);
			this.testarArgumentos = true;
			return this;
		},

		doComando: function (comando) {
			this.mensagem.comando = comando;
			return this;
		},

		vezes: function (quantidadeDeVezes) {
			this.quantidadeDeVezes = quantidadeDeVezes;
			return this;
		},

		testar: function () {
			var contexto = new Contexto();
			var comandos = this.montarComandos();
			var nomeDoAtor = this.nomeDoAtor;
			var mensagem = this.mensagem;
			var quantidadeDeVezes = this.quantidadeDeVezes;
			var testarArgumentos = this.testarArgumentos;
			var tituloDoTeste = String.formatar("Teste de mensagem.");
			Util.normalizarComandos(mensagem);
			QUnit.asyncTest(tituloDoTeste, function () {
				global.postMessage = sinon.spy();
				Webis.inicializar(contexto, comandos, function (excecao) {
					var mensagemRecebida = global.postMessage.lastCall.args[0];
					var comandosTextual = Util.obterRepresentacaoTextualWebis(comandos);
					var quantidadeDeVezesTextual = String.formatar("%@ vez%@", quantidadeDeVezes, (quantidadeDeVezes === 1) ? "" : "es");
					var mensagemDoTesteQuantidade = "Comandos %@ enviam a mensagem %@ para o ecossistema.";
					var mensagemFormatadaDoTesteQuantidade = String.formatar(mensagemDoTesteQuantidade, comandosTextual, quantidadeDeVezesTextual);
					if (testarArgumentos) {
						var mensagemTextual = Util.obterRepresentacaoTextualWebis(mensagem);
						var mensagemDoTeste = "Comandos %@ enviam a mensagem %@ para o ecossistema.";
						var mensagemFormatadaDoTeste = String.formatar(mensagemDoTeste, comandosTextual, mensagemTextual);
						QUnit.deepEqual(mensagemRecebida, mensagem, mensagemFormatadaDoTeste);
					}
					QUnit.equal(global.postMessage.callCount, quantidadeDeVezes, mensagemFormatadaDoTesteQuantidade);
					QUnit.start();
				}, nomeDoAtor);
			});
		}
	});

	var TesteDeEstimulo = new Class({
		Extends: TesteDeMensagem,

		initialize: function () {
			this.parent();
			this.pilha = [];
			this.estimulo = undefined;
			this.tabelaDeTratadoresLocal = [];
		},

		comTratador: function (filtro, comandos) {
			this.tabelaDeTratadoresLocal.unshift(new TratadorDeEstimulo(filtro, comandos));
			return this;
		},

		comEstimulo: function (estimulo) {
			this.estimulo = estimulo;
			return this;
		},

		deixaNaPilha: function () {
			this.pilha.push.apply(this.pilha, arguments);
			return this;
		},

		testar: function () {
			var contexto = new Contexto();
			var comandos = this.montarComandos();
			var nomeDoAtor = this.nomeDoAtor;
			var mensagem = this.mensagem;
			var quantidadeDeVezes = this.quantidadeDeVezes;
			var pilha = this.pilha;
			var estimulo = this.estimulo;
			var tabelaDeTratadoresLocal = this.tabelaDeTratadoresLocal;
			var testarArgumentos = this.testarArgumentos;
			var tituloDoTeste = String.formatar("Teste de estímulo.");
			Util.normalizarComandos(mensagem);
			QUnit.asyncTest(tituloDoTeste, function () {
				Webis.inicializar(contexto, comandos, function () {
					global.postMessage = sinon.spy();
					TabelaDeTratadores.append(tabelaDeTratadoresLocal);
					Webis.receberEstimulo(estimulo, function () {
						var comandosTextual = Util.obterRepresentacaoTextualWebis(comandos);
						var estimuloTextual = Util.obterRepresentacaoTextualWebis(estimulo);
						var pilhaTextual = Util.obterRepresentacaoTextualWebis(pilha);
						var tabelaDeTratadoresTextual = Util.obterRepresentacaoTextualWebis(tabelaDeTratadoresLocal);
						var quantidadeDeVezesTextual = String.formatar("%@ vez%@", quantidadeDeVezes, (quantidadeDeVezes === 1) ? "" : "es");
						var mensagemDoTesteDeMensagemQuantidade = "Estímulo %@ envia a mensagem %@ para o ecossistema.";
						var mesagemDoTesteDeTratadores = "Tabela de tratadores fica igual a: %@.";
						var mensagemDoTesteDePilha = "Comandos %@ e estímulo %@ deixam a pilha igual a: %@.";
						var mensagemFormatadaDoTesteDeMensagemQuantidade = String.formatar(mensagemDoTesteDeMensagemQuantidade, estimuloTextual, quantidadeDeVezesTextual);
						var mensagemFormatadaDoTesteDeTratadores = String.formatar(mesagemDoTesteDeTratadores, tabelaDeTratadoresTextual);
						var mensagemFormatadaDoTesteDePilha = String.formatar(mensagemDoTesteDePilha, comandosTextual, estimuloTextual, pilhaTextual);
						if (testarArgumentos) {
							var mensagemRecebida = global.postMessage.firstCall.args[0];
							var mensagemTextual = Util.obterRepresentacaoTextualWebis(mensagem);
							var mensagemDoTesteDeMensagem = "Estímulo %@ envia a mensagem %@ para o ecossistema.";
							var mensagemFormatadaDoTesteDeMensagem = String.formatar(mensagemDoTesteDeMensagem, estimuloTextual, mensagemTextual);
							QUnit.deepEqual(mensagem, mensagemRecebida, mensagemFormatadaDoTesteDeMensagem);
						}
						QUnit.equal(global.postMessage.callCount, quantidadeDeVezes, mensagemFormatadaDoTesteDeMensagemQuantidade);
						QUnit.deepEqual(TabelaDeTratadores, tabelaDeTratadoresLocal, mensagemFormatadaDoTesteDeTratadores);
						QUnit.deepEqual(contexto.pilha, pilha, mensagemFormatadaDoTesteDePilha);
						QUnit.start();
					});
				}, nomeDoAtor);
			});
		}
	});

	var TesteWebis = {
		deTiposDeParametros: function () {
			return new TesteDeTiposDeParametros();
		},

		dePilha: function () {
			return new TesteDePilha();
		},

		deExcecao: function () {
			return new TesteDeExcecao();
		},

		dePropriedade: function () {
			return new TesteDePropriedade();
		},

		deMensagem: function () {
			return new TesteDeMensagem();
		},

		deEstimulo: function () {
			return new TesteDeEstimulo();
		}
	};

	global.TesteWebis = TesteWebis;
}(this));
