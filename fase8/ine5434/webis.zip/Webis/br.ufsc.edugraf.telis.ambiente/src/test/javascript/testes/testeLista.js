/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global Palavra*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("inserirNoInício");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirNoInício")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "palavra")
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirNoInício")
			.comParametros(1, "palavra")
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirNoInício")
			.comParametros(true, "palavra")
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos("Texto", new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha("SIMBOLOTexto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos("Texto", [10, true, "OutroTexto", new Simbolo("SIMBOLO")])
			.deixaNaPilha("[10 verdadeiro OutroTexto SIMBOLO]Texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos("TextoA", "TextoB")
			.deixaNaPilha("TextoBTextoA")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos("Texto", 100)
			.deixaNaPilha("100Texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos("Texto", false)
			.deixaNaPilha("falsoTexto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos([1, 2, 3], new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha([new Simbolo("SIMBOLO"), 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos([1, 2, 3], [10, true, "OutroTexto", new Simbolo("SIMBOLO")])
			.deixaNaPilha([[10, true, "OutroTexto", new Simbolo("SIMBOLO")], 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos([1, 2, 3], "TextoB")
			.deixaNaPilha(["TextoB", 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos([1, 2, 3], 0)
			.deixaNaPilha([0, 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoInício")
			.comComandos([1, 2, 3], false)
			.deixaNaPilha([false, 1, 2, 3])
			.testar();
	}());

	(function () {
		QUnit.module("inserirNoFim");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirNoFim")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "palavra")
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirNoFim")
			.comParametros(1, "palavra")
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirNoFim")
			.comParametros(true, "palavra")
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos("Texto", new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha("TextoSIMBOLO")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos("Texto", [10, true, "OutroTexto", new Simbolo("SIMBOLO")])
			.deixaNaPilha("Texto[10 verdadeiro OutroTexto SIMBOLO]")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos("TextoA", "TextoB")
			.deixaNaPilha("TextoATextoB")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos("Texto", 100)
			.deixaNaPilha("Texto100")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos("Texto", false)
			.deixaNaPilha("Textofalso")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos([1, 2, 3], new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha([1, 2, 3, new Simbolo("SIMBOLO")])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos([1, 2, 3], [10, true, "OutroTexto", new Simbolo("SIMBOLO")])
			.deixaNaPilha([1, 2, 3, [10, true, "OutroTexto", new Simbolo("SIMBOLO")]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos([1, 2, 3], "TextoB")
			.deixaNaPilha([1, 2, 3, "TextoB"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos([1, 2, 3], 4)
			.deixaNaPilha([1, 2, 3, 4])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirNoFim")
			.comComandos([1, 2, 3], false)
			.deixaNaPilha([1, 2, 3, false])
			.testar();
	}());

	(function () {
		QUnit.module("primeiro");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("primeiro")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("primeiro")
			.comParametros(10)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("primeiro")
			.comParametros(true)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("primeiro")
			.comComandos("texto")
			.deixaNaPilha("t")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("primeiro")
			.comComandos(["texto", 2, true, new Simbolo("SIMBOLO"), []])
			.deixaNaPilha("texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("primeiro")
			.comComandos([2])
			.deixaNaPilha(2)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("primeiro")
			.comComandos("")
			.lancaExcecao(Checagem.obterMensagemDeSequenciaVazia())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("primeiro")
			.comComandos([])
			.lancaExcecao(Checagem.obterMensagemDeSequenciaVazia())
			.testar();
	}());

	(function () {
		QUnit.module("último");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("último")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("último")
			.comParametros(10)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("último")
			.comParametros(true)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("último")
			.comComandos("texto")
			.deixaNaPilha("o")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("último")
			.comComandos(["texto", 2, true, new Simbolo("SIMBOLO"), []])
			.deixaNaPilha([])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("último")
			.comComandos([2])
			.deixaNaPilha(2)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("último")
			.comComandos("")
			.lancaExcecao(Checagem.obterMensagemDeSequenciaVazia())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("último")
			.comComandos([])
			.lancaExcecao(Checagem.obterMensagemDeSequenciaVazia())
			.testar();
	}());

	(function () {
		QUnit.module("obterElemento");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros("texto", "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(10, [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(10, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(false, [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(false, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterElemento")
			.comParametros(true, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], [new Simbolo("SIMBOLO"), 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], [[], 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], ["texto", 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], [true, 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], [])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], [2])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([[1, 2, 3], [1, 2, 3], [1, 2, 3]], [2, 2, 1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([], 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos("", 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, 2, 3], 4)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos([1, [2], 3], [2, 2])
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos("123", 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("obterElemento")
			.comComandos("123", 4)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos("texto", 1)
			.deixaNaPilha("t")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos("texto", 5)
			.deixaNaPilha("o")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos([11, 22, 333], 1)
			.deixaNaPilha(11)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos([11, 22, 33], 2)
			.deixaNaPilha(22)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos([11, 32, 33], 3)
			.deixaNaPilha(33)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos([[1, 2, 3], [4, 5, 6], [7, 8, 9]], [2, 2])
			.deixaNaPilha(5)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos([[["item1"], ["item2", "item3"]], ["item4"]], [1, 2, 1])
			.deixaNaPilha("item2")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterElemento")
			.comComandos([[["item1"], ["item2", "item3"]], ["item4"]], [1, 2, 1, 5])
			.deixaNaPilha("2")
			.testar();
	}());

	(function () {
		QUnit.module("obterTamanho");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterTamanho")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterTamanho")
			.comParametros(10)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("obterTamanho")
			.comParametros(true)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterTamanho")
			.comComandos([])
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterTamanho")
			.comComandos([1, 2, 3])
			.deixaNaPilha(3)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterTamanho")
			.comComandos("")
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("obterTamanho")
			.comComandos("texto")
			.deixaNaPilha(5)
			.testar();
	}());

	(function () {
		QUnit.module("gerarLista");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarLista")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarLista")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarLista")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("gerarLista")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("gerarLista")
			.comComandos(1)
			.lancaExcecao(Checagem.obterMensagemDeParametrosInsuficientes())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("gerarLista")
			.comComandos(false, true, 1)
			.deixaNaPilha(false, [true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("gerarLista")
			.comComandos(0)
			.deixaNaPilha([])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("gerarLista")
			.comComandos(false, true, 0)
			.deixaNaPilha(false, true, [])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("gerarLista")
			.comComandos(false, true, -10)
			.deixaNaPilha(false, true, [])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("gerarLista")
			.comComandos(false, true, 2)
			.deixaNaPilha([false, true])
			.testar();
	}());

	(function () {
		QUnit.module("inserirElemento");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), 1, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, 1)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros([], 1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros([], 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros([], 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros("texto", 1, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros("texto", 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros("texto", 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros("texto", 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(1, 1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(1, 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(1, 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(1, 1, 1)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(1, 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(true, 1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(true, 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(true, 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(true, 1, 1)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("inserirElemento")
			.comParametros(true, 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, [new Simbolo("SIMBOLO"), 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, [[], 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, ["texto", 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, [true, 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, [])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 0, [1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([[1, 2, 3], [1, 2, 3], [1, 2, 3]], 1, [2, 2, 1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([], 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1, 5)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos([1, [2], 3], 1, [2, 3])
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos("", 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos("123", 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("inserirElemento")
			.comComandos("123", 1, 5)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 0, 1)
			.deixaNaPilha([0, 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 1.5, 2)
			.deixaNaPilha([1, 1.5, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([], true, 1)
			.deixaNaPilha([true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1], true, 2)
			.deixaNaPilha([1, true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, "teto", 3], "x", [2, 3])
			.deixaNaPilha([1, "texto", 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, [2.25, 2.75], 3], 2.5, [2, 2])
			.deixaNaPilha([1, [2.25, 2.5, 2.75], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, ["teto"], 3], "x", [2, 1, 3])
			.deixaNaPilha([1, ["texto"], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, [2.25, 2.5], [3, [5, 6]]], 4, [3, 2, 1])
			.deixaNaPilha([1, [2.25, 2.5], [3, [4, 5, 6]]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([[[[]]]], true, [1, 1, 1, 1])
			.deixaNaPilha([[[[true]]]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos("textonecessario", 10, 6)
			.deixaNaPilha("texto10necessario")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos("", "Texto", 1)
			.deixaNaPilha("Texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos("T", "exto", 2)
			.deixaNaPilha("Texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, 2, 3], 4, 4)
			.deixaNaPilha([1, 2, 3, 4])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos([1, [2], 3], 3, [2, 2])
			.deixaNaPilha([1, [2, 3], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("inserirElemento")
			.comComandos("123", "4", 4)
			.deixaNaPilha("1234")
			.testar();
	}());

	(function () {
		QUnit.module("soletrar");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("soletrar")
			.comParametros(new PacoteDeSimbolo("Simbolo"))
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("soletrar")
			.comParametros(false)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("soletrar")
			.comParametros(20)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("soletrar")
			.comComandos("texto")
			.deixaNaPilha("t", "e", "x", "t", "o")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("soletrar")
			.comComandos("")
			.deixaNaPilha()
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("soletrar")
			.comComandos(["texto", true, new Simbolo("SIMBOLO"), 1, [1, 2, 3]])
			.deixaNaPilha("texto", true, new Simbolo("SIMBOLO"), 1, [1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("soletrar")
			.comComandos([])
			.deixaNaPilha()
			.testar();
	}());

	(function () {
		QUnit.module("rartelos");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("rartelos")
			.comParametros(new PacoteDeSimbolo("Simbolo"))
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("rartelos")
			.comParametros(false)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("rartelos")
			.comParametros(20)
			.dosTipos(Array)
			.dosTipos(String)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("rartelos")
			.comComandos("texto")
			.deixaNaPilha("o", "t", "x", "e", "t")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("rartelos")
			.comComandos("")
			.deixaNaPilha()
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("rartelos")
			.comComandos(["texto", true, new Simbolo("SIMBOLO"), 1, [1, 2, 3]])
			.deixaNaPilha([1, 2, 3], 1, new Simbolo("SIMBOLO"), true, "texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("rartelos")
			.comComandos([])
			.deixaNaPilha()
			.testar();
	}());

	(function () {
		QUnit.module("substituirElemento");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), 1, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, 1)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros([], 1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros([], 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros([], 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros("texto", 1, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros("texto", 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros("texto", 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros("texto", 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(1, 1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(1, 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(1, 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(1, 1, 1)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(1, 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(true, 1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(true, 1, [])
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(true, 1, "texto")
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(true, 1, 1)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("substituirElemento")
			.comParametros(true, 1, true)
			.dosTipos(Array, Palavra, Array)
			.dosTipos(Array, Palavra, Number)
			.dosTipos(Array, Array, Array)
			.dosTipos(Array, Array, Number)
			.dosTipos(String, Palavra, Number)
			.dosTipos(String, Array, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, [new Simbolo("SIMBOLO"), 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, [[], 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, ["texto", 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, [true, 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, [])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 0, [1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([[1, 2, 3], [1, 2, 3], [1, 2, 3]], 1, [2, 2, 1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([], 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1, 4)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos([1, [2], 3], 1, [2, 2])
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos("", 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos("123", 1, 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("substituirElemento")
			.comComandos("123", 1, 4)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 0, 1)
			.deixaNaPilha([0, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, 2, 3], 1.5, 2)
			.deixaNaPilha([1, 1.5, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([false], true, 1)
			.deixaNaPilha([true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, false], true, 2)
			.deixaNaPilha([1, true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, "teXto", 3], "x", [2, 3])
			.deixaNaPilha([1, "texto", 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, [2.25, 2, 2.75], 3], 2.5, [2, 2])
			.deixaNaPilha([1, [2.25, 2.5, 2.75], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, ["teXto"], 3], "x", [2, 1, 3])
			.deixaNaPilha([1, ["texto"], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([1, [2.25, 2.5], [3, [5, 6]]], 4, [3, 2, 1])
			.deixaNaPilha([1, [2.25, 2.5], [3, [4, 6]]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos([[[[false]]]], true, [1, 1, 1, 1])
			.deixaNaPilha([[[[true]]]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos("textoXnecessario", 10, 6)
			.deixaNaPilha("texto10necessario")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos("T", "Texto", 1)
			.deixaNaPilha("Texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("substituirElemento")
			.comComandos("Te", "exto", 2)
			.deixaNaPilha("Texto")
			.testar();
	}());

	(function () {
		QUnit.module("removerElemento");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 1)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros("texto", "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(1, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(1, [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(1, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(1, 1)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(1, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(true, [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(true, 1)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("removerElemento")
			.comParametros(true, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(String, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], [new Simbolo("SIMBOLO"), 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], [[], 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], ["texto", 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], [true, 1])
			.lancaExcecao(Checagem.obterMensagemDeListaDeIndicesInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], [])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], [1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([[1, 2, 3], [1, 2, 3], [1, 2, 3]], [2, 2, 1])
			.lancaExcecao(Checagem.obterMensagemDeDimensaoDeListaInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([], 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], 4)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos([1, [2], 3], [2, 2])
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos("", 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos("123", 0)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("removerElemento")
			.comComandos("123", 4)
			.lancaExcecao(Checagem.obterMensagemDeIndiceForaDosLimites())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], 1)
			.deixaNaPilha([2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, 2, 3], 2)
			.deixaNaPilha([1, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([false], 1)
			.deixaNaPilha([])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, false], 2)
			.deixaNaPilha([1])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, "teXto", 3], [2, 3])
			.deixaNaPilha([1, "teto", 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, [2.25, 2, 2.75], 3], [2, 2])
			.deixaNaPilha([1, [2.25, 2.75], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, ["teXto"], 3], [2, 1, 3])
			.deixaNaPilha([1, ["teto"], 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([1, [2.25, 2.5], [3, [5, 6]]], [3, 2, 1])
			.deixaNaPilha([1, [2.25, 2.5], [3, [6]]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos([[[[false]]]], [1, 1, 1, 1])
			.deixaNaPilha([[[[]]]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos("textoXnecessario", 6)
			.deixaNaPilha("textonecessario")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos("T", 1)
			.deixaNaPilha("")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("removerElemento")
			.comComandos("Te", 2)
			.deixaNaPilha("T")
			.testar();
	}());

	(function () {
		QUnit.module("concatenar");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), false)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros([], 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros([], false)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros("texto", false)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(10, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(10, 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(10, false)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(false, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(false, 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("concatenar")
			.comParametros(true, false)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos([1, 2, 3], [4, 5, 6])
			.deixaNaPilha([1, 2, 3, 4, 5, 6])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos([1, 2, 3], [])
			.deixaNaPilha([1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos([], [4, 5, 6])
			.deixaNaPilha([4, 5, 6])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos([], [])
			.deixaNaPilha([])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos("tex", "to")
			.deixaNaPilha("texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos("", "to")
			.deixaNaPilha("to")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos("tex", "")
			.deixaNaPilha("tex")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("concatenar")
			.comComandos("", "")
			.deixaNaPilha("")
			.testar();
	}());

	(function () {
		QUnit.module("paraCada");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros([], 10)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros("textoA", "textoB")
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(10, [])
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(20, 10)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(20, true)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(true, [])
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(true, 10)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("paraCada")
			.comParametros(false, true)
			.dosTipos(Array, Array)
			.dosTipos(String, Array)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("paraCada")
			.comComandos(["a", "b", "c"], [new Simbolo("mostrar")])
			.lancaExcecao(Checagem.obterMensagemDeParametrosInsuficientes())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("paraCada")
			.comComandos(["abc"], [new Simbolo("mostrar")])
			.lancaExcecao(Checagem.obterMensagemDeParametrosInsuficientes())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([1, 2, 3], [2, new Simbolo("*")])
			.deixaNaPilha([2, 4, 6])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([1, 2, 3], [new Simbolo("contarGiro"), new Simbolo("*")])
			.deixaNaPilha([1, 4, 9])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([1, 2, 3], [new Simbolo("contarGiro"), new Simbolo("*"), "w"])
			.deixaNaPilha(["w", "w", "w"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos(["a", "b", "c"], [])
			.deixaNaPilha(["a", "b", "c"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([], [])
			.deixaNaPilha([])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
			.comComandos([[1, new Simbolo("+")], new Simbolo("paraCada")])
			.deixaNaPilha([[2, 3, 4], [5, 6, 7], [8, 9, 10]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
			.comComandos([[1, new Simbolo("+")], new Simbolo("paraCada"), 10])
			.deixaNaPilha([10, 10, 10])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos([[1, 2, 3], [4, 5, 6], [7, 8, 9]])
			.comComandos([[new Simbolo("contarGiro")], new Simbolo("paraCada")])
			.deixaNaPilha([[1, 2, 3], [1, 2, 3], [1, 2, 3]])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos("TXT", [".", new Simbolo("+")])
			.deixaNaPilha(["T.", "X.", "T."])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos("TXT", [])
			.deixaNaPilha(["T", "X", "T"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos("TXT", [new Simbolo("contarGiro"), new Simbolo("+")])
			.deixaNaPilha(["T1", "X2", "T3"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("paraCada")
			.comComandos("", [])
			.deixaNaPilha([])
			.testar();
	}());
}(this));
