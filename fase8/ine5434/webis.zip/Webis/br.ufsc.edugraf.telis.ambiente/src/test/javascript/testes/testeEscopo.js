/*global Escopo*/
/*global QUnit*/

(function (global) {
	"use strict";

	QUnit.module("escopo");

	QUnit.test("Teste personalizado.", function () {
		var escopo = new Escopo();
		var nomeDaVariavel = "variavel";
		escopo.escrever(nomeDaVariavel, 10);
		QUnit.equal(escopo.ler(nomeDaVariavel), 10, "Variável escrita em escopo é lida com o valor escrito.");
		escopo.escrever(nomeDaVariavel, 20);
		QUnit.equal(escopo.ler(nomeDaVariavel), 20, "Variável reescrita em escopo é lida com valor atualizado.");
	});

	QUnit.test("Teste personalizado.", function () {
		var escopoPai = new Escopo();
		var escopoFilho = escopoPai.criarEscopoFilho();
		var nomeDaVariavel = "variavel";
		escopoPai.escrever(nomeDaVariavel, [10]);
		QUnit.deepEqual(escopoPai.ler(nomeDaVariavel), [10], "Variável escrita em escopo pai é lida pelo escopo pai.");
		QUnit.deepEqual(escopoFilho.ler(nomeDaVariavel), [10], "Variável escrita em escopo pai é lida pelo escopo filho.");
	});

	QUnit.test("Teste personalizado.", function () {
		var escopoPai = new Escopo();
		var escopoFilho = escopoPai.criarEscopoFilho();
		var nomeDaVariavel = "variavel";
		escopoFilho.escrever(nomeDaVariavel, 10);
		QUnit.equal(escopoFilho.ler(nomeDaVariavel), 10, "Variável escrita apenas pelo escopo filho é lida pelo escopo filho.");
		QUnit.equal(escopoPai.ler(nomeDaVariavel), undefined, "Variável escrita apenas pelo escopo filho é lida como indefinida pelo escopo pai.");
	});

	QUnit.test("Teste personalizado.", function () {
		var escopoPai = new Escopo();
		var escopoFilho = escopoPai.criarEscopoFilho();
		var nomeDaVariavel = "variavel";
		QUnit.equal(escopoPai.ler(nomeDaVariavel), undefined, "Variável que não existe em escopo pai é lida como indefinida.");
		QUnit.equal(escopoFilho.ler(nomeDaVariavel), undefined, "Variável que não existe nem em escopo pai nem em escopo filho é lida como indefinida.");
	});

	QUnit.test("Teste personalizado.", function () {
		var escopoPai = new Escopo();
		var escopoFilho = escopoPai.criarEscopoFilho();
		var nomeDaVariavel = "variavel";
		escopoPai.escrever(nomeDaVariavel, 10);
		QUnit.equal(escopoPai.ler(nomeDaVariavel), 10, "Variável escrita por escopo pai é lida pelor escopo pai.");
		escopoFilho.escrever(nomeDaVariavel, 20);
		QUnit.equal(escopoFilho.ler(nomeDaVariavel), 20, "Variável reescrita por escopo filho é lida pelo escopo filho.");
		QUnit.equal(escopoPai.ler(nomeDaVariavel), 20, "Variável reescrita por escopo filho é lida pelo escopo pai com valor atualizado.");
	});

	QUnit.test("Teste personalizado.", function () {
		var escopoPai = new Escopo();
		var escopoFilho = escopoPai.criarEscopoFilho();
		var nomeDaVariavel = "variavel";
		escopoFilho.escrever(nomeDaVariavel, 10);
		escopoPai.escrever(nomeDaVariavel, 20);
		QUnit.equal(escopoFilho.ler(nomeDaVariavel), 10, "Variável escrita primeiramente por escopo filho e depois escrita por escopo pai é lida pelo escopo filho com o valor que este escreveu.");
		QUnit.equal(escopoPai.ler(nomeDaVariavel), 20, "Variável escrita primeiramente por escopo filho e depois escrita por escopo pai é lida pelo escopo pai com o valor que este escreveu.");
	});
}(this));
