/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("arcoTangente");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("arcoTangente")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("arcoTangente")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("arcoTangente")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("arcoTangente")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("arcoTangente")
			.comComandos(0)
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("arcoTangente")
			.comComandos(0.5773502691896257)
			.deixaNaPilha(29.999999999999996)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("arcoTangente")
			.comComandos(1.7320508075688772)
			.deixaNaPilha(59.99999999999999)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("arcoTangente")
			.comComandos(-1)
			.deixaNaPilha(315)
			.testar();
	}());

	(function () {
		QUnit.module("seno");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("seno")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("seno")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("seno")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("seno")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(0)
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(30)
			.deixaNaPilha(0.49999999999999994)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(45)
			.deixaNaPilha(0.7071067811865475)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(60)
			.deixaNaPilha(0.8660254037844386)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(90)
			.deixaNaPilha(1)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(135)
			.deixaNaPilha(0.7071067811865476)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(180)
			.deixaNaPilha(1.2246063538223773e-16)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(225)
			.deixaNaPilha(-0.7071067811865475)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(270)
			.deixaNaPilha(-1)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(315)
			.deixaNaPilha(-0.7071067811865477)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("seno")
			.comComandos(360)
			.deixaNaPilha(0)
			.testar();
	}());

	(function () {
		QUnit.module("cosseno");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("cosseno")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("cosseno")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("cosseno")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("cosseno")
			.comParametros(true)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(0)
			.deixaNaPilha(1)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(30)
			.deixaNaPilha(0.8660254037844387)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(45)
			.deixaNaPilha(0.7071067811865476)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(60)
			.deixaNaPilha(0.5000000000000001)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(90)
			.deixaNaPilha(6.123031769111886e-17)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(135)
			.deixaNaPilha(-0.7071067811865475)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(180)
			.deixaNaPilha(-1)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(225)
			.deixaNaPilha(-0.7071067811865477)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(270)
			.deixaNaPilha(-1.836909530733566e-16)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(315)
			.deixaNaPilha(0.7071067811865474)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("cosseno")
			.comComandos(360)
			.deixaNaPilha(1)
			.testar();
	}());
}(this));
