/*global Ator*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("som");

		TesteWebis
			.dePropriedade()
			.doElemento(Ator)
			.daPropriedade("comSom")
			.comValor(false)
			.testar();
	}());

	(function () {
		QUnit.module("fixarSom");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSom")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSom")
			.comParametros([])
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSom")
			.comParametros(10)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSom")
			.comParametros(false)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarSom")
			.comComandos("uriQualquer")
			.doComando("FIXAR_SOM")
			.comDados({uri: "uriQualquer", posicaoNoCodigo: undefined})
			.testar();
	}());

	(function () {
		QUnit.module("fixarSomContínuo");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSomContínuo")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSomContínuo")
			.comParametros([])
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSomContínuo")
			.comParametros(10)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("fixarSomContínuo")
			.comParametros(false)
			.dosTipos(String)
			.testar();

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("fixarSomContínuo")
			.comComandos("uriQualquer")
			.doComando("FIXAR_SOM_CONTINUO")
			.comDados({uri: "uriQualquer", posicaoNoCodigo: undefined})
			.testar();
	}());

	(function () {
		QUnit.module("calibrarSom");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("calibrarSom")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("calibrarSom")
			.comParametros([])
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("calibrarSom")
			.comParametros("texto")
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("calibrarSom")
			.comParametros(false)
			.dosTipos(Number)
			.testar();

		TesteWebis
			.deMensagem()
			.daPrimitiva("calibrarSom")
			.comComandos(10)
			.doComando("CALIBRAR_SOM")
			.comDados({calibragemDeSom: 10})
			.testar();
	}());

	(function () {
		QUnit.module("pegarMicrofone");

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("pegarMicrofone")
			.doComando("PEGAR_MICROFONE")
			.comDados({})
			.testar();
	}());

	(function () {
		QUnit.module("comSom");

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("comSom")
			.doComando("COM_SOM")
			.comDados({})
			.testar();

		TesteWebis
			.dePropriedade()
			.daPrimitiva("comSom")
			.doElemento(Ator)
			.daPropriedade("comSom")
			.comValor(true)
			.testar();
	}());

	(function () {
		QUnit.module("semSom");

		TesteWebis
			.deMensagem()
			.doAtor("ator")
			.daPrimitiva("semSom")
			.comComandos(new Simbolo("comSom"))
			.doComando("SEM_SOM")
			.comDados({})
			.vezes(2)
			.testar();

		TesteWebis
			.dePropriedade()
			.daPrimitiva("semSom")
			.doElemento(Ator)
			.daPropriedade("comSom")
			.comValor(false)
			.testar();
	}());
}(this));
