/*global Associar*/
/*global Checagem*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("executar");

		TesteWebis.dePilha()
			.daPrimitiva("executar")
			.comComandos([10, 20])
			.deixaNaPilha(10, 20)
			.testar();
	}());

	(function () {
		QUnit.module("seVerdade");

		TesteWebis.dePilha()
			.daPrimitiva("seVerdade")
			.comComandos(true, [10, 20])
			.deixaNaPilha(10, 20)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("seVerdade")
			.comComandos(false, [10, 20])
			.deixaNaPilha()
			.testar();
	}());

	(function () {
		QUnit.module("seFalso");

		TesteWebis.dePilha()
			.daPrimitiva("seFalso")
			.comComandos(false, [10, 20])
			.deixaNaPilha(10, 20)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("seFalso")
			.comComandos(true, [10, 20])
			.deixaNaPilha()
			.testar();
	}());

	(function () {
		QUnit.module("vezesRepetir");

		TesteWebis.dePilha()
			.daPrimitiva("vezesRepetir")
			.comComandos([10], 5)
			.deixaNaPilha(10, 10, 10, 10, 10)
			.testar();
	}());

	(function () {
		QUnit.module("entãoSenão");

		TesteWebis.dePilha()
			.daPrimitiva("entãoSenão")
			.comComandos(true, [10], [20])
			.deixaNaPilha(10)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("entãoSenão")
			.comComandos(false, [10], [20])
			.deixaNaPilha(20)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("entãoSenão")
			.comComandos([true, 1, new Simbolo("=")], [10], [20])
			.deixaNaPilha(10)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("entãoSenão")
			.comComandos([false, 1, new Simbolo("=")], [10], [20])
			.deixaNaPilha(20)
			.testar();
	}());

	(function () {
		QUnit.module("contarGiro");

		TesteWebis.dePilha()
			.daPrimitiva("vezesRepetir")
			.comComandos([new Simbolo("contarGiro")], 5)
			.deixaNaPilha(1, 2, 3, 4, 5)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("vezesRepetir")
			.comComandos([new Simbolo("contarGiro"), [new Simbolo("contarGiro")], 3, new Simbolo("vezesRepetir")], 3)
			.deixaNaPilha(1, 1, 2, 3, 2, 1, 2, 3, 3, 1, 2, 3)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("vezesRepetir")
			.comComandos([new Simbolo("contarGiro"), [new Simbolo("contarGiro"), [new Simbolo("contarGiro")], 2, new Simbolo("vezesRepetir")], 2, new Simbolo("vezesRepetir")], 2)
			.deixaNaPilha(1, 1, 1, 2, 2, 1, 2, 2, 1, 1, 2, 2, 1, 2)
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("contarGiro")
			.lancaExcecao(Checagem.obterMensagemDeUsoDeContarGiroInvalido())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("entãoSenão")
			.comComandos([true], [new Simbolo("contarGiro")], [new Simbolo("contarGiro")])
			.lancaExcecao(Checagem.obterMensagemDeUsoDeContarGiroInvalido())
			.testar();

		TesteWebis.deExcecao()
			.daPrimitiva("seVerdade")
			.comComandos(true, [new Simbolo("contarGiro")])
			.lancaExcecao(Checagem.obterMensagemDeUsoDeContarGiroInvalido())
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("vezesRepetir")
			.comComandos([new Simbolo("contarGiro")], 5)
			.deixaNaPilha(1, 2, 3, 4, 5)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("enquantoVerdade")
			.comComandos([new Simbolo("contarGiro"), 1, new Simbolo("=")], ["esse texto deve aparecer apenas 1 vez"])
			.deixaNaPilha("esse texto deve aparecer apenas 1 vez")
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("enquantoVerdade")
			.comComandos([new Simbolo("contarGiro"), 4, new Simbolo("menorQue")], [new Simbolo("contarGiro")])
			.deixaNaPilha(1, 2, 3)
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("enquantoVerdade")
			.comComandos([new Simbolo("contarGiro"), 4, new Simbolo("menorQue")], [new Simbolo("contarGiro"), [new Simbolo("contarGiro"), 4, new Simbolo("menorQue")], [new Simbolo("contarGiro")], new Simbolo("enquantoVerdade")])
			.deixaNaPilha(1, 1, 2, 3, 2, 1, 2, 3, 3, 1, 2, 3)
			.testar();
	}());

	(function () {
		QUnit.module("enquantoVerdade");

		TesteWebis.dePilha()
			.daPrimitiva("enquantoVerdade")
			.comComandos([false], [1])
			.deixaNaPilha()
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("enquantoVerdade")
			.comComandos(1, new Associar("contador"), [1, new Simbolo("contador"), new Simbolo("=")], ["texto", 2, new Associar("contador")])
			.deixaNaPilha("texto")
			.testar();

		TesteWebis.dePilha()
			.daPrimitiva("enquantoVerdade")
			.comComandos([1, 2, 3, 4, 5, false], [])
			.deixaNaPilha()
			.testar();
	}());
}(this));
