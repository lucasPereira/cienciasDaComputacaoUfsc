/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("avaliar");

		TesteWebis
			.deExcecao()
			.daPrimitiva("avaliar")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"))
			.lancaExcecao(Checagem.obterMensagemDeAvaliacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("avaliar")
			.comComandos("texto")
			.lancaExcecao(Checagem.obterMensagemDeAvaliacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("avaliar")
			.comComandos(-1.11)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("avaliar")
			.comComandos(0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("avaliar")
			.comComandos(0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("avaliar")
			.comComandos(1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("avaliar")
			.comComandos([1, true])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("avaliar")
			.comComandos([false, 1, new Simbolo("=")])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("avaliar")
			.comComandos([new PacoteDeSimbolo("SIMBOLO")])
			.lancaExcecao(Checagem.obterMensagemDeAvaliacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("avaliar")
			.comComandos([true, "texto"])
			.lancaExcecao(Checagem.obterMensagemDeAvaliacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("avaliar")
			.comComandos(["texto", 1, new Simbolo("+")])
			.lancaExcecao(Checagem.obterMensagemDeAvaliacaoInvalida())
			.testar();
	}());
}(this));
