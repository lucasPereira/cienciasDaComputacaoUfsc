/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global Palavra*/
/*global QUnit*/
/*global Simbolo*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("operador +");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros([new Simbolo("SIMBOLOA")], [new Simbolo("SIMBOLOB")])
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros([new Simbolo("SIMBOLO")], [10])
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros([new Simbolo("SIMBOLO")], [true])
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros([10], [new Simbolo("SIMBOLO")])
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("+")
			.comParametros([true], [new Simbolo("SIMBOLO")])
			.dosTipos(Simbolo, Array)
			.dosTipos(Simbolo, String)
			.dosTipos(Array, Palavra)
			.dosTipos(Array, Array)
			.dosTipos(String, Palavra)
			.dosTipos(String, Array)
			.dosTipos(Number, Array)
			.dosTipos(Number, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, String)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("+")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("+")
			.comComandos([], [2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("+")
			.comComandos([[1, 2, 3], [4, 5, 6]], [[6, 5, 4], [3, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("+")
			.comComandos([], 1)
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("+")
			.comComandos(1, [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("+")
			.comComandos([], [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), [1, 2, 3])
			.deixaNaPilha([new Simbolo("SIMBOLO"), 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), [])
			.deixaNaPilha([new Simbolo("SIMBOLO")])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.deixaNaPilha("SIMBOLOtexto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), "")
			.deixaNaPilha("SIMBOLO")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([1, 2, 3], new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha([1, 2, 3, new Simbolo("SIMBOLO")])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([], new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha([new Simbolo("SIMBOLO")])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([["A", 1, true], "B", 2, false])
			.comComandos([["B", 2, false], "A", 1, true])
			.deixaNaPilha([["AB", 3, true], "BA", 3, true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([1, 2, 3], "texto")
			.deixaNaPilha([1, 2, 3, "texto"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([], "texto")
			.deixaNaPilha(["texto"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([[2], "texto", 1, false], 1)
			.deixaNaPilha([[3], "texto1", 2, true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos([[true], "texto", 1, false], false)
			.deixaNaPilha([[true], "textofalso", true, false])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("texto", new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha("textoSIMBOLO")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("", new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha("SIMBOLO")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("texto", [1, 2, 3])
			.deixaNaPilha(["texto", 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("texto", [])
			.deixaNaPilha(["texto"])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("textoA", "textoB")
			.deixaNaPilha("textoAtextoB")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("texto", 10)
			.deixaNaPilha("texto10")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("texto", true)
			.deixaNaPilha("textoverdadeiro")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos("texto", false)
			.deixaNaPilha("textofalso")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(10, [1, 2, 3])
			.deixaNaPilha([11, 12, 13])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(100, "texto")
			.deixaNaPilha("100texto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(10, 20)
			.deixaNaPilha(30)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(1.1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(10, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(0, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(0.1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(-1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(1.1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(10, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(0, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(0.1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(-1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, [false, true])
			.deixaNaPilha([false, true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, "texto")
			.deixaNaPilha("verdadeirotexto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, "texto")
			.deixaNaPilha("falsotexto")
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, 1.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, -1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, 1.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, -1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(false, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("+")
			.comComandos(true, true)
			.deixaNaPilha(true)
			.testar();
	}());

	(function () {
		QUnit.module("operador *");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros("texto", "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([new Simbolo("SIMBOLOA")], [new Simbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([new Simbolo("SIMBOLO")], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([new Simbolo("SIMBOLO")], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([new Simbolo("SIMBOLO")], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([new Simbolo("SIMBOLO")], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(["texto"], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(["texto"], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(["texto"], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(["texto"], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros(["texto"], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([[]], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([[]], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([10], [new Simbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([10], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([true], [new Simbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("*")
			.comParametros([true], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Array, Boolean)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Array)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("*")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("*")
			.comComandos([], [2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("*")
			.comComandos([[1, 2, 3], [4, 5, 6]], [[6, 5, 4], [3, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("*")
			.comComandos([], 1)
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("*")
			.comComandos(1, [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("*")
			.comComandos([], [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos([[1, true, false], 2, false, true])
			.comComandos([[2, false, false], 1, true, true])
			.deixaNaPilha([[2, false, false], 2, false, true])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos([2, false], 3)
			.deixaNaPilha([6, false])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos([4, true], false)
			.deixaNaPilha([false, false])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(10, [1, 2, 3])
			.deixaNaPilha([10, 20, 30])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(10, 20)
			.deixaNaPilha(200)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(1.1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(10, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(0, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(0.1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(-1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(1.1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(10, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(0, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(0.1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(-1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, [false, true])
			.deixaNaPilha([false, false])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, 1.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, -1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, 1.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, 0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, -1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(false, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("*")
			.comComandos(true, true)
			.deixaNaPilha(true)
			.testar();
	}());

	(function () {
		QUnit.module("operador -");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros("texto", "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(10, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(true, 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(true, false)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([new PacoteDeSimbolo("SIMBOLOA")], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(["texto"], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(["texto"], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(["texto"], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(["texto"], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros(["texto"], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([[]], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([[]], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([[]], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([10], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([10], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([10], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([true], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([true], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([true], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("-")
			.comParametros([true], [false])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("-")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("-")
			.comComandos([], [2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("-")
			.comComandos([[1, 2, 3], [4, 5, 6]], [[6, 5, 4], [3, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("-")
			.comComandos([], 1)
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("-")
			.comComandos(1, [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("-")
			.comComandos([], [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("-")
			.comComandos([[1, 2, 3], 2, 4, 6])
			.comComandos([[2, 1, 0], 1, 2, 3])
			.deixaNaPilha([[-1, 1, 3], 1, 2, 3])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("-")
			.comComandos([2, 4], 3)
			.deixaNaPilha([-1, 1])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("-")
			.comComandos(10, [9, 10, 11])
			.deixaNaPilha([1, 0, -1])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("-")
			.comComandos(1.1, 0.1)
			.deixaNaPilha(1)
			.testar();
	}());

	(function () {
		QUnit.module("operador /");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros("texto", "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(10, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(true, 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(true, false)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([new PacoteDeSimbolo("SIMBOLOA")], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(["texto"], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(["texto"], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(["texto"], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(["texto"], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros(["texto"], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([[]], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([[]], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([[]], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([10], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([10], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([10], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([true], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([true], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([true], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("/")
			.comParametros([true], [false])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("/")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("/")
			.comComandos([], [2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("/")
			.comComandos([[1, 2, 3], [4, 5, 6]], [[6, 5, 4], [3, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("/")
			.comComandos([], 1)
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("/")
			.comComandos(1, [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("/")
			.comComandos([], [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos([[6, 4, 2], 5, 3, 3])
			.comComandos([[2, 1, 4], 1, 2, 3])
			.deixaNaPilha([[3, 4, 0.5], 5, 1.5, 1])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos([10, 5], 5)
			.deixaNaPilha([2, 1])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos(10, [2, 5, 10])
			.deixaNaPilha([5, 2, 1])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos(0, 1)
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos(0, 0)
			.deixaNaPilha(NaN)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos(1, 0)
			.deixaNaPilha(Infinity)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("/")
			.comComandos(-1, 0)
			.deixaNaPilha(-Infinity)
			.testar();
	}());

	(function () {
		QUnit.module("operador \\");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros("texto", "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(10, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(true, 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(true, false)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([new PacoteDeSimbolo("SIMBOLOA")], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(["texto"], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(["texto"], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(["texto"], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(["texto"], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros(["texto"], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([[]], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([[]], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([[]], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([10], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([10], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([10], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([true], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([true], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([true], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("\\")
			.comParametros([true], [false])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("\\")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("\\")
			.comComandos([], [2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("\\")
			.comComandos([[1, 2, 3], [4, 5, 6]], [[6, 5, 4], [3, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("\\")
			.comComandos([], 1)
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("\\")
			.comComandos(1, [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("\\")
			.comComandos([], [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos([[6, 4, 2], 5, 3, 3])
			.comComandos([[2, 1, 4], 1, 2, 3])
			.deixaNaPilha([[0, 0, 2], 0, 1, 0])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos([10, 5], 3)
			.deixaNaPilha([1, 2])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos(-7, [2, 5, 10])
			.deixaNaPilha([-1, -2, -7])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos(0, 1)
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos(0, 0)
			.deixaNaPilha(NaN)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos(1, 0)
			.deixaNaPilha(NaN)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("\\")
			.comComandos(-1, 0)
			.deixaNaPilha(NaN)
			.testar();
	}());

	(function () {
		QUnit.module("operador ^");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros("texto", [])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros("texto", "")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros("texto", 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([], "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(10, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(10, true)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(true, 10)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(true, false)
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([new PacoteDeSimbolo("SIMBOLOA")], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([new PacoteDeSimbolo("SIMBOLO")], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(["texto"], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(["texto"], [[]])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(["texto"], [""])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(["texto"], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros(["texto"], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([[]], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([[]], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([[]], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([10], [new PacoteDeSimbolo("SIMBOLOB")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([10], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([10], [true])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([true], [new PacoteDeSimbolo("SIMBOLO")])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([true], ["texto"])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([true], [10])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("^")
			.comParametros([true], [false])
			.dosTipos(Array, Array)
			.dosTipos(Array, Number)
			.dosTipos(Number, Array)
			.dosTipos(Number, Number)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("^")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("^")
			.comComandos([], [2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("^")
			.comComandos([[1, 2, 3], [4, 5, 6]], [[6, 5, 4], [3, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("^")
			.comComandos([], 1)
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("^")
			.comComandos(1, [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("^")
			.comComandos([], [])
			.lancaExcecao(Checagem.obterMensagemDeListasDeOperacaoInvalida())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos([[6, 4, 2], 5, 3, 3])
			.comComandos([[2, 1, 4], 1, 0, 3])
			.deixaNaPilha([[36, 4, 16], 5, 1, 27])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos([10, 5], 3)
			.deixaNaPilha([1000, 125])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos(7, [2, -2, 1])
			.deixaNaPilha([49, 0.02040816326530612, 7])
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos(0, 1)
			.deixaNaPilha(0)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos(0, 0)
			.deixaNaPilha(1)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos(1, 0)
			.deixaNaPilha(1)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("^")
			.comComandos(-1, 0)
			.deixaNaPilha(1)
			.testar();
	}());

	(function () {
		QUnit.module("operador =");

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), "SIMBOLO")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([], new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([1], [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([1], [1, 2])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([[1]], [[2]])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([[1], "texto", 1, true], [true, 1, "texto", [1]])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([[1]], [[1]])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([[1], "texto", 1, true], [[1], "texto", 1, true])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([], [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([], "")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([], 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([], true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos([], false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("SIMBOLO", new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("", [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("texto", "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("", "")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("texto", "teXto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("te", "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("10", 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("verdadeiro", true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos("falso", false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(10, new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(0, [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(5, "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(9, 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(11, 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(10.1, 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(10, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(0, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(0.1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(-1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(11.1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(0, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(0.1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(-1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(11.1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, "verdadeiro")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, "falso")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, 0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, -1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, 11.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, 0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, -1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, 11.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(true, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("=")
			.comComandos(false, false)
			.deixaNaPilha(true)
			.testar();
	}());

	(function () {
		QUnit.module("maiorQue");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros([1, 2, 3, 4, 5], "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros([1], 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros("texto", [1, 2, 3, 4, 5])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros("1", 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(0, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(5, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(true, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorQue")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("maiorQue")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("maiorQue")
			.comComandos([], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("maiorQue")
			.comComandos([[1]], [[1, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([1, 2, 3], [1, 2, 3])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([1, 2, 3], [3, 2, 1])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([2, 3, 3], [1, 2, 3])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([2, 3, 4], [1, 2, 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([[2, 2, 2], 3], [[1, 2, 1], 2])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([[2, 2, 2], 2], [[1, 1, 1], 2])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([[2, 2, 2], 2], [[1, 1, 1], 1])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos([], [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos("", "")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos("texto", "casa")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos("casa", "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos("texto", "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(-0.1, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(0, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(0.1, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(0.9, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(1, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(1.1, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(-1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(0, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(-1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(2, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(false, 0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(false, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(false, -0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(true, 1.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(true, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(true, 0.9)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(false, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(false, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(true, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorQue")
			.comComandos(true, true)
			.deixaNaPilha(false)
			.testar();
	}());

	(function () {
		QUnit.module("menorQue");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros([1, 2, 3, 4, 5], "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros([1], 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros("texto", [1, 2, 3, 4, 5])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros("1", 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(0, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(5, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(true, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorQue")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("menorQue")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("menorQue")
			.comComandos([], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("menorQue")
			.comComandos([[1]], [[1, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([1, 2, 3], [1, 2, 3])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([1, 2, 3], [3, 2, 1])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([1, 2, 3], [2, 3, 3])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([1, 2, 3], [2, 3, 4])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([[1, 2, 1], 2], [[2, 2, 2], 3])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([[1, 1, 1], 2], [[2, 2, 2], 2])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([[1, 1, 1], 1], [[2, 2, 2], 2])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos([], [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos("", "")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos("texto", "casa")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos("casa", "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos("texto", "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(-0.1, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(0, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(0.1, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(0.9, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(1, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(1.1, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(-1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(0, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(-1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(2, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(false, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(false, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(false, -0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(true, 1.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(true, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(true, 0.9)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(false, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(false, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(true, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorQue")
			.comComandos(true, true)
			.deixaNaPilha(false)
			.testar();
	}());

	(function () {
		QUnit.module("maiorOuIgual");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros([1, 2, 3, 4, 5], "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros([1], 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros("texto", [1, 2, 3, 4, 5])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros("1", 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(0, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(5, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(true, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("maiorOuIgual")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("maiorOuIgual")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("maiorOuIgual")
			.comComandos([], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("maiorOuIgual")
			.comComandos([[1]], [[1, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([1, 2, 3], [1, 2, 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([1, 2, 3], [3, 2, 1])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([2, 3, 3], [1, 2, 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([2, 3, 4], [1, 2, 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([[2, 2, 2], 3], [[1, 2, 1], 2])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([[2, 2, 2], 2], [[1, 1, 1], 2])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([[2, 2, 2], 2], [[1, 1, 1], 1])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos([], [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos("", "")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos("texto", "casa")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos("casa", "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos("texto", "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(-0.1, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(0, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(0.1, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(0.9, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(1, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(1.1, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(-1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(0, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(-1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(2, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(false, 0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(false, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(false, -0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(true, 1.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(true, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(true, 0.9)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(false, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(false, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(true, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("maiorOuIgual")
			.comComandos(true, true)
			.deixaNaPilha(true)
			.testar();
	}());

	(function () {
		QUnit.module("menorOuIgual");

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros([1, 2, 3, 4, 5], "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros([1], 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros([], true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros("texto", [1, 2, 3, 4, 5])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros("1", 1)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros("texto", true)
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(0, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(5, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLOB"))
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(true, [])
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deTiposDeParametros()
			.daPrimitiva("menorOuIgual")
			.comParametros(true, "texto")
			.dosTipos(Array, Array)
			.dosTipos(String, String)
			.dosTipos(Number, Number)
			.dosTipos(Number, Boolean)
			.dosTipos(Boolean, Number)
			.dosTipos(Boolean, Boolean)
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("menorOuIgual")
			.comComandos([1], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("menorOuIgual")
			.comComandos([], [1, 2])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.deExcecao()
			.daPrimitiva("menorOuIgual")
			.comComandos([[1]], [[1, 2]])
			.lancaExcecao(Checagem.obterMensagemDeTamanhoDeListasInvalido())
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([1, 2, 3], [1, 2, 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([1, 2, 3], [3, 2, 1])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([1, 2, 3], [2, 3, 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([1, 2, 3], [2, 3, 4])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([[1, 2, 1], 2], [[2, 2, 2], 3])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([[1, 1, 1], 2], [[2, 2, 2], 2])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([[1, 1, 1], 1], [[2, 2, 2], 2])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos([], [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos("", "")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos("texto", "casa")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos("casa", "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos("texto", "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(-0.1, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(0, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(0.1, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(0.9, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(1, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(1.1, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(-1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(0, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(1, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(-1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(2, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(false, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(false, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(false, -0.1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(true, 1.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(true, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(true, 0.9)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(false, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(false, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(true, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("menorOuIgual")
			.comComandos(true, true)
			.deixaNaPilha(true)
			.testar();
	}());

	(function () {
		QUnit.module("diferenteDe");

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLOA"), new PacoteDeSimbolo("SIMBOLOB"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), "SIMBOLO")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(new PacoteDeSimbolo("SIMBOLO"), false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([], new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([1], [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([1], [1, 2])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([[1]], [[2]])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([[1], "texto", 1, true], [true, 1, "texto", [1]])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([[1]], [[1]])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([[1], "texto", 1, true], [[1], "texto", 1, true])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([], [])
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([], "")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([], 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([], true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos([], false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("SIMBOLO", new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("", [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("texto", "texto")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("", "")
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("texto", "teXto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("te", "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("10", 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("verdadeiro", true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos("falso", false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(10, new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(0, [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(5, "texto")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(9, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(11, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(10.1, 10)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(10, 10)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(0, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(0.1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(-1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(11.1, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(0, false)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(0.1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(1, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(-1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(11.1, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, new PacoteDeSimbolo("SIMBOLO"))
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, [])
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, "verdadeiro")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, "falso")
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, 0)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, 1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, -1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, 11.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, 0)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, 0.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, 1)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, -1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, 11.1)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, false)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, true)
			.deixaNaPilha(true)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(true, true)
			.deixaNaPilha(false)
			.testar();

		TesteWebis
			.dePilha()
			.daPrimitiva("diferenteDe")
			.comComandos(false, false)
			.deixaNaPilha(false)
			.testar();
	}());
}(this));
