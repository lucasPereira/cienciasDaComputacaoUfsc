/*global Agenda*/
/*global Checagem*/
/*global PacoteDeSimbolo*/
/*global QUnit*/
/*global Simbolo*/
/*global TabelaDeAgendas*/
/*global TesteWebis*/
/*global sinon*/

(function (global) {
	"use strict";

	QUnit.begin(function () {
		global.postMessage = sinon.stub();
	});

	(function () {
		QUnit.module("incluirAgenda");

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(new PacoteDeSimbolo("SIMBOLO"), true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros([], new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros([], [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros([], "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros([], 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros([], true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros("texto", new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros("texto", "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros("texto", 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros("texto", true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(10, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(10, [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(10, "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(10, 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(10, true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(true, new PacoteDeSimbolo("SIMBOLO"))
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(true, [])
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(true, "texto")
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(true, 10)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.deTiposDeParametros()
			.daPrimitiva("incluirAgenda")
			.comParametros(true, true)
			.dosTipos(String, Array)
			.testar();

		TesteWebis.dePropriedade()
			.daPrimitiva("incluirAgenda")
			.comComandos("nomeDaAgenda", [])
			.doElemento(TabelaDeAgendas)
			.daPropriedade("nomeDaAgenda")
			.comValor(new Agenda([]))
			.testar();
	}());

	(function () {
		QUnit.module("agenda");

		TesteWebis.deExcecao()
			.comComandos(new Simbolo("agendaQualquer"))
			.lancaExcecao(Checagem.obterMensagemDePalavraNaoEncontrada("agendaQualquer"))
			.testar();

		TesteWebis.dePilha()
			.comComandos("nomeDaAgenda", [], new Simbolo("incluirAgenda"), new Simbolo("nomeDaAgenda"))
			.deixaNaPilha()
			.testar();

		TesteWebis.dePilha()
			.comComandos(10, "agenda", [1, 2, 3], new Simbolo("incluirAgenda"), new Simbolo("agenda"))
			.deixaNaPilha(10, 1, 2, 3)
			.testar();

		TesteWebis.dePilha()
			.comComandos("agendaA", [1, 2, 3], new Simbolo("incluirAgenda"), "agendaB", [0, new Simbolo("agendaA"), 4], new Simbolo("incluirAgenda"), new Simbolo("agendaB"))
			.deixaNaPilha(0, 1, 2, 3, 4)
			.testar();

		TesteWebis.dePilha()
			.comComandos("agendaA", [1], new Simbolo("incluirAgenda"), new Simbolo("agendaA"), "agendaA", [2], new Simbolo("incluirAgenda"), new Simbolo("agendaA"))
			.deixaNaPilha(1, 2)
			.testar();
	}());
}(this));
