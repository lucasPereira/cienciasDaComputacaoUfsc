package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import java.util.List;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaTodosSons extends DadosParaInterfaceGrafica {
	private List<Som> sons;
	
	public DadosDaPaginaTodosSons(UriInfo uriInfo, Usuario usuarioAutenticado, List<Som> sons) {
		super(uriInfo, usuarioAutenticado);
		this.sons = sons;
	}
	
	public List<Som> obterSons() {
		return sons;
	}
}
