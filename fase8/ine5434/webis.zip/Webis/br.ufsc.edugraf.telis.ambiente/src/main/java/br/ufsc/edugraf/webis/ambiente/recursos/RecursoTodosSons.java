package br.ufsc.edugraf.webis.ambiente.recursos;

import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaTodosSons;

import com.google.inject.Inject;

@Path("/sons")
public class RecursoTodosSons extends Recurso {
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private RepositorioDoAmbiente repositorio;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoTodosSons(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
		this.repositorio = repositorio;
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response obterHtml() {
		List<Som> sons = repositorio.obterSons();
		DadosDaPaginaTodosSons dados = new DadosDaPaginaTodosSons(informacaoDeUri, usuarioAutenticado, sons);
		return obterRespostaDePaginaHtml(Arquivos.TODOS_SONS, dados);
	}
}
