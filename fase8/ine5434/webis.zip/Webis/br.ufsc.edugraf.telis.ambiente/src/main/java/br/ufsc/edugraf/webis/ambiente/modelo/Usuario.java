package br.ufsc.edugraf.webis.ambiente.modelo;

import java.security.Principal;
import java.text.Collator;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import br.ufsc.edugraf.webis.ambiente.couch.RepositorioDeUsuarios;

import com.google.common.base.Objects;

public class Usuario implements Principal, Comparable<Usuario> {
	@JsonProperty("_id") private String identificadorDoCouch;
	@JsonProperty("_rev") private String revisaoDoCouch;
	@JsonProperty("identificadorDoOpenId") private String identificadorDoOpenId;
	@JsonProperty("nome") private String nome;
	@JsonProperty("email") private String email;
	@JsonProperty("tipo") public final String tipo = RepositorioDeUsuarios.TIPO;
	
	@JsonCreator
	public Usuario(@JsonProperty("_id") String identificadorDoCouch, @JsonProperty("_rev") String revisaoDoCouch, @JsonProperty("identificadorDoOpenId") String identificadorDoOpenId, @JsonProperty("nome") String nome, @JsonProperty("email") String email) {
		this.identificadorDoCouch = identificadorDoCouch;
		this.revisaoDoCouch = revisaoDoCouch;
		this.identificadorDoOpenId = identificadorDoOpenId;
		this.nome = nome;
		this.email = email;
	}
	
	public Usuario(String identificadorDoOpenId, String nome, String email) {
		this.identificadorDoOpenId = identificadorDoOpenId;
		this.nome = nome;
		this.email = email;
	}
	
	public Usuario(String identificadorDoCouch, String identificadorDoOpenId, String nome, String email) {
		this.identificadorDoCouch = identificadorDoCouch;
		this.identificadorDoOpenId = identificadorDoOpenId;
		this.nome = nome;
		this.email = email;
	}
	
	public String obterNome() {
		return (nome != null) ? nome : "Sem nome";
	}
	
	public String obterEmail() {
		return email;
	}
	
	public String obterIdentificadorDoOpenId() {
		return identificadorDoOpenId;
	}
	
	public String obterIdentificadorDoCouch() {
		return identificadorDoCouch;
	}
	
	public void fixarNome(String nome) {
		this.nome = nome;
	}
	
	public void fixarEmail(String email) {
		this.email = email;
	}
	
	public void fixarIdentificadorDoOpenId(String identificadorDoOpenId) {
		this.identificadorDoOpenId = identificadorDoOpenId;
	}
	
	@Override
	@JsonIgnore
	public String getName() {
		return obterNome();
	}
	
	@Override
	public int hashCode(){
		return Objects.hashCode(email);
	}
	
	@Override
	public boolean equals(final Object outroObjeto){
		if(outroObjeto instanceof Usuario){
			final Usuario outro = (Usuario) outroObjeto;
			return Objects.equal(email, outro.email);
		}
		return false;
	}
	
	@Override
	public int compareTo(Usuario outro) {
		if (this.equals(outro)) {
			return 0;
		}
		return Collator.getInstance().compare(this.nome, outro.nome);
	}
}
