package br.ufsc.edugraf.webis.ambiente.recursos;

import java.net.MalformedURLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaInicio;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosParaInterfaceGrafica;

import com.google.inject.Inject;

@Path("/")
public class RecursoInicio extends Recurso{
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private RepositorioDoAmbiente repositorio;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoInicio(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
		this.repositorio = repositorio;
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response obterHtml() throws MalformedURLException {
		List<Aplique> apliques = repositorio.obterApliques();
		DadosParaInterfaceGrafica dados = new DadosDaPaginaInicio(informacaoDeUri, usuarioAutenticado, apliques);
		return obterRespostaDePaginaHtml(Arquivos.INICIO, dados);
	}
}
