package br.ufsc.edugraf.webis.ambiente.modelo;

import java.util.List;

public interface RepositorioDoAmbiente {
	public List<Aplique> obterApliques();
	
	public List<Aplique> obterApliquesPorAutor(Usuario autor); 
	
	public List<Som> obterSons();
	
	public List<Som> obterSonsPorAutor(Usuario autor); 
	
	public Aplique obterApliquePorNomeEAutor(String nome, Usuario autor);
	
	public Usuario obterUsuarioPorIdentificadorDoOpenId(String identificadorDoOpenId);
	
	public Usuario obterUsuarioPorIdentificadorDoCouch(String identificadorDoCouch);
	
	public Usuario obterUsuarioPorEmail(String email);
	
	public Som obterSomPorAutorENome(Usuario autor, String nome);
	
	public void salvarAplique(Aplique aplique);
	
	public void salvarUsuario(Usuario usuario);
	
	public void salvarSom(Som som);
}
