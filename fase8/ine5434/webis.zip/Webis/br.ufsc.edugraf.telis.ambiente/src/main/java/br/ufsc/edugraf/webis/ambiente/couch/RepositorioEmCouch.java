package br.ufsc.edugraf.webis.ambiente.couch;

import java.io.IOException;
import java.util.List;

import javax.ws.rs.core.MediaType;

import org.ektorp.AttachmentInputStream;
import org.ektorp.CouchDbConnector;
import org.ektorp.DocumentNotFoundException;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.util.Documents;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class RepositorioEmCouch implements RepositorioDoAmbiente {
	private CouchDbConnector bancoDeDados;
	private RepositorioDeApliques repositorioDeApliques;
	private RepositorioDeUsuarios repositorioDeUsuarios;
	private RepositorioDeSons repositorioDeSons;
	
	public RepositorioEmCouch() {
		this.bancoDeDados = CouchDB.obterInstancia().obterConexãoComCouchDB();
		this.repositorioDeApliques = new RepositorioDeApliques(bancoDeDados);
		this.repositorioDeUsuarios = new RepositorioDeUsuarios(bancoDeDados);
		this.repositorioDeSons = new RepositorioDeSons(bancoDeDados);
	}
	
	@Override
	public List<Aplique> obterApliques() {
		List<Aplique> resultado = repositorioDeApliques.obterApliquesOrdenadosPorDataDeModificacao();
		for (Aplique aplique : resultado) {
			aplique.fixarAutor(repositorioDeUsuarios.obterUsuarioPorIdentificadorDoCouch(aplique.obterIdentificadorDoCouchDoAutor()));
		}
		return resultado;
	}
	
	@Override
	public List<Aplique> obterApliquesPorAutor(Usuario autor) {
		List<Aplique> apliquesDoAutor = repositorioDeApliques.obterApliquesPorIdentificadorDoCouchDoAutorOrdenadosPorDataDeModificacao(autor.obterIdentificadorDoCouch());
		for (Aplique aplique : apliquesDoAutor) {
			aplique.fixarAutor(autor);
		}
		return apliquesDoAutor;
	}
	
	@Override
	public List<Som> obterSons() {
		List<Som> resultado = repositorioDeSons.obterSonsOrdenadosPorDataDeCarregamento();
		for (Som som : resultado) {
			som.fixarAutor(repositorioDeUsuarios.obterUsuarioPorIdentificadorDoCouch(som.obterIdentificadorDoCouchDoAutor()));
		}
		return resultado;
	}
	
	@Override
	public List<Som> obterSonsPorAutor(Usuario autor) {
		List<Som> sonsDoAutor = repositorioDeSons.obterSonsPorIdentificadorDoCouchDoAutorOrdenadosPorDataDeCarregamento(autor.obterIdentificadorDoCouch());
		for (Som som : sonsDoAutor) {
			som.fixarAutor(autor);
		}
		return sonsDoAutor;
	}
	
	@Override
	public Aplique obterApliquePorNomeEAutor(String nome, Usuario autor) {
		Aplique aplique = this.repositorioDeApliques.obterApliquePorIdentificadorDoCouchDoAutorENome(autor.obterIdentificadorDoCouch(), nome);
		if (aplique == null) {
			aplique = new Aplique(nome);
		}
		aplique.fixarAutor(autor);
		return aplique;
	}
	
	@Override
	public Usuario obterUsuarioPorIdentificadorDoOpenId(String identificadorDoOpenId) {
		return this.repositorioDeUsuarios.obterUsuarioPorIdentificadorDoOpenId(identificadorDoOpenId);
	}
	@Override
	public Usuario obterUsuarioPorIdentificadorDoCouch(String identificadorDoCouch) {
		return this.repositorioDeUsuarios.obterUsuarioPorIdentificadorDoCouch(identificadorDoCouch);
	}
	
	@Override
	public Usuario obterUsuarioPorEmail(String email) {
		return this.repositorioDeUsuarios.obterUsuarioPorEmail(email);
	}
	
	@Override
	public Som obterSomPorAutorENome(Usuario autor, String nome) {
		Som som = this.repositorioDeSons.obterSomPorIdentificadorDoCouchDoAutorENome(autor.obterIdentificadorDoCouch(), nome);
		if (som != null) {
			som.fixarAutor(autor);
			AttachmentInputStream arquivoDeSom = null; 
			try {
				arquivoDeSom = bancoDeDados.getAttachment(som.obterIdentificadorDoCouch(), "som");
			} catch (DocumentNotFoundException excecao) {
				
			}
			som.fixarSom(arquivoDeSom);
		}
		return som;
	}
	
	@Override
	public void salvarAplique(Aplique aplique) {
		salvarDocumento(aplique, repositorioDeApliques);
		Usuario autor = aplique.obterAutor();
		if (autor != null) {
			salvarUsuario(autor);
		}
	}
	
	@Override
	public void salvarUsuario(Usuario usuario) {
		salvarDocumento(usuario, repositorioDeUsuarios);
	}
	
	@Override
	public void salvarSom(Som som) {
		Som somExistente = obterSomPorAutorENome(som.obterAutor(), som.obterNome());
		if (somExistente == null) {
			salvarDocumento(som, repositorioDeSons);
			somExistente = obterSomPorAutorENome(som.obterAutor(), som.obterNome());
		}
		AttachmentInputStream arquivoDeSom = new AttachmentInputStream("som", som.obterSom(), MediaType.valueOf("audio/*").toString());
		bancoDeDados.createAttachment(somExistente.obterIdentificadorDoCouch(), somExistente.obterRevisaoDoCouch(), arquivoDeSom);
		try {
			arquivoDeSom.close();
		} catch (IOException excecao) {
			excecao.printStackTrace();
		}
	}
	
	private <T, R extends CouchDbRepositorySupport<T>> void salvarDocumento(T documento, R repositorio) {
		if (Documents.isNew(documento)) {
			repositorio.add(documento);
		} else {
			repositorio.update(documento);
		}
	}
}
