package br.ufsc.edugraf.webis.ambiente.recursos;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosParaInterfaceGrafica;

import com.google.inject.Inject;

@Path("/carregamentoDeSom")
public class RecursoCarregamentoDeSom extends Recurso{
	private @Context UriInfo uriInfo;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoCarregamentoDeSom(@Context SecurityContext contextoDeSegurança, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSegurança.getUserPrincipal();
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response obterHtml() {
		obterUsuarioAutenticado(usuarioAutenticado);
		DadosParaInterfaceGrafica dados = new DadosParaInterfaceGrafica(uriInfo, usuarioAutenticado);
		return obterRespostaDePaginaHtml(Arquivos.CARREGAMENTO_DE_SOM, dados);
	}
}
