package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import java.util.List;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaSons extends DadosParaInterfaceGrafica {
	private List<Som> sons;
	private Usuario autor;
	
	public DadosDaPaginaSons(UriInfo informacaoDeUri, Usuario usuarioAutenticado, List<Som> sons, Usuario autor) {
		super(informacaoDeUri, usuarioAutenticado);
		this.sons = sons;
		this.autor = autor;
	}
	
	public List<Som> obterSons() {
		return this.sons;
	}
	
	public Usuario obterAutor() {
		return autor;
	}
}
