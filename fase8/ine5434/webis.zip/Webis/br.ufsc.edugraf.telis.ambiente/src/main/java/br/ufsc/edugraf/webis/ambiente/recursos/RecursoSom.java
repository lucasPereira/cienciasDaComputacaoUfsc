package br.ufsc.edugraf.webis.ambiente.recursos;

import java.io.ByteArrayInputStream;
import java.io.IOException;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

import com.google.inject.Inject;
import com.sun.jersey.multipart.FormDataParam;

@Path("/{identificadorDoCouchDoAutor}/som/{nome}")
public class RecursoSom extends Recurso {
	private final static int TAMANHO_MAXIMO_DO_SOM = 2 * 1024 * 1024;
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private RepositorioDoAmbiente repositorio;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoSom(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
		this.repositorio = repositorio;
	}
	
	@GET
	@Produces(MIDIA_AUDIO)
	public Response obterAudio(@PathParam("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor, @PathParam("nome") String nome) {
		Usuario autor = obterAutor(identificadorDoCouchDoAutor, repositorio);
		Som som = obterSom(nome, autor);
		return obterRespostaDeSom(som.obterSom(), TIPO_DE_MIDIA_AUDIO);
	}
	
	@PUT
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	public Response colocarFormulario(@PathParam("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor, @PathParam("nome") String nome, @FormDataParam("som") byte[] som) throws IOException {
		Usuario autor = obterAutorAutenticado(identificadorDoCouchDoAutor, usuarioAutenticado, repositorio);
		if (som.length > TAMANHO_MAXIMO_DO_SOM) {
			return obterRespostaDeRequisicaoMalFeita();
		}
		ByteArrayInputStream arquivoDeSom = new ByteArrayInputStream(som);
		Som somSalvo = new Som(identificadorDoCouchDoAutor, nome, arquivoDeSom);
		somSalvo.fixarAutor(autor);
		repositorio.salvarSom(somSalvo);
		arquivoDeSom.close();
		return obterRespostaDeSucesso();
	}
	
	private Som obterSom(String nome, Usuario autor) {
		Som som = repositorio.obterSomPorAutorENome(autor, nome);
		if (som == null) {
			throw new WebApplicationException(obterRespostaDeNaoEncontrado());
		}
		return som;
	}
}
