package br.ufsc.edugraf.webis.ambiente.recursos;

import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaSons;

import com.google.inject.Inject;

@Path("{identificadorDoCouchDoAutor}/sons")
public class RecursoSons extends Recurso {
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private RepositorioDoAmbiente repositorio;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoSons(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
		this.repositorio = repositorio;
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response obterHtml(@PathParam("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor) {
		Usuario autor = obterAutor(identificadorDoCouchDoAutor, repositorio);
		List<Som> sons = repositorio.obterSonsPorAutor(autor);
		DadosDaPaginaSons dados = new DadosDaPaginaSons(informacaoDeUri, usuarioAutenticado, sons, autor);
		return obterRespostaDePaginaHtml(Arquivos.SONS, dados);
	}
}
