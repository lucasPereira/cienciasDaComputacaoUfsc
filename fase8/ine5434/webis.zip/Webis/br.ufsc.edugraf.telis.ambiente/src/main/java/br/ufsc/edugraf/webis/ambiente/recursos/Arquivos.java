package br.ufsc.edugraf.webis.ambiente.recursos;

public enum Arquivos {
	INICIO("inicio"),
	APLIQUE("aplique"),
	APLIQUES("apliques"),
	TODOS_APLIQUES("todosApliques"),
	CRIACAO_DE_APLIQUE("criacaoDeAplique"),
	USUARIO("usuario"),
	SONS("sons"),
	TODOS_SONS("todosSons"),
	CARREGAMENTO_DE_SOM("carregamentoDeSom"),
	ACESSIBILIDADE("acessibilidade"),
	PRIMITIVAS("primitivas");
	
	private static final String CAMINHHO_BASE = "/br/ufsc/edugraf/webis/ambiente/recursos/";
	private static final String EXTENSAO = ".tpl";
	private String nome;
	
	private Arquivos(String nome) {
		this.nome = nome;
	}
	
	public String comoTexto() {
		return CAMINHHO_BASE + nome + EXTENSAO;
	}
}
