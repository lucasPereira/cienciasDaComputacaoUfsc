package br.ufsc.edugraf.webis.ambiente.couch;

import static com.google.common.collect.Iterables.getFirst;

import java.util.List;

import org.ektorp.ComplexKey;
import org.ektorp.CouchDbConnector;
import org.ektorp.ViewQuery;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.View;
import org.ektorp.support.Views;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;

@Views({
	@View(name = RepositorioDeApliques.VISAO_POR_NOME, map = "function(documento) { if (documento.tipo == '" + RepositorioDeApliques.TIPO + "') { emit(documento.nome, documento); } }"),
	@View(name = RepositorioDeApliques.VISAO_POR_DATA_DE_MODIFICACAO, map = "function(documento) { if (documento.tipo == '" + RepositorioDeApliques.TIPO + "') { emit(documento.dataDeModificacao, documento); } }"),
	@View(name = RepositorioDeApliques.VISAO_POR_AUTOR_E_NOME, map = "function(documento) { if (documento.tipo == '" + RepositorioDeApliques.TIPO + "') { emit([documento.identificadorDoCouchDoAutor, documento.nome], documento); } }"),
	@View(name = RepositorioDeApliques.VISAO_POR_AUTOR_E_DATA_DE_MODIFICACAO, map = "function(documento) { if (documento.tipo == '" + RepositorioDeApliques.TIPO + "') { emit([documento.identificadorDoCouchDoAutor, documento.dataDeModificacao], documento); } }")
})
public class RepositorioDeApliques extends CouchDbRepositorySupport<Aplique> {
	public static final String TIPO = "aplique";
	private static final String DESIGN = "_design/" + TIPO;
	protected static final String VISAO_POR_NOME = "porNome";
	protected static final String VISAO_POR_DATA_DE_MODIFICACAO = "porDataDeModificacao";
	protected static final String VISAO_POR_AUTOR_E_NOME = "porNomeEAutor";
	protected static final String VISAO_POR_AUTOR_E_DATA_DE_MODIFICACAO = "porAutorEDataDeMoficacao";
	private CouchDbConnector bancoDeDados;
	
	public RepositorioDeApliques(CouchDbConnector bancoDeDados) {
		super(Aplique.class, bancoDeDados, TIPO);
		this.bancoDeDados = bancoDeDados;
	}
	
	public List<Aplique> obterApliquesOrdenadosPorNome() {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_NOME)
			.descending(false);
		return bancoDeDados.queryView(busca, Aplique.class);
	}
	
	public List<Aplique> obterApliquesOrdenadosPorDataDeModificacao() {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_DATA_DE_MODIFICACAO)
			.descending(true);
		return bancoDeDados.queryView(busca, Aplique.class);
	}
	
	public List<Aplique> obterApliquesPorIdentificadorDoCouchDoAutorOrdenadosPorDataDeModificacao(String identificadorDoCouchDoAtor) {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_AUTOR_E_DATA_DE_MODIFICACAO)
			.descending(true)
			.inclusiveEnd(true)
			.startKey(ComplexKey.of(identificadorDoCouchDoAtor, ComplexKey.emptyObject()))
			.endKey(ComplexKey.of(identificadorDoCouchDoAtor));
		return bancoDeDados.queryView(busca, Aplique.class);
	}
	
	public List<Aplique> obterApliquesPorIdentificadorDoCouchDoAutorOrdenadosPorNome(String identificadorDoCouchDoAtor) {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_AUTOR_E_NOME)
			.descending(true)
			.inclusiveEnd(true)
			.startKey(ComplexKey.of(identificadorDoCouchDoAtor, ComplexKey.emptyObject()))
			.endKey(ComplexKey.of(identificadorDoCouchDoAtor));
		return bancoDeDados.queryView(busca, Aplique.class);
	}
	
	public Aplique obterApliquePorIdentificadorDoCouchDoAutorENome(String identificadorDoCouchDoAutor, String nome) {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_AUTOR_E_NOME)
			.key(ComplexKey.of(identificadorDoCouchDoAutor, nome));
		List<Aplique> apliquesEncontrados = bancoDeDados.queryView(busca, Aplique.class);
		return getFirst(apliquesEncontrados, null);
	}
}
