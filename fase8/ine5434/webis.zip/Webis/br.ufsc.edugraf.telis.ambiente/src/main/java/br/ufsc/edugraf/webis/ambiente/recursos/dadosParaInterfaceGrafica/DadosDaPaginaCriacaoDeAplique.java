package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaCriacaoDeAplique extends DadosParaInterfaceGrafica {
	private boolean possuiErro;
	private String nome;
	private String codigoFonte;
	
	public DadosDaPaginaCriacaoDeAplique(UriInfo informacaoDeUri, Usuario usuarioAutenticado, String nome, String codigo) {
		super(informacaoDeUri, usuarioAutenticado);
		this.possuiErro = true;
		this.nome = nome;
		this.codigoFonte = codigo;
	}
	
	public DadosDaPaginaCriacaoDeAplique(UriInfo informacaoDeUri, Usuario usuarioAutenticado) {
		super(informacaoDeUri, usuarioAutenticado);
		this.possuiErro = false;
		this.nome = "";
		this.codigoFonte = "";
	}
	
	public String obterNome() {
		return nome;
	}
	
	public String obterCodigoFonte() {
		return codigoFonte;
	}
	
	public boolean possuiErro() {
		return possuiErro;
	}
}
