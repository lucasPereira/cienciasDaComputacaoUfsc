package br.ufsc.edugraf.webis.ambiente.servlet;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.ektorp.CouchDbConnector;
import org.ektorp.support.CouchDbRepositorySupport;

import br.ufsc.edugraf.webis.ambiente.couch.CouchDB;
import br.ufsc.edugraf.webis.ambiente.couch.RepositorioDeApliques;
import br.ufsc.edugraf.webis.ambiente.couch.RepositorioDeUsuarios;

public class AtualizacaoDasVisoesDoCouchDB implements ServletContextListener {
	private static final Log log = LogFactory.getLog(AtualizacaoDasVisoesDoCouchDB.class);
	
	@Override
	public void contextInitialized(ServletContextEvent contexto) {
		try {
			System.setProperty(CouchDbRepositorySupport.AUTO_UPDATE_VIEW_ON_CHANGE, "true");
			CouchDbConnector bancoDeDados = CouchDB.obterInstancia().obterConexãoComCouchDB();
			new RepositorioDeApliques(bancoDeDados).initStandardDesignDocument();
			new RepositorioDeUsuarios(bancoDeDados).initStandardDesignDocument();
		} catch (Exception excecao) {
			log.error("Erro durante atualização das visões do CouchDb.", excecao);
		}
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent contexto) {
		
	}
}
