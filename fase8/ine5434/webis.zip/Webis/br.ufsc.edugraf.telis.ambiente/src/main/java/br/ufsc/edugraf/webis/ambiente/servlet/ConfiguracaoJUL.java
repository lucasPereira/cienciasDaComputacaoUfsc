package br.ufsc.edugraf.webis.ambiente.servlet;

import java.util.logging.LogManager;
import java.util.logging.Logger;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.bridge.SLF4JBridgeHandler;

public class ConfiguracaoJUL implements ServletContextListener {
	@Override
	public void contextInitialized(ServletContextEvent sce) {
		Logger logger = LogManager.getLogManager().getLogger("");
		for (java.util.logging.Handler tratador : logger.getHandlers()) {
			logger.removeHandler(tratador);
		}
		SLF4JBridgeHandler.install();
	}
	
	@Override
	public void contextDestroyed(ServletContextEvent contexto) {
		SLF4JBridgeHandler.uninstall();
	}
}
