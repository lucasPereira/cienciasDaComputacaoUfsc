package br.ufsc.edugraf.webis.ambiente.recursos;

import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;

import com.google.inject.Inject;

@Path("/som/{nome}")
public class RecursoSomInterno extends Recurso {
	private final static String PASTA_BASE = "som/";
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	
	@Inject
	public RecursoSomInterno(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		
	}
	
	@GET
	@Produces(MIDIA_MP3)
	public Response obterMp3(@PathParam("nome") String nome) {
		InputStream som = obterRecurso(contextoDeServlet, PASTA_BASE + nome);
		return obterRespostaDeSom(som, TIPO_DE_MIDIA_MP3);
	}
}
