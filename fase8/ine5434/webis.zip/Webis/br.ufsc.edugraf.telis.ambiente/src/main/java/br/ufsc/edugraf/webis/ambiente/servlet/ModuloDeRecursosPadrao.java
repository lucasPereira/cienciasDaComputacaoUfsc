package br.ufsc.edugraf.webis.ambiente.servlet;

import br.ufsc.edugraf.webis.ambiente.seguranca.FiltroDeAutenticacaoOpenID;

public class ModuloDeRecursosPadrao extends ModuloDeRecursos {
	
	public ModuloDeRecursosPadrao() {
		adicionarFiltro(FiltroDeAutenticacaoOpenID.class);
	}
}
