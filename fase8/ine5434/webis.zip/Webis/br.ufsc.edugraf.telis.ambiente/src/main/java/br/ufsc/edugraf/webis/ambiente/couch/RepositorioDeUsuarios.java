package br.ufsc.edugraf.webis.ambiente.couch;

import static com.google.common.collect.Iterables.getFirst;

import java.util.List;

import org.ektorp.CouchDbConnector;
import org.ektorp.DocumentNotFoundException;
import org.ektorp.ViewQuery;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.View;
import org.ektorp.support.Views;

import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

@Views({
	@View(name = RepositorioDeUsuarios.VISAO_POR_IDENTIFICADOR_DO_OPEN_ID, map = "function(documento) { if (documento.tipo == '" + RepositorioDeUsuarios.TIPO + "') { emit(documento.identificadorDoOpenId, documento); } }"),
	@View(name = RepositorioDeUsuarios.VISAO_POR_EMAIL, map = "function(documento) { if (documento.tipo == '" + RepositorioDeUsuarios.TIPO + "') { emit(documento.email, documento); } }")
})
public class RepositorioDeUsuarios extends CouchDbRepositorySupport<Usuario> {
	public static final String TIPO = "usuario";
	private static final String DESIGN = "_design/" + TIPO;
	protected static final String VISAO_POR_IDENTIFICADOR_DO_OPEN_ID = "porIdentificadorDoOpenId";
	protected static final String VISAO_POR_EMAIL = "porEmail";
	private CouchDbConnector bancoDeDados;
	
	public RepositorioDeUsuarios(CouchDbConnector bancoDeDados) {
		super(Usuario.class, bancoDeDados, TIPO);
		this.bancoDeDados = bancoDeDados;
	}
	
	public List<Usuario> obterUsuariosOrdenadosPorIdentificadorDoOpenId() {
		ViewQuery busca = new ViewQuery()
			.viewName(VISAO_POR_IDENTIFICADOR_DO_OPEN_ID)
			.designDocId(DESIGN);
		return bancoDeDados.queryView(busca, Usuario.class);
	}
	
	public List<Usuario> obterUsuariosOrdenadosPorEmail() {
		ViewQuery busca = new ViewQuery()
			.viewName(VISAO_POR_EMAIL)
			.designDocId(DESIGN);
		return bancoDeDados.queryView(busca, Usuario.class);
	}
	
	public Usuario obterUsuarioPorIdentificadorDoOpenId(String identificadorDoOpenId) {
		ViewQuery busca = new ViewQuery()
			.viewName(VISAO_POR_IDENTIFICADOR_DO_OPEN_ID)
			.designDocId(DESIGN)
			.key(identificadorDoOpenId);
		List<Usuario> usuarios = bancoDeDados.queryView(busca, Usuario.class);
		return getFirst(usuarios, null);
	}
	
	public Usuario obterUsuarioPorEmail(String email) {
		ViewQuery busca = new ViewQuery()
			.viewName(VISAO_POR_EMAIL)
			.designDocId(DESIGN)
			.key(email);
		List<Usuario> usuarios = bancoDeDados.queryView(busca, Usuario.class);
		return getFirst(usuarios, null);
	}
	
	public Usuario obterUsuarioPorIdentificadorDoCouch(String identificadorDoCouch) {
		try {
			return get(identificadorDoCouch);
		} catch (DocumentNotFoundException excecao) {
			
		}
		return null;
	}
}
