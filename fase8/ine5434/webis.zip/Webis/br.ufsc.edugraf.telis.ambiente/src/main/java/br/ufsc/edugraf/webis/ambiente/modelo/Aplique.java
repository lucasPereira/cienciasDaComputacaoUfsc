package br.ufsc.edugraf.webis.ambiente.modelo;

import java.text.Collator;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonProperty;

import br.ufsc.edugraf.webis.ambiente.couch.RepositorioDeApliques;

public class Aplique implements Comparable<Aplique> {
	@JsonProperty("_id") private String identificadorDoCouch;
	@JsonProperty("_rev") private String revisaoDoCouch;
	@JsonProperty("nome") private String nome;
	@JsonProperty("modelo") private Modelo modelo = new Modelo("inicial");
	@JsonProperty("dataDeModificacao") private Date dataDeModificacao;
	@JsonProperty("identificadorDoCouchDoAutor") private String identificadorDoCouchDoAutor;
	@JsonProperty("tipo") public final String tipo = RepositorioDeApliques.TIPO;
	@JsonIgnore private Usuario autor;
	
	@JsonCreator 
	public Aplique(@JsonProperty("_id") String identificadorDoCouch, @JsonProperty("_rev") String revisaoDoCouch, @JsonProperty("nome") String nome, @JsonProperty("modelo") Modelo modelo, @JsonProperty("dataDeModificacao") Date dataDeModificacao, @JsonProperty("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor) {
		this.identificadorDoCouch = identificadorDoCouch;
		this.revisaoDoCouch = revisaoDoCouch;
		this.nome = nome;
		this.nome = nome;
		this.modelo = modelo;
		this.dataDeModificacao = dataDeModificacao;
		this.identificadorDoCouchDoAutor = identificadorDoCouchDoAutor;
	}
	
	public Aplique(String nome) {
		this.nome = nome;
	}
	
	public String obterNome() {
		return (nome != null) ? nome : "Sem nome";
	}
	
	public Modelo obterModelo() {
		return modelo;
	}
	
	public String obterIdentificadorDoCouchDoAutor() {
		return identificadorDoCouchDoAutor;
	}
	
	public Usuario obterAutor() {
		return autor;
	}
	
	public String obterDataDeModificacao() {
		return new Calendario(dataDeModificacao).obterData();
	}
	
	public String obterDataDeModificacaoPorExtenso() {
		return new Calendario(dataDeModificacao).obterDataPorExtenso();
	}
	
	public void fixarAutor(Usuario autor) {
		this.identificadorDoCouchDoAutor = autor.obterIdentificadorDoCouch();
		this.autor = autor;
	}
	
	public void fixarDataDeModificacao(Date dataDeModificacao) {
		this.dataDeModificacao = dataDeModificacao;
	}
	
	public void atualizarDataDeModificacao() {
		this.dataDeModificacao = new Date();
	}
	
	@Override
	public int compareTo(Aplique outro) {
		return Collator.getInstance().compare(this.nome, outro.nome);
	}
}
