package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import java.util.List;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaInicio extends DadosParaInterfaceGrafica {
	private List<Aplique> apliques;
	
	public DadosDaPaginaInicio(UriInfo uriInfo, Usuario usuarioAutenticado, List<Aplique> apliques) {
		super(uriInfo, usuarioAutenticado);
		this.apliques = apliques;
	}
	
	public List<Aplique> obterApliques() {
		return apliques;
	}
}
