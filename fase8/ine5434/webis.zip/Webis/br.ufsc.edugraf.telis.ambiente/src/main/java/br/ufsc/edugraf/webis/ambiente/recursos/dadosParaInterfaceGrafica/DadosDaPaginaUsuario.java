package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import java.util.List;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaUsuario extends DadosParaInterfaceGrafica {
	private List<Aplique> apliques;
	private Usuario usuario;
	
	public DadosDaPaginaUsuario(UriInfo uriInfo, Usuario usuarioAutenticado, Usuario usuario, List<Aplique> apliques) {
		super(uriInfo, usuarioAutenticado);
		this.apliques = apliques;
		this.usuario = usuario;
	}
	
	public List<Aplique> obterApliques() {
		return apliques;
	}
	public Usuario obterUsuario() {
		return usuario;
	}
}
