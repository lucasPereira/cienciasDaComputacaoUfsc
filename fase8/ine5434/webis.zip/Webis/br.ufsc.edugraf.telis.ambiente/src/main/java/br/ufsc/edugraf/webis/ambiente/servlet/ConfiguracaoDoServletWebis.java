package br.ufsc.edugraf.webis.ambiente.servlet;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.google.inject.Module;
import com.google.inject.servlet.GuiceServletContextListener;

public class ConfiguracaoDoServletWebis extends GuiceServletContextListener {
	
	private final Module[] modulos;
	
	public ConfiguracaoDoServletWebis() {
		this(new Module[] {new Servicos(), new ModuloDeRecursosPadrao()});
	}
	
	public ConfiguracaoDoServletWebis(Module[] modulos) {
		this.modulos = modulos;
	}
	
	@Override
	protected Injector getInjector() {
		return Guice.createInjector(modulos);
		
	}
}
