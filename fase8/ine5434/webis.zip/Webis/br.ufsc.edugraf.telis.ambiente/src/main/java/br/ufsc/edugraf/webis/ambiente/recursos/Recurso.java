package br.ufsc.edugraf.webis.ambiente.recursos;

import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosParaInterfaceGrafica;

import com.sun.jersey.api.view.Viewable;

public class Recurso {
	protected static final String MIDIA_FLUXO_DE_OCTETO = "application/octet-stream";
	protected static final String MIDIA_CSS = "text/css";
	protected static final String MIDIA_MP3 = "audio/mp3";
	protected static final String MIDIA_AUDIO = "audio/*";
	protected static final String MIDIA_JS = "application/javascript";
	protected static final String MIDIA_HTML = "text/html";
	protected static final MediaType TIPO_DE_MIDIA_FLUXO_DE_OCTETO = MediaType.valueOf(MIDIA_FLUXO_DE_OCTETO);
	protected static final MediaType TIPO_DE_MIDIA_CSS = MediaType.valueOf(MIDIA_CSS);
	protected static final MediaType TIPO_DE_MIDIA_MP3 = MediaType.valueOf(MIDIA_MP3);
	protected static final MediaType TIPO_DE_MIDIA_AUDIO = MediaType.valueOf(MIDIA_AUDIO);
	protected static final MediaType TIPO_DE_MIDIA_JS = MediaType.valueOf(MIDIA_JS);
	protected static final MediaType TIPO_DE_MIDIA_HTML = MediaType.valueOf(MIDIA_HTML);
	
	protected Response obterRespostaDePaginaHtml(Arquivos pagina, DadosParaInterfaceGrafica dados) {
		return Response
					.status(Status.OK)
					.header("Access-Control-Allow-Origin", "*")
					.type(MediaType.TEXT_HTML)
					.entity(new Viewable(pagina.comoTexto(), dados))
					.build();
	}
	
	protected Response obterRespostaDePaginaHtml(Arquivos pagina, Status codigoDeEstado, DadosParaInterfaceGrafica dados) {
		return Response
					.status(codigoDeEstado)
					.header("Access-Control-Allow-Origin", "*")
					.type(MediaType.TEXT_HTML)
					.entity(new Viewable(pagina.comoTexto(), dados))
					.build();
	}
	
	protected Response obterRespostaDeSom(InputStream som, MediaType tipoDeMidia) {
		return Response
					.status(Status.OK)
					.header("Access-Control-Allow-Origin", "*")
					.entity(som)
					.type(tipoDeMidia)
					.build();
	}
	
	protected Response obterRespostaDeRecurso(InputStream recurso, MediaType tipoDeMidia) {
		return Response
					.status(Status.OK)
					.header("Access-Control-Allow-Origin", "*")
					.entity(recurso)
					.type(tipoDeMidia)
					.build();
	}
	
	protected Response obterRespostaDeProibido() {
		return Response
					.status(Status.FORBIDDEN)
					.build();
	}
	
	protected Response obterRespostaDeRequisicaoMalFeita() {
		return Response
					.status(Status.BAD_REQUEST)
					.build();
	}
	
	protected Response obterRespostaDeAutenticacaoNecessaria() {
		return Response
					.status(Status.UNAUTHORIZED)
					.build();
	}
	
	protected Response obterRespostaDeSucesso() {
		return Response
					.status(Status.OK)
					.build();
	}
	
	protected Response obterRespostaDeNaoEncontrado() {
		return Response
					.status(Status.NOT_FOUND)
					.build();
	}
	
	protected InputStream obterRecurso(ServletContext contextoDeServlet, String caminho) {
		InputStream recurso = contextoDeServlet.getResourceAsStream("/" + caminho);
		if (recurso == null) {
			throw new WebApplicationException(obterRespostaDeNaoEncontrado());
		}
		return recurso;
	}
	
	protected Usuario obterAutor(String identificadorDoCouchDoAutor, RepositorioDoAmbiente repositorio) {
		Usuario autor = repositorio.obterUsuarioPorIdentificadorDoCouch(identificadorDoCouchDoAutor);
		if (autor == null) {
			throw new WebApplicationException(obterRespostaDeNaoEncontrado());
		}
		return autor;
	}
	
	protected Usuario obterAutorAutenticado(String identificadorDoCouchDoAutor, Usuario usuarioAutenticado, RepositorioDoAmbiente repositorio) {
		if (usuarioAutenticado == null) {
			throw new WebApplicationException(obterRespostaDeAutenticacaoNecessaria());
		}
		Usuario autor = obterAutor(identificadorDoCouchDoAutor, repositorio);
		if (!autor.equals(usuarioAutenticado)) {
			throw new WebApplicationException(obterRespostaDeProibido());
		}
		return autor;
	}
	
	protected Usuario obterUsuarioAutenticado(Usuario usuarioAutenticado) {
		if (usuarioAutenticado == null) {
			throw new WebApplicationException(obterRespostaDeAutenticacaoNecessaria());
		}
		return usuarioAutenticado;
	}
}
