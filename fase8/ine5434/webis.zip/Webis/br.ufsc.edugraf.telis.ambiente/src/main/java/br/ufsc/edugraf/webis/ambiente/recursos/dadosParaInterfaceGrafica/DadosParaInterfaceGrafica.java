package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import static com.google.common.collect.Lists.newArrayList;
import static java.util.Collections.unmodifiableList;

import java.net.URI;
import java.util.List;

import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.apache.commons.lang3.tuple.Pair;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Som;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoAcessibilidade;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoAplique;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoApliques;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoAutenticacao;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoCarregamentoDeSom;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoCriacaoDeAplique;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoEstilo;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoPrimitivas;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoSom;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoSons;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoTodosApliques;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoTodosSons;
import br.ufsc.edugraf.webis.ambiente.recursos.RecursoUsuario;

public class DadosParaInterfaceGrafica {
	private UriInfo informacaoDeUri;
	private Usuario usuarioAutenticado;
	private List<Pair<String, String>> menu = newArrayList();
	
	public DadosParaInterfaceGrafica(UriInfo uriInfo, Usuario usuarioAutenticado) {
		this.informacaoDeUri = uriInfo;
		this.usuarioAutenticado = usuarioAutenticado;
	}
	
	public Usuario obterUsuarioAutenticado() {
		return usuarioAutenticado;
	}
	
	private UriBuilder obterConstrutorDeCaminho() {
		return informacaoDeUri.getBaseUriBuilder();
	}
	
	public String obterUriInicio() {
		return obterConstrutorDeCaminho().build().getPath();
	}
	
	public String obterUriAcessibilidade() {
		return obterConstrutorDeCaminho().path(RecursoAcessibilidade.class).build().getPath();
	}
	
	public String obterUriPrimitivas() {
		return obterConstrutorDeCaminho().path(RecursoPrimitivas.class).build().getPath();
	}
	
	public String obterUriAutenticacao() {
		return obterConstrutorDeCaminho().path(RecursoAutenticacao.class).build().getPath();
	}
	
	public String obterUriDesautenticacao() {
		return obterConstrutorDeCaminho().path(RecursoAutenticacao.class).segment("desassociar").build().getPath();
	}
	
	public String obterUriUsuario(Usuario usuario) {
		return obterConstrutorDeCaminho().path(RecursoUsuario.class).build(usuario.obterIdentificadorDoCouch()).getPath();
	}

	public String obterUriUsuarioAutenticado() {
		return obterConstrutorDeCaminho().path(RecursoUsuario.class).build(usuarioAutenticado.obterIdentificadorDoCouch()).getPath();
	}
	
	public String obterUriEstilo(String nome) {
		return obterConstrutorDeCaminho().path(RecursoEstilo.class).build(nome).getPath();
	}
	
	public String obterUriAplique(Aplique aplique) {
		return obterUriAplique(aplique.obterAutor(), aplique);
	}
	
	public String obterUriAplique(Usuario usuario, Aplique aplique) {
		return obterConstrutorDeCaminho().path(RecursoAplique.class).build(usuario.obterIdentificadorDoCouch(), aplique.obterNome()).getPath();
	}
	
	public String obterUriExecucaoDoAplique(Usuario usuario, Aplique aplique) {
		return obterConstrutorDeCaminho().path(RecursoAplique.class).segment("aplique.html").build(usuario.obterIdentificadorDoCouch(), aplique.obterNome()).getPath();
	}
	
	public String obterUriApliques(Usuario usuario) {
		return obterConstrutorDeCaminho().path(RecursoApliques.class).build(usuario.obterIdentificadorDoCouch(), "").getPath();
	}
	
	public String obterUriApliques() {
		return obterUriApliques(usuarioAutenticado);
	}
	
	public String obterUriTodosApliques() {
		return obterConstrutorDeCaminho().path(RecursoTodosApliques.class).build().getPath();
	}
	
	public String obterUriCriacaoDeAplique() {
		return obterConstrutorDeCaminho().path(RecursoCriacaoDeAplique.class).build().getPath();
	}
	
	public String obterUriSom(Som som) {
		URI uri = obterConstrutorDeCaminho().path(RecursoSom.class).build(som.obterAutor().obterIdentificadorDoCouch(), som.obterNome());
		return uri.toString();
	}
	
	public String obterUriSom() {
		URI uri = obterConstrutorDeCaminho().path(RecursoSom.class).build(usuarioAutenticado.obterIdentificadorDoCouch(), "");
		return uri.toString();
	}
	
	public String obterUriSons(Usuario usuario) {
		return obterConstrutorDeCaminho().path(RecursoSons.class).build(usuario.obterIdentificadorDoCouch()).getPath();
	}
	
	public String obterUriSons() {
		return obterUriSons(usuarioAutenticado);
	}
	
	public String obterUriTodosSons() {
		return obterConstrutorDeCaminho().path(RecursoTodosSons.class).build().getPath();
	}
	
	public String obterUriCarregamentoDeSom() {
		return obterConstrutorDeCaminho().path(RecursoCarregamentoDeSom.class).build().getPath();
	}
	
	public List<Pair<String, String>> obterMenu() {
		return unmodifiableList(menu);
	}
	
	public boolean usuarioEstaAutenticado() {
		return (usuarioAutenticado != null);
	}
	
	public boolean usuarioEOUsuarioAutenticado(Usuario usuario) {
		if (usuarioEstaAutenticado()) {
			return usuarioAutenticado.equals(usuario);
		}
		return false;
	}
}
