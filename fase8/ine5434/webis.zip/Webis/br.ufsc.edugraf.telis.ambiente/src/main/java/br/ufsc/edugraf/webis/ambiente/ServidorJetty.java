package br.ufsc.edugraf.webis.ambiente;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.server.handler.DefaultHandler;
import org.eclipse.jetty.server.handler.HandlerCollection;
import org.eclipse.jetty.server.handler.RequestLogHandler;
import org.eclipse.jetty.servlet.DefaultServlet;
import org.eclipse.jetty.servlet.ServletContextHandler;

import br.ufsc.edugraf.webis.ambiente.servlet.AtualizacaoDasVisoesDoCouchDB;
import br.ufsc.edugraf.webis.ambiente.servlet.ConfiguracaoDoServletWebis;
import br.ufsc.edugraf.webis.ambiente.servlet.ConfiguracaoJUL;
import br.ufsc.edugraf.webis.ambiente.servlet.ModuloDeRecursosPadrao;
import br.ufsc.edugraf.webis.ambiente.servlet.Servicos;
import ch.qos.logback.access.jetty.RequestLogImpl;

import com.google.inject.Module;
import com.google.inject.servlet.GuiceFilter;

public class ServidorJetty {
	private static final int PORTA_PADRÃO = 9090;
	private Server server;
	
	public ServidorJetty(int porta) {
		this(porta, new Module[] {new Servicos(), new ModuloDeRecursosPadrao()});
	}
	
	public ServidorJetty(int porta, Module ... modulos) {
		server = new Server(porta);
		HandlerCollection handlers = new HandlerCollection();
		ServletContextHandler servletContextHandler = new ServletContextHandler(server, "/", true, false);
		servletContextHandler.setResourceBase("src/main/webapp");
		servletContextHandler.addEventListener(new ConfiguracaoJUL());
		servletContextHandler.addEventListener(new ConfiguracaoDoServletWebis(modulos));
		servletContextHandler.addEventListener(new AtualizacaoDasVisoesDoCouchDB());
		servletContextHandler.addFilter(GuiceFilter.class, "/*", null);
		servletContextHandler.addServlet(DefaultServlet.class, "/");
		RequestLogHandler requestLogHandler = new RequestLogHandler();
		RequestLogImpl requestLog = new RequestLogImpl();
		requestLog.setResource("/logback-access.xml");
		requestLogHandler.setRequestLog(requestLog);
		handlers.setHandlers(new org.eclipse.jetty.server.Handler[]{servletContextHandler, new DefaultHandler(), requestLogHandler});
		server.setHandler(handlers);
	}
	
	public void iniciar() throws Exception {
		server.start();
	}
	
	public void desligar() throws Exception {
		server.stop();
	}
	
	public static void main(String[] args) throws Exception {
		ServidorJetty servidor = new ServidorJetty(PORTA_PADRÃO);
		try {
			servidor.iniciar();
		} catch (Exception excecao) {
			servidor.desligar();
		}
	}
}

