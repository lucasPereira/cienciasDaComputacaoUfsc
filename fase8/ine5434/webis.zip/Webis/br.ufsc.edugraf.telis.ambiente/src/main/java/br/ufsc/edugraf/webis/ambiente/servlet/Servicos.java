package br.ufsc.edugraf.webis.ambiente.servlet;

import br.ufsc.edugraf.webis.ambiente.couch.RepositorioEmCouch;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;

import com.google.inject.AbstractModule;

public final class Servicos extends AbstractModule {
	@Override
	public void configure() {
		bind(RepositorioDoAmbiente.class).to(RepositorioEmCouch.class);
	}
}
