package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaAplique extends DadosParaInterfaceGrafica {
	private boolean podeSalvar = false;
	private boolean podeCriar = false;
	private Aplique aplique;
	private Usuario autor;
	
	public DadosDaPaginaAplique(UriInfo uriInfo, Usuario usuarioAutenticado, Usuario autor, Aplique aplique) {
		super(uriInfo, usuarioAutenticado);
		this.aplique = aplique;
		this.autor = autor;
	}
	
	public void autorizarSalvamento() {
		this.podeSalvar  = true;
	}
	
	public void autorizarCriacao() {
		this.podeCriar  = true;
	}
	
	public Aplique obterAplique() {
		return aplique;
	}
	
	public Usuario obterAutor() {
		return autor;
	}
	
	public boolean podeSalvarOAplique() {
		return podeSalvar;
	}
	
	public boolean podeCriarOAplique() {
		return podeCriar;
	}
}
