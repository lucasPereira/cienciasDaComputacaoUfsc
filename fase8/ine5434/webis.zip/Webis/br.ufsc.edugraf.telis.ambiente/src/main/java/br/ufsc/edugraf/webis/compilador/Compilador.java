package br.ufsc.edugraf.webis.compilador;

import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.antlr.runtime.ANTLRStringStream;
import org.antlr.runtime.CharStream;
import org.antlr.runtime.CommonTokenStream;
import org.antlr.runtime.EarlyExitException;
import org.antlr.runtime.FailedPredicateException;
import org.antlr.runtime.MismatchedNotSetException;
import org.antlr.runtime.MismatchedSetException;
import org.antlr.runtime.MismatchedTokenException;
import org.antlr.runtime.MismatchedTreeNodeException;
import org.antlr.runtime.MissingTokenException;
import org.antlr.runtime.NoViableAltException;
import org.antlr.runtime.RecognitionException;
import org.antlr.runtime.Token;
import org.antlr.runtime.TokenStream;
import org.antlr.runtime.UnwantedTokenException;
import org.antlr.stringtemplate.StringTemplate;
import org.antlr.stringtemplate.StringTemplateGroup;

public final class Compilador {
	private static final String FIM_DE_ARQUIVO = "'fim de arquivo'";
	private static final String FORMATO_DE_SIMBOLO = "%s";
	
	public String compilar(String codigo) throws RecognitionException {
		StringTemplateGroup templateDeCodigo = new StringTemplateGroup(new InputStreamReader(Compilador.class.getResourceAsStream("webisJs.stg")));
		CharStream fluxoDeCaracteres = new ANTLRStringStream(codigo);
		WebisLexer analisadorLexico = new WebisLexer(fluxoDeCaracteres);
		TokenStream fluxoDeSimbolos = new CommonTokenStream(analisadorLexico);
		WebisParser analisadorSintatico = new WebisParser(fluxoDeSimbolos);
		analisadorSintatico.setTemplateLib(templateDeCodigo);
		StringTemplate codigoCompilado = (StringTemplate) analisadorSintatico.programa().getTemplate();
		codigoCompilado.setAttribute("errosDeCompilacao", obterCodigoCompiladoDeErros(analisadorSintatico, analisadorLexico, templateDeCodigo));
		return codigoCompilado.toString();
	}
	
	private List<StringTemplate> obterCodigoCompiladoDeErros(WebisParser analisadorSintatico, WebisLexer analisadorLexico, StringTemplateGroup templateDeCodigo) {
		LinkedList<StringTemplate> templatesDeErro = new LinkedList<StringTemplate>();
		adicionarErrosLexicos(analisadorLexico, templateDeCodigo, templatesDeErro);
		adicionarErrosSinticos(analisadorSintatico, templateDeCodigo, templatesDeErro);
		return templatesDeErro;
	}
	
	private void adicionarErrosSinticos(WebisParser analisadorSintatico, StringTemplateGroup templateDeCodigo, LinkedList<StringTemplate> templatesDeErro) {
		for (RecognitionException erro : analisadorSintatico.obterErros()){
			Map<String, String> mapeamentoDeErroSintatico = new HashMap<String, String>();
			mapeamentoDeErroSintatico.put("r", obterLexema(erro.token));
			mapeamentoDeErroSintatico.put("e", obterSimboloEsperado(erro, analisadorSintatico.getTokenNames()));
			mapeamentoDeErroSintatico.put("y", erro.line + "");
			mapeamentoDeErroSintatico.put("x", erro.charPositionInLine + "");
			StringTemplate templateDeErroSintatico = templateDeCodigo.getInstanceOf("erroSintatico", mapeamentoDeErroSintatico);
			templatesDeErro.addLast(templateDeErroSintatico);
		}
	}
	
	private void adicionarErrosLexicos(WebisLexer analisadorLexico, StringTemplateGroup templateDeCodigo, LinkedList<StringTemplate> templatesDeErro) {
		for (RecognitionException erro : analisadorLexico.obterErros()){
			Map<String, String> mapeamentoDeErroLexico = new HashMap<String, String>();
			mapeamentoDeErroLexico.put("r", obterCaractere(erro.c));
			mapeamentoDeErroLexico.put("y", erro.line + "");
			mapeamentoDeErroLexico.put("x", erro.charPositionInLine + "");
			StringTemplate templateDeErroLexico = templateDeCodigo.getInstanceOf("erroLexico", mapeamentoDeErroLexico);
			templatesDeErro.addLast(templateDeErroLexico);
		}
	}
	
	private String obterLexema(Token simbolo) {
		if (simbolo.getType() == Token.EOF) {
			return String.format(FORMATO_DE_SIMBOLO, FIM_DE_ARQUIVO);
		}
		return normalizarTexto(simbolo.getText());
	}
	
	private String obterCaractere(int caractereComoInteiro) {
		if (caractereComoInteiro < 0) {
			return String.format(FORMATO_DE_SIMBOLO, FIM_DE_ARQUIVO);
		}
		return normalizarTexto(((char) caractereComoInteiro) + "");
	}
	
	private String normalizarTexto(String texto) {
		texto = texto.replaceAll("\\s", " ");
		texto = texto.replaceAll("\"", "\\\\\"");
		texto = texto.replaceAll("'", "\\\\'");
		return texto;
	}
	
	private String obterSimboloEsperado(RecognitionException erro, String[] nomesDosSimbolos) {
		String simboloEsperado = null;
		int indiceDoSimboloEsperado = 0;
		if (erro instanceof UnwantedTokenException) {
			indiceDoSimboloEsperado = ((UnwantedTokenException) erro).expecting;
		} else if (erro instanceof MissingTokenException) {
			indiceDoSimboloEsperado = ((MissingTokenException) erro).expecting;
		} else if (erro instanceof MismatchedTokenException) {
			indiceDoSimboloEsperado = ((MismatchedTokenException) erro).expecting;
		} else if (erro instanceof MismatchedTreeNodeException) {
			indiceDoSimboloEsperado = ((MismatchedTreeNodeException) erro).expecting;
		} else if (erro instanceof NoViableAltException) {
			indiceDoSimboloEsperado = Token.EOF;
		} else if (erro instanceof EarlyExitException) {
			indiceDoSimboloEsperado = Token.EOF;
		} else if (erro instanceof MismatchedSetException) {
			simboloEsperado = ((MismatchedSetException) erro).expecting + "";
		} else if (erro instanceof MismatchedNotSetException) {
			simboloEsperado = ((MismatchedNotSetException) erro).expecting + "";
		} else if (erro instanceof FailedPredicateException) {
			simboloEsperado = ((FailedPredicateException) erro).predicateText;
		} else {
			indiceDoSimboloEsperado = erro.index;
		}
		if (simboloEsperado == null) {
			if (indiceDoSimboloEsperado == Token.EOF) {
				simboloEsperado = FIM_DE_ARQUIVO;
			} else {
				simboloEsperado = nomesDosSimbolos[indiceDoSimboloEsperado];
			}
			simboloEsperado = String.format(FORMATO_DE_SIMBOLO, simboloEsperado);
		}
		return simboloEsperado;
	}
}
