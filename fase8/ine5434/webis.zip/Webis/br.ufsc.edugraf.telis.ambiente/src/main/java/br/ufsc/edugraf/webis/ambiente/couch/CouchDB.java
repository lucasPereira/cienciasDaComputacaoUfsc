package br.ufsc.edugraf.webis.ambiente.couch;

import java.net.MalformedURLException;

import org.ektorp.CouchDbConnector;
import org.ektorp.CouchDbInstance;
import org.ektorp.http.HttpClient;
import org.ektorp.http.StdHttpClient;
import org.ektorp.impl.StdCouchDbConnector;
import org.ektorp.impl.StdCouchDbInstance;

public class CouchDB {
	private static CouchDB couchDB = new CouchDB();
	private HttpClient clienteHttp;
	private CouchDbInstance bancoDeDados; 
//	private static final String NOME_DA_BASE_DE_DADOS = "webis";
//	private static final String ENDERECO_DO_COUCH = "http://mole.edugraf.ufsc.br:5984/";
	private static final String NOME_DA_BASE_DE_DADOS = "ambientewebis";
	private static final String ENDERECO_DO_COUCH = "http://localhost:5984/";
	
	public static CouchDB obterInstancia() {
		return couchDB;
	}
	
	private CouchDB() {
		try {
			clienteHttp = new StdHttpClient.Builder().url(ENDERECO_DO_COUCH).build();
		} catch (MalformedURLException excecao) {
			
		}
		bancoDeDados = new StdCouchDbInstance(clienteHttp);
	}
	
	public CouchDbConnector obterConexãoComCouchDB() {
		CouchDbConnector conectorDoBancoDeDados = new StdCouchDbConnector(NOME_DA_BASE_DE_DADOS, bancoDeDados);
		conectorDoBancoDeDados.createDatabaseIfNotExists();
		return conectorDoBancoDeDados;
	}
}
