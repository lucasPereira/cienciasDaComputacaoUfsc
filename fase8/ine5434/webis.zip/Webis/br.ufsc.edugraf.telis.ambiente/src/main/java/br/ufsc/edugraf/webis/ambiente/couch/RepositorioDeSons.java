package br.ufsc.edugraf.webis.ambiente.couch;

import static com.google.common.collect.Iterables.getFirst;

import java.util.List;

import org.ektorp.ComplexKey;
import org.ektorp.CouchDbConnector;
import org.ektorp.ViewQuery;
import org.ektorp.support.CouchDbRepositorySupport;
import org.ektorp.support.View;
import org.ektorp.support.Views;

import br.ufsc.edugraf.webis.ambiente.modelo.Som;

@Views({
	@View(name = RepositorioDeSons.VISAO_POR_NOME, map = "function(documento) { if (documento.tipo == '" + RepositorioDeSons.TIPO + "') { emit(documento.nome, documento); } }"),
	@View(name = RepositorioDeSons.VISAO_POR_DATA_DE_CARREGAMENTO, map = "function(documento) { if (documento.tipo == '" + RepositorioDeSons.TIPO + "') { emit(documento.dataDeCarregamento, documento); } }"),
	@View(name = RepositorioDeSons.VISAO_POR_AUTOR_E_NOME, map = "function(documento) { if (documento.tipo == '" + RepositorioDeSons.TIPO + "') { emit([documento.identificadorDoCouchDoAutor, documento.nome], documento); } }"),
	@View(name = RepositorioDeSons.VISAO_POR_AUTOR_E_DATA_DE_CARREGAMENTO, map = "function(documento) { if (documento.tipo == '" + RepositorioDeSons.TIPO + "') { emit([documento.identificadorDoCouchDoAutor, documento.dataDeCarregamento], documento); } }")
})
public class RepositorioDeSons extends CouchDbRepositorySupport<Som> {
	public static final String TIPO = "som";
	private static final String DESIGN = "_design/" + TIPO;
	protected static final String VISAO_POR_NOME = "porNome";
	protected static final String VISAO_POR_DATA_DE_CARREGAMENTO = "porDataDeCarregamento";
	protected static final String VISAO_POR_AUTOR_E_NOME = "porAutorENome";
	protected static final String VISAO_POR_AUTOR_E_DATA_DE_CARREGAMENTO = "porAutorEDataDeCarregamento";
	private CouchDbConnector bancoDeDados;
	
	public RepositorioDeSons(CouchDbConnector bancoDeDados) {
		super(Som.class, bancoDeDados, TIPO);
		initStandardDesignDocument();
		this.bancoDeDados = bancoDeDados;
	}
	
	public List<Som> obterSonsOrdenadosPorNome() {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_NOME)
			.descending(false);
		return bancoDeDados.queryView(busca, Som.class);
	}
	
	public List<Som> obterSonsOrdenadosPorDataDeCarregamento() {
		ViewQuery busca = new ViewQuery()
			.designDocId(DESIGN)
			.viewName(VISAO_POR_DATA_DE_CARREGAMENTO)
			.descending(true);
		return bancoDeDados.queryView(busca, Som.class);
	}
	
	public List<Som> obterSonsPorIdentificadorDoCouchDoAutorOrdenadosPorNome(String identificadorDoCouchDoAtor) {
		ViewQuery busca = new ViewQuery()
		.designDocId(DESIGN)
			.viewName(VISAO_POR_AUTOR_E_NOME)
			.descending(true)
			.inclusiveEnd(true)
			.startKey(ComplexKey.of(identificadorDoCouchDoAtor, ComplexKey.emptyObject()))
			.endKey(ComplexKey.of(identificadorDoCouchDoAtor));
		return bancoDeDados.queryView(busca, Som.class);
	}
	
	public List<Som> obterSonsPorIdentificadorDoCouchDoAutorOrdenadosPorDataDeCarregamento(String identificadorDoCouchDoAtor) {
		ViewQuery busca = new ViewQuery()
		.designDocId(DESIGN)
			.viewName(VISAO_POR_AUTOR_E_DATA_DE_CARREGAMENTO)
			.descending(true)
			.inclusiveEnd(true)
			.startKey(ComplexKey.of(identificadorDoCouchDoAtor, ComplexKey.emptyObject()))
			.endKey(ComplexKey.of(identificadorDoCouchDoAtor));
		return bancoDeDados.queryView(busca, Som.class);
	}
	
	public Som obterSomPorIdentificadorDoCouchDoAutorENome(String identificadorDoCouchDoAutor, String nome) {
		List<Som> apliquesEncontrados = queryView(VISAO_POR_AUTOR_E_NOME, ComplexKey.of(identificadorDoCouchDoAutor, nome));
		return getFirst(apliquesEncontrados, null);
	}
}
