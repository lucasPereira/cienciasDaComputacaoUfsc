package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import java.util.List;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaTodosApliques extends DadosParaInterfaceGrafica {
	private List<Aplique> apliques;
	
	public DadosDaPaginaTodosApliques(UriInfo uriInfo, Usuario usuarioAutenticado, List<Aplique> apliques) {
		super(uriInfo, usuarioAutenticado);
		this.apliques = apliques;
	}
	
	public List<Aplique> obterApliques() {
		return apliques;
	}
}
