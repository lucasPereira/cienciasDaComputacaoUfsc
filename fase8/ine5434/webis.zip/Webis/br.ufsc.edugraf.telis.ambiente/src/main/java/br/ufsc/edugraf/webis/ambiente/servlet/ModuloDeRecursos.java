package br.ufsc.edugraf.webis.ambiente.servlet;

import static com.google.common.base.Joiner.on;
import static com.google.common.collect.Lists.newArrayList;
import static com.google.common.collect.Maps.newHashMap;

import java.util.Collection;
import java.util.Map;

import com.sun.jersey.api.container.filter.RolesAllowedResourceFilterFactory;
import com.sun.jersey.api.core.PackagesResourceConfig;
import com.sun.jersey.guice.JerseyServletModule;
import com.sun.jersey.guice.spi.container.servlet.GuiceContainer;
import com.sun.jersey.spi.container.ContainerRequestFilter;

public class ModuloDeRecursos extends JerseyServletModule {
	
	private Collection<String> filtros = newArrayList();
	
	public ModuloDeRecursos() {
		
	}
	
	public void adicionarFiltro(Class<? extends ContainerRequestFilter> filtro) {
		filtros.add(filtro.getName());
	}
	
	@Override
	protected void configureServlets() {
		Map<String, String> params = newHashMap();
		params.put(PackagesResourceConfig.PROPERTY_PACKAGES, "br.ufsc.edugraf.webis.ambiente.recursos");
		params.put(PackagesResourceConfig.PROPERTY_CONTAINER_REQUEST_FILTERS, on(' ').join(filtros));
		params.put(PackagesResourceConfig.PROPERTY_RESOURCE_FILTER_FACTORIES, RolesAllowedResourceFilterFactory.class.getName());
		serve("/*").with(GuiceContainer.class, params);
	}
}
