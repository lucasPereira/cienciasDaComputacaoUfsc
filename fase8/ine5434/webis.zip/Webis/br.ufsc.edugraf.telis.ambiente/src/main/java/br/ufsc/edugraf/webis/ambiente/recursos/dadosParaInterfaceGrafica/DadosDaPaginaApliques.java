package br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica;

import java.util.List;

import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

public class DadosDaPaginaApliques extends DadosParaInterfaceGrafica {
	private List<Aplique> apliques;
	private Usuario autor;
	
	public DadosDaPaginaApliques(UriInfo informacaoDeUri, Usuario usuarioAutenticado, List<Aplique> apliques, Usuario autor) {
		super(informacaoDeUri, usuarioAutenticado);
		this.apliques = apliques;
		this.autor = autor;
	}
	
	public List<Aplique> obterApliques() {
		return this.apliques;
	}
	
	public Usuario obterAutor() {
		return autor;
	}
}
