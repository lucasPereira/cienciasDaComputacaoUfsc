package br.ufsc.edugraf.webis.ambiente.recursos;

import java.io.InputStream;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;

import com.google.inject.Inject;

@Path("/{nome: .+\\.css}")
public class RecursoEstilo extends Recurso {
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	
	@Inject
	public RecursoEstilo(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		
	}
	
	@GET
	@Produces(Recurso.MIDIA_CSS)
	public Response obterCss(@PathParam("nome") String nome) throws MalformedURLException {
		InputStream estilo = obterRecurso(contextoDeServlet, nome);
		return obterRespostaDeRecurso(estilo, TIPO_DE_MIDIA_CSS);
	}
}
