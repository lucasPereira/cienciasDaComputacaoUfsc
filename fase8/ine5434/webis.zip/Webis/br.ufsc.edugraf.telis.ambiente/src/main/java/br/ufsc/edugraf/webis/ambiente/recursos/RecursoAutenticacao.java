package br.ufsc.edugraf.webis.ambiente.recursos;

import java.net.MalformedURLException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import org.openid4java.association.AssociationException;
import org.openid4java.consumer.ConsumerException;
import org.openid4java.consumer.ConsumerManager;
import org.openid4java.consumer.VerificationResult;
import org.openid4java.discovery.DiscoveryException;
import org.openid4java.discovery.DiscoveryInformation;
import org.openid4java.discovery.Identifier;
import org.openid4java.message.AuthRequest;
import org.openid4java.message.AuthSuccess;
import org.openid4java.message.MessageException;
import org.openid4java.message.ParameterList;
import org.openid4java.message.ax.AxMessage;
import org.openid4java.message.ax.FetchRequest;
import org.openid4java.message.ax.FetchResponse;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

import com.google.inject.Inject;
import com.sun.jersey.api.view.Viewable;

@Path("/autenticacao")
public class RecursoAutenticacao {
	private static final String OPENID_DO_GOOGLE = "https://www.google.com/accounts/o8/id";
	private static final ConsumerManager manager = new ConsumerManager();
	@Context private UriInfo uriInfo;
	@Context private HttpServletRequest request;
	@Inject private RepositorioDoAmbiente repositorio;
	
	public RecursoAutenticacao() {
		
	}
	
	@GET
	@Produces("text/html;charset=UTF-8")
	public Response obterHtml() throws MalformedURLException,	DiscoveryException, MessageException, ConsumerException, AssociationException {
		if (request.getSession().getAttribute("openid") != null) {
			URI uriInicial = obterConstrutorDeCaminho().path(RecursoInicio.class).build();
			return Response.seeOther(uriInicial).build();
		}
		Viewable entidade = autenticar();
		return Response.ok().entity(entidade).build();
	}
	
	@GET
	@Path("retorno")
	public Response retorno() throws MessageException, DiscoveryException, AssociationException, MalformedURLException, ConsumerException {
		VerificationResult resultadoOpenId = this.obterIdentificador();
		Identifier identificador = resultadoOpenId.getVerifiedId();
		if (identificador != null) {
			AuthSuccess autorizacaoBemSucedida = (AuthSuccess) resultadoOpenId.getAuthResponse();
			if (autorizacaoBemSucedida.hasExtension(AxMessage.OPENID_NS_AX)) {
				FetchResponse resposta = (FetchResponse) autorizacaoBemSucedida.getExtension(AxMessage.OPENID_NS_AX);
				String email = resposta.getAttributeValue("email");
				String nome = resposta.getAttributeValue("nome");
				Usuario usuario = repositorio.obterUsuarioPorEmail(email);
				if (usuario == null) {
					usuario = new Usuario(identificador.getIdentifier(), nome, email);
				} else {
					usuario.fixarIdentificadorDoOpenId(identificador.getIdentifier());
					usuario.fixarNome(nome);
					usuario.fixarEmail(email);
				}
				repositorio.salvarUsuario(usuario);
				request.getSession().setAttribute("openid", identificador);
				URI uriInicial = obterConstrutorDeCaminho().path(RecursoInicio.class).build();
				return Response.seeOther(uriInicial).build();
			}
		}
		return obterHtml();
	}
	
	@GET
	@Path("desassociar")
	public Response logout() throws MessageException, DiscoveryException, AssociationException, MalformedURLException, ConsumerException {
		request.getSession().invalidate();
		URI uriInicial = obterConstrutorDeCaminho().path(RecursoInicio.class).build();
		return Response.seeOther(uriInicial).build();
	}
	
	private Viewable autenticar() throws DiscoveryException, MessageException, ConsumerException {
		List<?> dadosDescobertos = manager.discover(OPENID_DO_GOOGLE);
		DiscoveryInformation informacoesDescobertas = manager.associate(dadosDescobertos);
		request.getSession().setAttribute("openid-disc", informacoesDescobertas);
		String uriDeRetorno = obterConstrutorDeCaminho().path(RecursoAutenticacao.class).segment("retorno").build().toString();
		AuthRequest requisicaoDeAutorizacao = manager.authenticate(informacoesDescobertas, uriDeRetorno);
		FetchRequest informacoesAdicionais = FetchRequest.createFetchRequest();
		informacoesAdicionais.addAttribute("email", "http://schema.openid.net/contact/email", true);
		informacoesAdicionais.addAttribute("nome", "http://axschema.org/namePerson/first", true);
		requisicaoDeAutorizacao.addExtension(informacoesAdicionais);
		Map<String, Object> dados = new HashMap<String, Object>();
		dados.put("parametros", requisicaoDeAutorizacao.getParameterMap());
		dados.put("uri", requisicaoDeAutorizacao.getDestinationUrl(false));
		return new Viewable("/br/ufsc/edugraf/webis/ambiente/recursos/formularioRedirecionamentoOpenID.tpl", dados);
	}
	
	public VerificationResult obterIdentificador() throws MessageException, DiscoveryException, AssociationException {
		ParameterList resposta = new ParameterList(request.getParameterMap());
		DiscoveryInformation informacaoDescoberta = (DiscoveryInformation) request.getSession().getAttribute("openid-disc");
		StringBuffer urlRecebida = request.getRequestURL();
		String parametrosDaUrl = request.getQueryString();
		if (parametrosDaUrl != null && parametrosDaUrl.length() > 0) {
			urlRecebida.append("?").append(request.getQueryString());
		}
		VerificationResult verification = manager.verify(urlRecebida.toString(), resposta, informacaoDescoberta);
		return verification;
	}
	
	private UriBuilder obterConstrutorDeCaminho() {
		return uriInfo.getBaseUriBuilder();
	}
}
