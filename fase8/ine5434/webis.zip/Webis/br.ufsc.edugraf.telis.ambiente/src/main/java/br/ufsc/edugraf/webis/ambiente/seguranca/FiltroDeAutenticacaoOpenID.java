package br.ufsc.edugraf.webis.ambiente.seguranca;

import java.security.Principal;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import org.openid4java.discovery.Identifier;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;

import com.google.inject.Inject;
import com.sun.jersey.spi.container.ContainerRequest;
import com.sun.jersey.spi.container.ContainerRequestFilter;

public class FiltroDeAutenticacaoOpenID implements ContainerRequestFilter {
	@Context private UriInfo uriInfo;
	@Context private HttpServletRequest requisicaoServlet;
	@Inject private RepositorioDoAmbiente repositorio;
	
	@Override
	public ContainerRequest filter(ContainerRequest request) {
		request.setSecurityContext(new Autorizador(obterUsuário(request)));
		return request;
	}
	
	private Usuario obterUsuário(ContainerRequest request) {
		if (requisicaoServlet.getSession().getAttribute("openid") == null) {
			return null;
		}
		Identifier identificadorOpenID = (Identifier)requisicaoServlet.getSession().getAttribute("openid");
		return repositorio.obterUsuarioPorIdentificadorDoOpenId(identificadorOpenID.getIdentifier());
	}
	
	private class Autorizador implements SecurityContext {
		
		private Principal principal;
		
		public Autorizador(final Usuario usuário) {
			this.principal = usuário;
		}
		
		@Override
		public Principal getUserPrincipal() {
			return this.principal;
		}
		
		@Override
		public boolean isUserInRole(String papel) {
			return true;
		}
		
		@Override
		public boolean isSecure() {
			return "https".equals(uriInfo.getRequestUri().getScheme());
		}
		
		@Override
		public String getAuthenticationScheme() {
			return SecurityContext.FORM_AUTH;
		}
	}
}
