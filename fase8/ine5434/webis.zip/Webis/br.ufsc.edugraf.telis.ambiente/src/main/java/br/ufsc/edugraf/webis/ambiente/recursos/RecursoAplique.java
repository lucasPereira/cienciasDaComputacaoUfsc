package br.ufsc.edugraf.webis.ambiente.recursos;

import java.io.InputStream;
import java.net.MalformedURLException;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import org.antlr.runtime.RecognitionException;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaAplique;
import br.ufsc.edugraf.webis.compilador.Compilador;

import com.google.inject.Inject;

@Path("/{identificadorDoCouchDoAutor}/aplique/{nome}")
public class RecursoAplique extends Recurso {
	private @PathParam("nome") String nome;
	private @PathParam("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor;
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private RepositorioDoAmbiente repositorio;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoAplique(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
		this.repositorio = repositorio;
	}
	
	@GET
	@Produces(MIDIA_HTML)
	public Response obterHtml() throws MalformedURLException {
		Usuario autorDoAplique = obterAutor(identificadorDoCouchDoAutor, repositorio);
		Aplique aplique = repositorio.obterApliquePorNomeEAutor(nome, autorDoAplique);
		DadosDaPaginaAplique dados = new DadosDaPaginaAplique(informacaoDeUri, usuarioAutenticado, obterAutorDoAplique(aplique), aplique);
		if (usuarioEstaAutenticado()) {
			if (usuarioAutenticadoPodeApropriarSe(aplique)) {
				dados.autorizarCriacao();
			} else if (usuarioAutenticadoPodeSalvar(aplique)) {
				dados.autorizarSalvamento();
			}
		}
		return obterRespostaDePaginaHtml(Arquivos.APLIQUE, dados);
	}
	
	@GET 
	@Path("/webis/modelo.js")
	@Produces(MIDIA_JS)
	public String modelo() throws MalformedURLException, RecognitionException {
		Usuario autorDoAplique = repositorio.obterUsuarioPorIdentificadorDoCouch(identificadorDoCouchDoAutor);
		Aplique aplique = repositorio.obterApliquePorNomeEAutor(nome, autorDoAplique);
		String codigoJavaScript = aplique.obterModelo().compilar();
		return codigoJavaScript;
	}
	
	@GET 
	@Path("/webis/novoAtor.js")
	@Produces(MIDIA_JS)
	public Response ator() {
		InputStream recurso = Compilador.class.getResourceAsStream("novoAtor.js");
		return obterRespostaDeRecurso(recurso, TIPO_DE_MIDIA_JS);
	}
	
	@GET 
	@Path("/{arquivoHtml: .+\\.html}")
	@Produces(MIDIA_HTML)
	public Response aplique(@PathParam("arquivoHtml") String arquivoHtml) {
		InputStream recurso = obterRecurso(contextoDeServlet, arquivoHtml);
		return obterRespostaDeRecurso(recurso, TIPO_DE_MIDIA_HTML);
	}
	
	@GET 
	@Path("/{arquivoJs: .+\\.js}")
	@Produces(MIDIA_JS)
	public Response arquivoJs(@PathParam("arquivoJs") String arquivoJs) {
		InputStream recurso = obterRecurso(contextoDeServlet, arquivoJs);
		return obterRespostaDeRecurso(recurso, TIPO_DE_MIDIA_JS);
	}
	
	private Usuario obterAutorDoAplique(Aplique aplique) {
		return (aplique.obterAutor() != null) ? aplique.obterAutor() : usuarioAutenticado;
	}
	
	private boolean usuarioEstaAutenticado() {
		return (usuarioAutenticado != null);
	}
	
	private boolean usuarioAutenticadoPodeSalvar(Aplique aplique) {
		return usuarioEstaAutenticado() && (aplique.obterAutor() == null || usuarioAutenticado.equals(aplique.obterAutor()));
	}
	
	private boolean usuarioAutenticadoPodeApropriarSe(Aplique aplique) {
		return usuarioEstaAutenticado() && (aplique.obterAutor() != null && !usuarioAutenticado.equals(aplique.obterAutor()));
	}
}
