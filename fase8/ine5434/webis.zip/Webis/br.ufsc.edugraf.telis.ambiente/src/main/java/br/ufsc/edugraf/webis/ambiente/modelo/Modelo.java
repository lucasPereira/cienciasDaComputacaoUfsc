package br.ufsc.edugraf.webis.ambiente.modelo;

import org.antlr.runtime.RecognitionException;
import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonProperty;

import br.ufsc.edugraf.webis.compilador.Compilador;

public class Modelo {
	@JsonProperty("nome") private String nome;
	@JsonProperty("codigoFonte") private String codigoFonte;
	
	@JsonCreator
	public Modelo(@JsonProperty("nome") String nome, @JsonProperty("codigoFonte") String codigoFonte) {
		this.nome = nome;
		this.codigoFonte = codigoFonte;
	}
	
	public Modelo(String nome) {
		this(nome, "");
	}
	
	public String obterNome() {
		return nome;
	}
	
	public String obterCodigoFonte() {
		return codigoFonte;
	}
	
	public void fixarCódigoFonte(String codigo) {
		this.codigoFonte = codigo;
	}
	
	public String compilar() throws RecognitionException {
		Compilador compilador = new Compilador();
		String codigoJavaScript = compilador.compilar(this.codigoFonte);
		return codigoJavaScript;
	}
}
