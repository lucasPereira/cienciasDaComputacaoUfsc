package br.ufsc.edugraf.webis.ambiente.recursos;

import java.net.MalformedURLException;
import java.util.List;

import javax.servlet.ServletContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriBuilder;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.Aplique;
import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaApliques;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaCriacaoDeAplique;

import com.google.inject.Inject;

@Path("{identificadorDoCouchDoAutor}/apliques")
public class RecursoApliques extends Recurso {
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private RepositorioDoAmbiente repositorio;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoApliques(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
		this.repositorio = repositorio;
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response obterHtml(@PathParam("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor) {
		Usuario autor = obterAutor(identificadorDoCouchDoAutor, repositorio);
		List<Aplique> apliques = repositorio.obterApliquesPorAutor(autor);
		DadosDaPaginaApliques dados = new DadosDaPaginaApliques(informacaoDeUri, usuarioAutenticado, apliques, autor);
		return obterRespostaDePaginaHtml(Arquivos.APLIQUES, dados);
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_HTML)
	public Response postarFormulario(@PathParam("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor, @FormParam("codigoFonte") String codigoFonte, @FormParam("nome") String nome) throws MalformedURLException {
		nome = nome.trim();
		final String validacaoDoNomeDoAplique = "(\\p{L}|\\p{Digit}| )+";
		if (nome == null || !nome.matches(validacaoDoNomeDoAplique)) {
			DadosDaPaginaCriacaoDeAplique dados = new DadosDaPaginaCriacaoDeAplique(informacaoDeUri, usuarioAutenticado, nome, codigoFonte);
			return obterRespostaDePaginaHtml(Arquivos.CRIACAO_DE_APLIQUE, Status.BAD_REQUEST, dados);
		}
		Usuario autorDoAplique = repositorio.obterUsuarioPorIdentificadorDoCouch(identificadorDoCouchDoAutor);
		Aplique aplique = repositorio.obterApliquePorNomeEAutor(nome, autorDoAplique);
		obterUsuarioAutenticado(usuarioAutenticado);
		if (!usuarioAutenticadoPodeSalvar(aplique)) {
			return obterRespostaDeProibido();
		}
		aplique.obterModelo().fixarCódigoFonte(codigoFonte);
		aplique.fixarAutor(usuarioAutenticado);
		aplique.atualizarDataDeModificacao();
		repositorio.salvarAplique(aplique);
		return Response.seeOther(UriBuilder.fromResource(RecursoAplique.class).build(identificadorDoCouchDoAutor, nome)).build();
	}
	
	private boolean usuarioAutenticadoPodeSalvar(Aplique aplique) {
		return (aplique.obterAutor() == null || usuarioAutenticado.equals(aplique.obterAutor()));
	}
}
