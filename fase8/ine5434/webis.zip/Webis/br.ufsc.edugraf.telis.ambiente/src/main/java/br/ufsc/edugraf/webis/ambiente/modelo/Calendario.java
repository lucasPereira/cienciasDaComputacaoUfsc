package br.ufsc.edugraf.webis.ambiente.modelo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class Calendario {
	private static final String FORMATO_PADRAO_DA_DATA = "yyyy-MM-dd HH:mm";
	private static final String FORMATO_POR_EXTENSO_DA_DATA = "dd 'de' MMMMM 'de' yyyy 'às' HH:mm";
	private static final String FORMATO_MINIMALISTA_DA_DATA = "'às' HH:mm";
	private static final Locale DATA_LOCAL = new Locale("pt", "BR");
	private Date data;
	
	public Calendario(Date data) {
		this.data = data;
	}
	
	public String obterData() {
		String dataFormatada = "";
		if (data != null) {
			dataFormatada = new SimpleDateFormat(FORMATO_PADRAO_DA_DATA).format(data);
		}
		return dataFormatada;
	}
	
	public String obterDataPorExtenso() {
		Calendar ontem = Calendar.getInstance(DATA_LOCAL);
		ontem.add(Calendar.DATE, -1);
		ontem.set(Calendar.HOUR, 0);
		ontem.set(Calendar.MINUTE, 0);
		ontem.set(Calendar.AM_PM, Calendar.AM);
		Calendar hoje = Calendar.getInstance(DATA_LOCAL);
		hoje.set(Calendar.HOUR, 0);
		hoje.set(Calendar.MINUTE, 0);
		hoje.set(Calendar.AM_PM, Calendar.AM);
		String dataFormatada = "";
		if (data != null) {
			if (data.after(hoje.getTime())) {
				dataFormatada = "Hoje " + new SimpleDateFormat(FORMATO_MINIMALISTA_DA_DATA).format(data);
			} else if (data.after(ontem.getTime())) {
				dataFormatada = "Ontem " + new SimpleDateFormat(FORMATO_MINIMALISTA_DA_DATA).format(data);
			} else {
				dataFormatada = new SimpleDateFormat(FORMATO_POR_EXTENSO_DA_DATA).format(data);
			}
		}
		return dataFormatada;
	}
}
