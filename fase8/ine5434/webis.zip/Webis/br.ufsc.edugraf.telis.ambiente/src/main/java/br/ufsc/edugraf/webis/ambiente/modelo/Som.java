package br.ufsc.edugraf.webis.ambiente.modelo;

import java.io.InputStream;
import java.util.Date;

import org.codehaus.jackson.annotate.JsonCreator;
import org.codehaus.jackson.annotate.JsonIgnore;
import org.codehaus.jackson.annotate.JsonIgnoreProperties;
import org.codehaus.jackson.annotate.JsonProperty;

import br.ufsc.edugraf.webis.ambiente.couch.RepositorioDeSons;

@JsonIgnoreProperties("_attachments")
public class Som {
	@JsonProperty("_id") private String identificadorDoCouch;
	@JsonProperty("_rev") private String revisaoDoCouch;
	@JsonProperty("nome") private String nome;
	@JsonProperty("dataDeCarregamento") private Date dataDeCarregamento;
	@JsonProperty("identificadorDoCouchDoAutor") private String identificadorDoCouchDoAutor;
	@JsonProperty("tipo") public final String tipo = RepositorioDeSons.TIPO;
	@JsonIgnore private InputStream som;
	@JsonIgnore private Usuario autor;
	
	@JsonCreator
	public Som(@JsonProperty("_id") String identificadorDoCouch, @JsonProperty("_rev") String revisaoDoCouch, @JsonProperty("nome") String nome, @JsonProperty("dataDeCarregamento") Date dataDeCarregamento, @JsonProperty("identificadorDoCouchDoAutor") String identificadorDoCouchDoAutor) {
		this.identificadorDoCouch = identificadorDoCouch;
		this.revisaoDoCouch = revisaoDoCouch;
		this.nome = nome;
		this.dataDeCarregamento = dataDeCarregamento;
		this.identificadorDoCouchDoAutor = identificadorDoCouchDoAutor;
	}
	
	public Som(String identificadorDoCouchDoAutor, String nome, InputStream som) {
		this.identificadorDoCouchDoAutor = identificadorDoCouchDoAutor;
		this.nome = nome;
		this.dataDeCarregamento = new Date();
		this.som = som;
	}
	
	public String obterIdentificadorDoCouch() {
		return identificadorDoCouch;
	}
	
	public String obterRevisaoDoCouch() {
		return revisaoDoCouch;
	}
	
	public String obterNome() {
		return nome;
	}
	
	public String obterDataDeCarregamento() {
		return new Calendario(dataDeCarregamento).obterData();
	}
	
	public String obterDataDeCarregamentoPorExtenso() {
		return new Calendario(dataDeCarregamento).obterDataPorExtenso();
	}
	
	public String obterIdentificadorDoCouchDoAutor() {
		return identificadorDoCouchDoAutor;
	}
	
	public Usuario obterAutor() {
		return this.autor;
	}

	public InputStream obterSom() {
		return som;
	}
	
	public void fixarAutor(Usuario autor) {
		this.autor = autor;
	}
	
	public void fixarSom(InputStream som) {
		this.som = som;
	}
}
