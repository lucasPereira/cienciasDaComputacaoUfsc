package br.ufsc.edugraf.webis.ambiente.recursos;

import java.io.InputStream;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;

import com.google.inject.Inject;
import com.sun.jersey.api.client.Client;

@Path("/som/")
public class RecursoSomExterno extends Recurso {
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	
	@Inject
	public RecursoSomExterno(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		
	}
	
	@GET
	@Produces(MIDIA_AUDIO)
	public Response obterAudio(@QueryParam("endereco") String endereco) {
 		Client cliente = Client.create();
		InputStream som = null;
		try {
			som = cliente.resource(endereco).get(InputStream.class);
		} catch (Exception excecao) {
			return obterRespostaDeNaoEncontrado();
		}
		return obterRespostaDeSom(som, TIPO_DE_MIDIA_AUDIO);
	}
}
