package br.ufsc.edugraf.webis.ambiente.recursos;

import javax.servlet.ServletContext;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.core.UriInfo;

import br.ufsc.edugraf.webis.ambiente.modelo.RepositorioDoAmbiente;
import br.ufsc.edugraf.webis.ambiente.modelo.Usuario;
import br.ufsc.edugraf.webis.ambiente.recursos.dadosParaInterfaceGrafica.DadosDaPaginaCriacaoDeAplique;

import com.google.inject.Inject;

@Path("/criacaoDeAplique")
public class RecursoCriacaoDeAplique extends Recurso {
	private @Context ServletContext contextoDeServlet;
	private @Context UriInfo informacaoDeUri;
	private Usuario usuarioAutenticado;
	
	@Inject
	public RecursoCriacaoDeAplique(@Context SecurityContext contextoDeSeguranca, RepositorioDoAmbiente repositorio) {
		this.usuarioAutenticado = (Usuario) contextoDeSeguranca.getUserPrincipal();
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public Response obterHtml() {
		obterUsuarioAutenticado(usuarioAutenticado);
		DadosDaPaginaCriacaoDeAplique dados = new DadosDaPaginaCriacaoDeAplique(informacaoDeUri, usuarioAutenticado);
		return obterRespostaDePaginaHtml(Arquivos.CRIACAO_DE_APLIQUE, dados);
	}
}
