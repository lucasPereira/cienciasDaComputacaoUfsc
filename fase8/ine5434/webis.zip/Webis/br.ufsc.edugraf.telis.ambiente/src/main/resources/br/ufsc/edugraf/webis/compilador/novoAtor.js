importScripts('mootools.js');
importScripts('checagem.js');
importScripts('webis.js');
importScripts('geral.js');
importScripts('pilhaDeExecucao.js');
importScripts('agenda.js');
importScripts('ator.js');
importScripts('controleDeFluxo.js');
importScripts('estimulos.js');
importScripts('grafico.js');
importScripts('lista.js');
importScripts('operadores.js');
importScripts('pilha.js');
importScripts('posicionamento.js');
importScripts('som.js');
importScripts('trigonometria.js');
importScripts('utilitarios.js');

var TabelaDeComandosInternos = {
		"INICIAR_ATOR": function (dados) {
			var agendas = dados.agendas;
			var parametros = dados.parametros;
			var identificadorDoAtor = dados.identificadorDoAtor;
			var contexto = new Contexto();
			if (parametros !== undefined) {
				Util.normalizarComandos([parametros]);
				contexto.pilha.push(parametros);
			}
			Webis.inicializar(contexto, agendas, undefined, identificadorDoAtor);
		},
		
		"RECEBER_ESTIMULO": function (dados) {
			var listaDita = dados.listaDita;
			Webis.receberEstimulo(listaDita);
		}
};

function receberMensagemDoEcossistema(mensagem) {
	var dados = mensagem.data;
	var comando = dados.comando;
	if (TabelaDeComandosInternos[comando] !== undefined) {
		TabelaDeComandosInternos[comando](dados);
	}
}

self.addEventListener("message", receberMensagemDoEcossistema);
