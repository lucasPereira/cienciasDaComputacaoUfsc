/*global Ator*/
/*global Checagem*/
/*global Class*/
/*global Simbolo*/
/*global TabelaDeSimbolos*/
/*global Webis*/

(function (global) {
	"use strict";

	var Novo = new Class({
		initialize: function (nome, posicaoNoCodigo) {
			this.tipo = "Novo";
			this.nome = nome;
			this.posicaoNoCodigo = posicaoNoCodigo;
		},

		executar: function (contexto) {
			Webis.posicaoDoSimboloExecutado = this.posicaoNoCodigo;
			contexto.pilha.push(this.nome);
			TabelaDeSimbolos.novo(contexto);
		},

		comoTexto: function () {
			return String.formatar("%@ novo", this.nome);
		},

		comoTextoWebis: function () {
			return String.formatar("%@ novo", this.nome);
		}
	});

	Novo.extend({
		tipo: "Novo"
	});

	Object.merge(TabelaDeSimbolos, {
		"incluirModelo": function (contexto) {
			var modelo = contexto.pilha.tirar();
			var nomeDoModelo = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([nomeDoModelo, modelo], [String, Array]).checar();
			var agendas = {};
			var indice;
			for (indice = 0; indice < modelo.length; indice += 3) {
				var nomeDaAgenda = modelo[indice];
				var agenda = modelo[indice + 1];
				var incluirAgenda = modelo[indice + 2];
				Checagem.deTipos([nomeDaAgenda, agenda, incluirAgenda], [String, Array, Simbolo], Checagem.obterMensagemDeDefinicaoDeModeloInvalida()).checar();
				Checagem.deValor(incluirAgenda.nome, "incluirAgenda", Checagem.obterMensagemDeDefinicaoDeModeloInvalida()).checar();
				agendas[nomeDaAgenda] = agenda;
			}
			global.postMessage({comando: "INCLUIR_MODELO", nomeDoModelo: nomeDoModelo, agendas: agendas});
		},

		"novo": function (contexto) {
			var nomeDoModelo = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(nomeDoModelo, Simbolo).ou(nomeDoModelo, String).checar();
			var parametros = [];
			if (contexto.pilha.length > 0) {
				parametros = contexto.pilha[contexto.pilha.length - 1];
			}
			nomeDoModelo = (global.instanceOf(nomeDoModelo, Simbolo)) ? nomeDoModelo.nome : nomeDoModelo.valueOf();
			global.postMessage({comando: "NOVO", nomeDoModelo: nomeDoModelo, parametros: parametros, posicaoNoCodigo: Webis.posicaoDoSimboloExecutado});
		},

		"nova": function (contexto) {
			TabelaDeSimbolos.novo(contexto);
		},

		"suicidar": function () {
			global.postMessage({comando: "SUICIDAR", identificadorDoAtor: Ator.identificador});
			Webis.pilhaDeExecucao.encerrar();
		}
	});

	global.Novo = Novo;
}(this));
