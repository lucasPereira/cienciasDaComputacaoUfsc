/*global Checagem*/
/*global TabelaDeSimbolos*/

(function () {
	"use strict";

	function reduzirGraus(graus) {
		graus = graus % 360;
		return (graus < 0) ? graus + 360 : graus;
	}

	function paraGraus(radianos) {
		var anguloEmGraus = (radianos * 180 / Math.PI);
		return reduzirGraus(anguloEmGraus);
	}

	function paraRadianos(graus) {
		graus = reduzirGraus(graus);
		return (graus * Math.PI / 180);
	}

	Object.merge(TabelaDeSimbolos, {
		"arcoTangente": function (contexto) {
			var tangenteDoAngulo = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(tangenteDoAngulo, Number).checar();
			contexto.pilha.push(paraGraus(Math.atan(tangenteDoAngulo)));
		},

		"cosseno": function (contexto) {
			var angulo = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(angulo, Number).checar();
			contexto.pilha.push(Math.cos(paraRadianos(angulo)));
		},

		"seno": function (contexto) {
			var angulo = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(angulo, Number).checar();
			contexto.pilha.push(Math.sin(paraRadianos(angulo)));
		}
	});
}());
