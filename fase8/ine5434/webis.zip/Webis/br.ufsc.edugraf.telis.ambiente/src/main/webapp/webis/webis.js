/*global Agenda*/
/*global Checagem*/
/*global Class*/
/*global Contexto*/
/*global ContextoDeLacoDeRepeticao*/
/*global ContextoDeParaCada*/
/*global Novo*/
/*global PilhaDeExecucao*/
/*global TratadorDeEstimulo*/
/*global Util*/

(function (global) {
	"use strict";

	var TabelaDeAgendas = {};

	var TabelaDeTratadores = [];

	var TabelaDeSimbolos = {};

	var AtividadeInterna = new Class({
		initialize: function (atividade) {
			this.atividade = atividade;
		},

		executar: function (contexto) {
			this.atividade(contexto);
		}
	});

	var Ator = {
		inicializar: function (contexto, identificador) {
			this.contextoGlobal = contexto;
			this.identificador = identificador;
			this.posicao = {x: 0, y: 0, z: 0};
			this.direcao = {x: 0, y: 1, z: 0};
			this.velocidade = {x: 0, y: 0, z: 0};
			this.rotacao = 90;
			this.tamanhoDoPasso = 10;
			this.comSom = false;
			this.visivel = false;
		}
	};

	var Webis = {
		inicializar: function (contexto, agendas, funcaoDeRetorno, identificadorDoAtor) {
			Ator.inicializar(contexto, identificadorDoAtor);
			this.pilhaDeExecucao = new PilhaDeExecucao(funcaoDeRetorno);
			this.executandoInterrupcao = false;
			this.posicaoDoSimboloExecutado = {linha: 0, coluna: 0};
			this.inicializarAgendas(agendas);
			this.pilhaDeExecucao.adicionarBloco(contexto, TabelaDeAgendas.iniciar.comandos);
			this.pilhaDeExecucao.iniciar();
			global.addEventListener("error", this.receberErro.bind(this));
		},

		receberEstimulo: function (listaDita, funcaoDeRetorno) {
			if (!this.executandoInterrupcao) {
				var pilhaDeExecucaoSalva = this.pilhaDeExecucao;
				this.pilhaDeExecucao.interromper();
				this.pilhaDeExecucao = new PilhaDeExecucao(funcaoDeRetorno);
				this.pilhaDeExecucao.adicionarAtividadeInterna(Ator.contextoGlobal, new AtividadeInterna(function () {
					this.pilhaDeExecucao = pilhaDeExecucaoSalva;
					this.pilhaDeExecucao.retomar();
				}.bind(this)));
				this.adicionarTratadoresQueCasam(listaDita);
				this.pilhaDeExecucao.iniciar();
			} else if (global.typeOf(funcaoDeRetorno) === "function") {
				funcaoDeRetorno();
			}
		},

		adicionarTratadoresQueCasam: function (listaDita) {
			Util.normalizarComandos(listaDita);
			TabelaDeTratadores.each(function (tratador, indice) {
				if (listaDita.casaCom(tratador.filtro)) {
					var contextoDoTratador = Ator.contextoGlobal.criarContextoFilhoDeSeDito(listaDita);
					this.pilhaDeExecucao.adicionarBloco(contextoDoTratador, tratador.comandos);
				}
			}, this);
		},

		inicializarAgendas: function (agendas) {
			if (global.instanceOf(agendas, Array)) {
				agendas = {iniciar: agendas};
			}
			Object.each(agendas, function (agenda, chave) {
				Util.normalizarComandos(agenda);
				TabelaDeAgendas[chave] = new Agenda(agenda);
			}, this);
		},

		depurar: function (escopo, excecao) {
			var tipo = excecao.name;
			var mensagem = excecao.message;
			var arquivo = excecao.filename;
			var linha = excecao.lineno;
			global.postMessage({comando: "DEPURAR", escopo: escopo, tipo: tipo, mensagem: mensagem, arquivo: arquivo, linha: linha});
		},

		receberErro: function (evento) {
			this.depurar("Webis", evento);
		}
	};

	var ExcecaoWebis = new Class({
		tipo: "ExceçãoWebis",

		initialize: function (mensagem) {
			this.mensagem = mensagem;
		},

		comoTexto: function () {
			return this.mensagem;
		},

		comoTextoWebis: function () {
			return this.mensagem;
		}
	});

	ExcecaoWebis.extend({
		tipo: "ExceçãoWebis"
	});

	var ErroSintatico = new Class({
		initialize: function (simboloRecebido, simboloEsperado, posicaoNoCodigo) {
			this.tipo = "ErroSintático";
			this.simboloRecebido = simboloRecebido;
			this.simboloEsperado = simboloEsperado;
			this.posicaoNoCodigo = posicaoNoCodigo;
		},

		executar: function (contexto) {
			Webis.posicaoDoSimboloExecutado = this.posicaoNoCodigo;
			throw new ExcecaoWebis(Checagem.obterMensagemDeErroSintatico(this.simboloEsperado, this.simboloRecebido));
		}
	});

	ErroSintatico.extend({
		tipo: "ErroSintatico"
	});

	var ErroLexico = new Class({
		initialize: function (simboloRecebido, posicaoNoCodigo) {
			this.tipo = "ErroLexico";
			this.simboloRecebido = simboloRecebido;
			this.posicaoNoCodigo = posicaoNoCodigo;
		},

		executar: function (contexto) {
			Webis.posicaoDoSimboloExecutado = this.posicaoNoCodigo;
			throw new ExcecaoWebis(Checagem.obterMensagemDeErroLexico(this.simboloRecebido));
		}
	});

	ErroLexico.extend({
		tipo: "ErroLexico"
	});

	var Palavra = new Class({
		initialize: function () {
			this.tipo = "Palavra";
		}
	});

	Palavra.extend({
		tipo: "Palavra"
	});

	var Simbolo = new Class({
		initialize: function (nome, posicaoNoCodigo) {
			this.tipo = "Símbolo";
			this.nome = nome;
			this.posicaoNoCodigo = posicaoNoCodigo;
		},

		comoTexto: function () {
			return this.nome;
		},

		comoTextoWebis: function () {
			return this.nome;
		},

		executar: function (contexto) {
			Webis.posicaoDoSimboloExecutado = this.posicaoNoCodigo;
			var simboloAssociado;
			if (TabelaDeSimbolos[this.nome] !== undefined) {
				TabelaDeSimbolos[this.nome](contexto);
			} else if (TabelaDeAgendas[this.nome] !== undefined) {
				TabelaDeAgendas[this.nome].executar(contexto);
			} else if ((simboloAssociado = contexto.escopo.ler(this.nome)) !== undefined) {
				contexto.pilha.push(simboloAssociado);
			} else {
				throw new ExcecaoWebis(Checagem.obterMensagemDePalavraNaoEncontrada(this.nome));
			}
		},

		avaliar: function (contexto) {
			Webis.posicaoDoSimboloExecutado = this.posicaoNoCodigo;
			throw new ExcecaoWebis(Checagem.obterMensagemDeAvaliacaoInvalida());
		}
	});

	Simbolo.extend({
		tipo: "Símbolo"
	});

	var PacoteDeSimbolo = new Class({
		initialize: function (simbolo) {
			this.tipo = "PacoteDeSímbolo";
			this.simbolo = simbolo;
		},

		comoTexto: function () {
			return String.formatar("[%@] soletrar", this.simbolo);
		},

		comoTextoWebis: function () {
			return String.formatar("[%@] soletrar", this.simbolo);
		},

		executar: function (contexto) {
			contexto.pilha.push(new Simbolo(this.simbolo));
		}
	});

	PacoteDeSimbolo.extend({
		tipo: "PacoteDeSímbolo"
	});

	var Associar = new Class({
		initialize: function (nome, posicaoNoCodigo) {
			this.tipo = "Associar";
			this.nome = nome;
			this.posicaoNoCodigo = posicaoNoCodigo;
		},

		executar: function (contexto) {
			Webis.posicaoDoSimboloExecutado = this.posicaoNoCodigo;
			contexto.pilha.push(this.nome);
			TabelaDeSimbolos.associar(contexto);
		},

		comoTexto: function () {
			return String.formatar("%@ associar", this.nome);
		},

		comoTextoWebis: function () {
			return String.formatar("%@ associar", this.nome);
		}
	});

	Associar.extend({
		tipo: "Associar"
	});

	Function.implement({
		comoTexto: function () {
			return (this.tipo || this.name);
		},

		comoTextoWebis: function () {
			return (this.tipo || this.name);
		}
	});

	Array.extend({
		tipo: "Lista"
	});

	Array.implement({
		tipo: "Lista",

		comoTexto: function () {
			return String.formatar("[%@]", this.juntar(" "));
		},

		comoTextoWebis: function () {
			return String.formatar("[%@]", this.juntarWebis(" "));
		},

		juntar: function (separador) {
			var texto = "";
			var indice;
			for (indice = 0; indice < this.length; indice++) {
				var valor = this[indice];
				var valorTextual = Util.obterRepresentacaoTextual(valor);
				texto += valorTextual;
				if ((indice + 1) < this.length) {
					texto += separador;
				}
			}
			return texto;
		},

		juntarWebis: function (separador) {
			var texto = "";
			var indice;
			for (indice = 0; indice < this.length; indice++) {
				var valor = this[indice];
				var valorTextual = Util.obterRepresentacaoTextualWebis(valor);
				texto += valorTextual;
				if ((indice + 1) < this.length) {
					texto += separador;
				}
			}
			return texto;
		},

		executar: function (contexto) {
			contexto.pilha.push(this.valueOf());
		},

		avaliar: function (contexto) {
			var contextoDeCondicao = contexto.criarContextoFilhoDeCondicao();
			var atividadeInterna = new AtividadeInterna(function () {
				var avaliacao = contextoDeCondicao.pilha.tirar();
				Checagem.deTipo(avaliacao, Number, Checagem.obterMensagemDeAvaliacaoInvalida()).ou(avaliacao, Boolean).checar();
				avaliacao.avaliar(contexto);
			});
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoDeCondicao, atividadeInterna);
			Webis.pilhaDeExecucao.adicionarBloco(contextoDeCondicao, this);
		},

		tirar: function (contexto) {
			if (this.length === 0) {
				throw new ExcecaoWebis(Checagem.obterMensagemDeParametrosInsuficientes());
			}
			return this.pop();
		}
	});

	String.extend({
		tipo: "Texto",

		formatar: function (texto) {
			var indice;
			for (indice = 1; indice < arguments.length; indice += 1) {
				texto = texto.replace(/%@/, arguments[indice]);
			}
			return texto;
		}
	});

	String.implement({
		tipo: "Texto",

		comoTexto: function () {
			return this.toString();
		},

		comoTextoWebis: function () {
			return String.formatar("\"%@\"", this.toString());
		},

		executar: function (contexto) {
			contexto.pilha.push(this.valueOf());
		},

		avaliar: function (contexto) {
			throw new ExcecaoWebis(Checagem.obterMensagemDeAvaliacaoInvalida());
		}
	});

	Number.extend({
		tipo: "Número"
	});

	Number.implement({
		tipo: "Número",

		comoTexto: function () {
			return this.toString();
		},

		comoTextoWebis: function () {
			var texto = this.toString();
			return texto.replace(/\./, ",");
		},

		executar: function (contexto) {
			contexto.pilha.push(this.valueOf());
		},

		avaliar: function (contexto) {
			contexto.pilha.push((this.valueOf() > 0) ? true : false);
		}
	});

	Boolean.extend({
		tipo: "Booleano"
	});

	Boolean.implement({
		tipo: "Booleano",

		comoTexto: function () {
			return (this.valueOf() ? "verdadeiro" : "falso");
		},

		comoTextoWebis: function () {
			return (this.valueOf() ? "verdadeiro" : "falso");
		},

		executar: function (contexto) {
			contexto.pilha.push(this.valueOf());
		},

		avaliar: function (contexto) {
			contexto.pilha.push(this.valueOf());
		}
	});

	var Escopo = new Class({
		tabelaDeSimbolos: {},

		initialize: function (escopoPai) {
			this.escopoPai = escopoPai;
		},

		declarar: function (nome, valor) {
			this.tabelaDeSimbolos[nome] = valor;
		},

		escrever: function (nome, valor) {
			var existeLocalmente = this.tabelaDeSimbolos[nome] !== undefined;
			var existeNosPredecessores = this.ler(nome) !== undefined;
			if (!existeLocalmente && existeNosPredecessores) {
				this.escopoPai.escrever(nome, valor);
			} else {
				this.tabelaDeSimbolos[nome] = valor;
			}
		},

		ler: function (nome) {
			var valor = this.tabelaDeSimbolos[nome];
			if (valor === undefined && this.escopoPai !== undefined) {
				valor = this.escopoPai.ler(nome);
			}
			return valor;
		},

		criarEscopoFilho: function () {
			return new Escopo(this);
		}
	});

	var Contexto = new Class({
		initialize: function () {
			this.pilha = [];
			this.escopo = new Escopo();
		},

		criarContextoFilhoDeLacoDeRepeticao: function () {
			return new ContextoDeLacoDeRepeticao(this.pilha, this.escopo);
		},

		criarContextoFilhoDeAgenda: function () {
			var contextoDaAgenda = new Contexto();
			contextoDaAgenda.escopo = this.escopo;
			return contextoDaAgenda;
		},

		criarContextoFilhoDeSeDito: function (listaDita) {
			var contextoDeSeDito = new Contexto();
			contextoDeSeDito.escopo = this.escopo;
			contextoDeSeDito.pilha = listaDita.clone();
			return contextoDeSeDito;
		},

		criarContextoFilhoDeCondicao: function () {
			var contextoDeCondicao = new ContextoDeLacoDeRepeticao([], this.escopo);
			contextoDeCondicao.giroAtual = this.giroAtual;
			return contextoDeCondicao;
		}
	});

	var ContextoDeLacoDeRepeticao = new Class({
		Extends: Contexto,

		initialize: function (pilha, escopo) {
			this.pilha = pilha;
			this.escopo = escopo;
			this.giroAtual = 1;
		},

		contarGiro: function () {
			this.giroAtual += 1;
		},

		fornecerGiro: function () {
			return this.giroAtual;
		},

		criarContextoFilhoDeParaCada: function (elemento) {
			return new ContextoDeParaCada(this, this.escopo, elemento);
		}
	});

	var ContextoDeParaCada =  new Class({
		Extends: ContextoDeLacoDeRepeticao,

		initialize: function (pai, escopo, elemento) {
			this.pilha = [elemento];
			this.pai = pai;
			this.escopo = escopo;
		},

		fornecerGiro: function () {
			return this.pai.fornecerGiro();
		}
	});


	var Util = {
		normalizarComandos: function (comandos) {
			if (global.typeOf(comandos) === "array") {
				comandos.each(function (palavra, indice) {
					this.normalizarComando(comandos, palavra, indice);
				}, this);
			} else if (global.typeOf(comandos) === "object") {
				Object.each(comandos, function (palavra, chave) {
					this.normalizarComando(comandos, palavra, chave);
				}, this);
			}
		},

		normalizarComando: function (comandos, palavra, chave) {
			if (palavra !== null && palavra !== undefined) {
				var tipo = palavra.tipo;
				if (global.instanceOf(palavra, Array)) {
					this.normalizarComandos(palavra);
				} else if (tipo === Simbolo.tipo) {
					comandos[chave] = new Simbolo(palavra.nome, palavra.posicaoNoCodigo);
				} else if (tipo === PacoteDeSimbolo.tipo) {
					comandos[chave] = new PacoteDeSimbolo(palavra.simbolo);
				} else if (tipo === Associar.tipo) {
					comandos[chave] = new Associar(palavra.nome, palavra.posicaoNoCodigo);
				} else if (tipo === Novo.tipo) {
					comandos[chave] = new Novo(palavra.nome, palavra.posicaoNoCodigo);
				} else if (tipo === Agenda.tipo) {
					comandos[chave] = new Agenda(this.normalizarComandos(palavra.comandos));
				} else if (tipo === TratadorDeEstimulo.tipo) {
					comandos[chave] = new TratadorDeEstimulo(this.normalizarComandos(palavra.filtro), this.normalizarComandos(palavra.comandos));
				} else if (tipo === ExcecaoWebis.tipo) {
					comandos[chave] = new ExcecaoWebis(palavra.mensagem);
				} else if (tipo === ErroSintatico.tipo) {
					comandos[chave] = new ErroSintatico(palavra.simboloRecebido, palavra.simboloEsperado, palavra.posicaoNoCodigo);
				} else if (tipo === ErroLexico.tipo) {
					comandos[chave] = new ErroLexico(palavra.simboloRecebido, palavra.posicaoNoCodigo);
				} else {
					this.normalizarComandos(palavra);
				}
			}
		},

		obterRepresentacaoTextual: function (objeto) {
			if (objeto === null) {
				return "nulo";
			} else if (objeto === undefined) {
				return "indefinido";
			} else if (objeto === Infinity) {
				return "+Infinito";
			} else if (objeto === -Infinity) {
				return "-Infinito";
			} else if (objeto !== objeto) {
				return "Inderteminado";
			} else if (global.typeOf(objeto.comoTexto) === "function") {
				return objeto.comoTexto();
			} else {
				var texto = "{";
				var indiceDaPropriedade = 0;
				var indiceDaUltimaPropriedade = (Object.getOwnPropertyNames(objeto).length - 1);
				Object.each(objeto, function (valor, chave) {
					texto += (chave + ": ");
					texto += this.obterRepresentacaoTextual(valor);
					if (indiceDaPropriedade < indiceDaUltimaPropriedade) {
						texto += ", ";
					}
					indiceDaPropriedade++;
				}, this);
				return texto + "}";
			}
		},

		obterRepresentacaoTextualWebis: function (objeto) {
			if (objeto === null) {
				return "nulo";
			} else if (objeto === undefined) {
				return "indefinido";
			} else if (objeto === Infinity) {
				return "+Infinito";
			} else if (objeto === -Infinity) {
				return "-Infinito";
			} else if (objeto !== objeto) {
				return "Inderteminado";
			} else if (global.typeOf(objeto.comoTextoWebis) === "function") {
				return objeto.comoTextoWebis();
			} else {
				var texto = "{";
				var indiceDaPropriedade = 0;
				var indiceDaUltimaPropriedade = (Object.getOwnPropertyNames(objeto).length - 1);
				Object.each(objeto, function (valor, chave) {
					texto += (chave + ": ");
					texto += this.obterRepresentacaoTextualWebis(valor);
					if (indiceDaPropriedade < indiceDaUltimaPropriedade) {
						texto += ", ";
					}
					indiceDaPropriedade++;
				}, this);
				return texto + "}";
			}
		}
	};

	global.TabelaDeAgendas = TabelaDeAgendas;
	global.TabelaDeTratadores = TabelaDeTratadores;
	global.TabelaDeSimbolos = TabelaDeSimbolos;
	global.ExcecaoWebis = ExcecaoWebis;
	global.ErroSintatico = ErroSintatico;
	global.ErroLexico = ErroLexico;
	global.Palavra = Palavra;
	global.Simbolo = Simbolo;
	global.PacoteDeSimbolo = PacoteDeSimbolo;
	global.Associar = Associar;
	global.Contexto = Contexto;
	global.ContextoDeLacoDeRepeticao = ContextoDeLacoDeRepeticao;
	global.Escopo = Escopo;
	global.AtividadeInterna = AtividadeInterna;
	global.Ator = Ator;
	global.Webis = Webis;
	global.Util = Util;
}(this));
