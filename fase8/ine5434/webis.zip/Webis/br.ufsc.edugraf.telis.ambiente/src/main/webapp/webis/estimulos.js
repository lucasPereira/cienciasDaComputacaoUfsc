/*global Checagem*/
/*global Class*/
/*global TabelaDeSimbolos*/
/*global TabelaDeTratadores*/
/*global Util*/

(function (global) {
	"use strict";

	var TratadorDeEstimulo = new Class({
		initialize: function (filtro, comandos) {
			this.tipo = "TratadorDeEstímulo";
			this.filtro = filtro;
			this.comandos = comandos;
		},

		comoTexto: function () {
			return String.formatar("{filtro: %@, tratador: %@}", Util.obterRepresentacaoTextual(this.filtro), Util.obterRepresentacaoTextual(this.comandos));
		},

		comoTextoWebis: function () {
			return String.formatar("{filtro: %@, tratador: %@}", Util.obterRepresentacaoTextualWebis(this.filtro), Util.obterRepresentacaoTextualWebis(this.comandos));
		}
	});

	TratadorDeEstimulo.extend({
		tipo: "TratadorDeEstímulo"
	});

	Object.merge(TabelaDeSimbolos, {
		"dizer": function (contexto) {
			var listaDita = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(listaDita, Array).checar();
			global.postMessage({comando: "DIZER", listaDita: listaDita});
		},

		"seDito": function (contexto) {
			var comandos = contexto.pilha.tirar();
			var filtro = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([filtro, comandos], [Array, Array]).checar();
			TabelaDeTratadores.unshift(new TratadorDeEstimulo(filtro, comandos));
		}
	});

	global.TratadorDeEstimulo = TratadorDeEstimulo;
}(this));
