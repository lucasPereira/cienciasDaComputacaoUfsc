/*global Checagem*/
/*global Palavra*/
/*global Simbolo*/
/*global TabelaDeSimbolos*/
/*global Util*/

(function (global) {
	"use strict";

	Object.merge(TabelaDeSimbolos, {
		"associar": function (contexto) {
			var variavel = contexto.pilha.tirar();
			var valor = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([valor, variavel], [Palavra, Simbolo]).ou([valor, variavel], [Palavra, String]).ou([valor, variavel], [Array, Simbolo]).ou([valor, variavel], [Array, Array]).ou([valor, variavel], [Array, String]).checar();
			var nomeDaVariavel = (global.instanceOf(variavel, Simbolo)) ? variavel.nome : variavel;
			if (global.instanceOf(variavel, Simbolo) || global.instanceOf(variavel, String)) {
				contexto.escopo.escrever(variavel.comoTexto(), valor);
			} else if (global.instanceOf(variavel, Array)) {
				Checagem.deValor(valor.length, variavel.length, Checagem.obterMensagemDeEstruturaDeListaParaAssociarInvalida()).checar();
				variavel.map(function (variavelAtual, indice) {
					var valorAtual = valor[indice];
					Checagem.deTiposDeParametros([valorAtual, variavelAtual], [Palavra, Simbolo]).ou([valorAtual, variavelAtual], [Palavra, String]).ou([valorAtual, variavelAtual], [Array, Simbolo]).ou([valorAtual, variavelAtual], [Array, Array]).ou([valorAtual, variavelAtual], [Array, String]).checar();
					contexto.escopo.escrever(variavelAtual.comoTexto(), valorAtual);
				});
			}
		},

		"avaliar": function (contexto) {
			contexto.pilha.tirar().avaliar(contexto);
		},

		"mostrar": function (contexto) {
			var valor = contexto.pilha.tirar();
			global.postMessage({comando: "MOSTRAR", mensagem: Util.obterRepresentacaoTextual(valor)});
		}
	});
}(this));
