/*global Checagem*/
/*global Simbolo*/
/*global Palavra*/
/*global TabelaDeSimbolos*/
/*global Util*/

(function (global) {
	"use strict";

	function somar(a, b) {
		Checagem.deTiposDeParametros([a, b], [Simbolo, Array]).ou([a, b], [Simbolo, String]).ou([a, b], [Array, Palavra]).ou([a, b], [Array, Array]).ou([a, b], [String, Palavra]).ou([a, b], [String, Array]).ou([a, b], [Number, Array]).ou([a, b], [Number, String]).ou([a, b], [Number, Number]).ou([a, b], [Number, Boolean]).ou([a, b], [Boolean, Array]).ou([a, b], [Boolean, String]).ou([a, b], [Boolean, Number]).ou([a, b], [Boolean, Boolean]).checar();
		return a.somar(b);
	}

	function multiplicar(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [Array, Number]).ou([a, b], [Array, Boolean]).ou([a, b], [Number, Array]).ou([a, b], [Number, Number]).ou([a, b], [Number, Boolean]).ou([a, b], [Boolean, Array]).ou([a, b], [Boolean, Number]).ou([a, b], [Boolean, Boolean]).checar();
		return a.multiplicar(b);
	}

	function subtrair(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [Array, Number]).ou([a, b], [Number, Array]).ou([a, b], [Number, Number]).checar();
		return a.subtrair(b);
	}

	function dividir(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [Array, Number]).ou([a, b], [Number, Array]).ou([a, b], [Number, Number]).checar();
		return a.dividir(b);
	}

	function restoDaDivisao(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [Array, Number]).ou([a, b], [Number, Array]).ou([a, b], [Number, Number]).checar();
		return a.restoDaDivisao(b);
	}

	function elevar(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [Array, Number]).ou([a, b], [Number, Array]).ou([a, b], [Number, Number]).checar();
		return a.elevar(b);
	}

	function maiorQue(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [String, String]).ou([a, b], [Number, Number]).ou([a, b], [Number, Boolean]).ou([a, b], [Boolean, Number]).ou([a, b], [Boolean, Boolean]).checar();
		return a.maiorQue(b);
	}

	function menorQue(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [String, String]).ou([a, b], [Number, Number]).ou([a, b], [Number, Boolean]).ou([a, b], [Boolean, Number]).ou([a, b], [Boolean, Boolean]).checar();
		return a.menorQue(b);
	}

	function maiorOuIgual(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [String, String]).ou([a, b], [Number, Number]).ou([a, b], [Number, Boolean]).ou([a, b], [Boolean, Number]).ou([a, b], [Boolean, Boolean]).checar();
		return a.maiorOuIgual(b);
	}

	function menorOuIgual(a, b) {
		Checagem.deTiposDeParametros([a, b], [Array, Array]).ou([a, b], [String, String]).ou([a, b], [Number, Number]).ou([a, b], [Number, Boolean]).ou([a, b], [Boolean, Number]).ou([a, b], [Boolean, Boolean]).checar();
		return a.menorOuIgual(b);
	}

	Object.merge(TabelaDeSimbolos, {
		"+": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(somar(a, b));
		},

		"*": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(multiplicar(a, b));
		},

		"-": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(subtrair(a, b));
		},

		"/": function (contexto) {
			var divisor = contexto.pilha.tirar();
			var dividendo = contexto.pilha.tirar();
			contexto.pilha.push(dividir(dividendo, divisor));
		},

		"\\": function (contexto) {
			var divisor = contexto.pilha.tirar();
			var dividendo = contexto.pilha.tirar();
			contexto.pilha.push(restoDaDivisao(dividendo, divisor));
		},

		"^": function (contexto) {
			var expoente = contexto.pilha.tirar();
			var base = contexto.pilha.tirar();
			contexto.pilha.push(elevar(base, expoente));
		},

		"=": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(a.eIgual(b));
		},

		"diferenteDe": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(!a.eIgual(b));
		},

		"maiorQue": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(maiorQue(a, b));
		},

		"maiorOuIgual": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(maiorOuIgual(a, b));
		},

		"menorQue": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(menorQue(a, b));
		},

		"menorOuIgual": function (contexto) {
			var b = contexto.pilha.tirar();
			var a = contexto.pilha.tirar();
			contexto.pilha.push(menorOuIgual(a, b));
		}
	});

	Simbolo.implement({
		somar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				var lista = Array.clone(outro);
				lista.unshift(this);
				return lista;
			} else if (global.instanceOf(outro, String)) {
				return (Util.obterRepresentacaoTextual(this) + outro);
			}
		},

		eIgual: function (outro) {
			if (global.instanceOf(outro, Simbolo)) {
				return (this.nome === outro.nome);
			}
			return false;
		}
	});

	Array.implement({
		somar: function (outro) {
			if (global.instanceOf(outro, String) || global.instanceOf(outro, Simbolo)) {
				var lista = Array.clone(this);
				lista.push(outro);
				return lista;
			} else {
				return this.operar(outro, somar);
			}
		},

		multiplicar: function (outro) {
			return this.operar(outro, multiplicar);
		},

		subtrair: function (outro) {
			return this.operar(outro, subtrair);
		},

		dividir: function (outro) {
			return this.operar(outro, dividir);
		},

		restoDaDivisao: function (outro) {
			return this.operar(outro, restoDaDivisao);
		},

		elevar: function (outro) {
			return this.operar(outro, elevar);
		},

		operar: function (outro, operacao) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValor(this.length, outro.length, Checagem.obterMensagemDeTamanhoDeListasInvalido()).checar();
				Checagem.deValorMinimo(this.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				return this.map(function (valor, indice) {
					return operacao(valor, outro[indice]);
				});
			} else if (global.instanceOf(outro, Number) || global.instanceOf(outro, Boolean)) {
				Checagem.deValorMinimo(this.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				return this.map(function (valor) {
					return operacao(valor, outro);
				});
			}
		},

		eIgual: function (outro) {
			if (global.instanceOf(outro, Array) && this.length === outro.length) {
				var indice;
				for (indice = 0; indice < this.length; indice++) {
					if (!this[indice].eIgual(outro[indice])) {
						return false;
					}
				}
				return true;
			}
			return false;
		},

		maiorQue: function (outro) {
			var listasVazias = (this.length === 0 && outro.length === 0);
			return (!listasVazias && this.comparar(outro, maiorQue));
		},

		maiorOuIgual: function (outro) {
			var listasVazias = (this.length === 0 && outro.length === 0);
			return (listasVazias || this.comparar(outro, maiorOuIgual));
		},

		menorQue: function (outro) {
			var listasVazias = (this.length === 0 && outro.length === 0);
			return (!listasVazias && this.comparar(outro, menorQue));
		},

		menorOuIgual: function (outro) {
			var listasVazias = (this.length === 0 && outro.length === 0);
			return (listasVazias || this.comparar(outro, menorOuIgual));
		},

		comparar: function (outro, comparacao) {
			Checagem.deValor(this.length, outro.length, Checagem.obterMensagemDeTamanhoDeListasInvalido()).checar();
			var indice;
			for (indice = 0; indice < this.length; indice++) {
				if (!comparacao(this[indice], outro[indice])) {
					return false;
				}
			}
			return true;
		},

		casaCom: function (outro) {
			var casado = outro.clone();
			if (this.length !== outro.length) {
				return false;
			}
			outro.each(function (elemento, indice) {
				if (global.instanceOf(elemento, Simbolo)) {
					var tipo = elemento.nome;
					var elementoACasar = this[indice];
					var	substituirParaCasar = (
						(tipo === Simbolo.tipo && global.instanceOf(elementoACasar, Simbolo)) ||
						(tipo === Array.tipo && global.instanceOf(elementoACasar, Array)) ||
						(tipo === String.tipo && global.instanceOf(elementoACasar, String)) ||
						(tipo === Number.tipo && global.instanceOf(elementoACasar, Number)) ||
						(tipo === Boolean.tipo && global.instanceOf(elementoACasar, Boolean))
					);
					if (substituirParaCasar) {
						casado[indice] = elementoACasar;
					}
				}
			}, this);
			return this.eIgual(casado);
		}
	});

	String.implement({
		somar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				var lista = Array.clone(outro);
				lista.unshift(this);
				return lista;
			} else {
				return (this + Util.obterRepresentacaoTextual(outro));
			}
		},

		eIgual: function (outro) {
			if (global.instanceOf(outro, String)) {
				return (this.valueOf() === outro);
			}
			return false;
		},

		maiorQue: function (outro) {
			return (this.length > outro.length);
		},

		maiorOuIgual: function (outro) {
			return (this.length >= outro.length);
		},

		menorQue: function (outro) {
			return (this.length < outro.length);
		},

		menorOuIgual: function (outro) {
			return (this.length <= outro.length);
		}
	});

	Number.implement({
		somar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return somar(esse, valor);
				});
			} else if (global.instanceOf(outro, String)) {
				return (Util.obterRepresentacaoTextual(this) + outro);
			} else if (global.instanceOf(outro, Number)) {
				return (this + outro);
			} else if (global.instanceOf(outro, Boolean)) {
				return (this.fornecerComoBooleano() || outro);
			}
		},

		multiplicar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return multiplicar(esse, valor);
				});
			} else if (global.instanceOf(outro, Number)) {
				return (this * outro);
			} else if (global.instanceOf(outro, Boolean)) {
				return (this.fornecerComoBooleano() && outro);
			}
		},

		subtrair: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return subtrair(esse, valor);
				});
			} else if (global.instanceOf(outro, Number)) {
				return (this - outro);
			}
		},

		dividir: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return dividir(esse, valor);
				});
			} else if (global.instanceOf(outro, Number)) {
				return (this / outro);
			}
		},

		restoDaDivisao: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return restoDaDivisao(esse, valor);
				});
			} else if (global.instanceOf(outro, Number)) {
				return (this % outro);
			}
		},

		elevar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return elevar(esse, valor);
				});
			} else if (global.instanceOf(outro, Number)) {
				return Math.pow(this, outro);
			}
		},

		eIgual: function (outro) {
			if (global.instanceOf(outro, Number)) {
				return (this === outro);
			} else if (global.instanceOf(outro, Boolean)) {
				return (this === outro.fornecerComoNumero());
			}
			return false;
		},

		maiorQue: function (outro) {
			return (this > outro.fornecerComoNumero());
		},

		maiorOuIgual: function (outro) {
			return (this >= outro.fornecerComoNumero());
		},

		menorQue: function (outro) {
			return (this < outro.fornecerComoNumero());
		},

		menorOuIgual: function (outro) {
			return (this <= outro.fornecerComoNumero());
		},

		fornecerComoNumero: function () {
			return this;
		},

		fornecerComoBooleano: function () {
			return (this === 0 ? false : true);
		}
	});

	Boolean.implement({
		somar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return somar(esse, valor);
				});
			} else if (global.instanceOf(outro, String)) {
				return (Util.obterRepresentacaoTextual(this) + outro);
			} else if (global.instanceOf(outro, Number)) {
				return (this || outro.fornecerComoBooleano());
			} else if (global.instanceOf(outro, Boolean)) {
				return (this || outro);
			}
		},

		multiplicar: function (outro) {
			if (global.instanceOf(outro, Array)) {
				Checagem.deValorMinimo(outro.length, 1, Checagem.obterMensagemDeListasDeOperacaoInvalida()).checar();
				var esse = this;
				return outro.map(function (valor) {
					return multiplicar(esse, valor);
				});
			} else if (global.instanceOf(outro, Number)) {
				return (this && outro.fornecerComoBooleano());
			} else if (global.instanceOf(outro, Boolean)) {
				return (this && outro);
			}
		},

		eIgual: function (outro) {
			if (global.instanceOf(outro, Number)) {
				return (this.fornecerComoNumero() === outro);
			} else if (global.instanceOf(outro, Boolean)) {
				return (this === outro);
			}
			return false;
		},

		maiorQue: function (outro) {
			return (this.fornecerComoNumero() > outro.fornecerComoNumero());
		},

		maiorOuIgual: function (outro) {
			return (this.fornecerComoNumero() >= outro.fornecerComoNumero());
		},

		menorQue: function (outro) {
			return (this.fornecerComoNumero() < outro.fornecerComoNumero());
		},

		menorOuIgual: function (outro) {
			return (this.fornecerComoNumero() <= outro.fornecerComoNumero());
		},

		fornecerComoNumero: function () {
			return (this.valueOf() ? 1 : 0);
		}
	});
}(this));
