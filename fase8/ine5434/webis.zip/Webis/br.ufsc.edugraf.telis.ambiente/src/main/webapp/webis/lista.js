/*global AtividadeInterna*/
/*global Checagem*/
/*global ExcecaoWebis*/
/*global Palavra*/
/*global TabelaDeSimbolos*/
/*global Util*/
/*global Webis*/

(function (global) {
	"use strict";

	Object.merge(TabelaDeSimbolos, {
		"concatenar": function (contexto) {
			var sequencia;
			var sequenciaA = contexto.pilha.tirar();
			var sequenciaB = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([sequenciaA, sequenciaB], [Array, Array]).ou([sequenciaA, sequenciaB], [String, String]).checar();
			if (global.instanceOf(sequenciaA, Array) && global.instanceOf(sequenciaB, Array)) {
				sequencia = [];
				sequenciaA = sequenciaA.clone();
				sequenciaB = sequenciaB.clone();
				sequencia.push.apply(sequencia, sequenciaB);
				sequencia.push.apply(sequencia, sequenciaA);
			} else if (global.instanceOf(sequenciaA, String) && global.instanceOf(sequenciaB, String)) {
				sequencia = sequenciaB + sequenciaA;
			}
			contexto.pilha.push(sequencia);
		},

		"inserirElemento": function (contexto) {
			var posicao = contexto.pilha.tirar();
			var elemento = contexto.pilha.tirar();
			var sequencia = contexto.pilha.tirar();
			var indice;
			var indiceDaSequenciaFilho;
			var posicaoFinal;
			var sequenciaInicial;
			var sequenciaPai;
			Checagem.deTiposDeParametros([sequencia, elemento, posicao], [Array, Palavra, Array]).ou([sequencia, elemento, posicao], [Array, Palavra, Number]).ou([sequencia, elemento, posicao], [Array, Array, Array]).ou([sequencia, elemento, posicao], [Array, Array, Number]).ou([sequencia, elemento, posicao], [String, Palavra, Number]).ou([sequencia, elemento, posicao], [String, Array, Number]).checar();
			if (global.instanceOf(posicao, Number)) {
				indice = (posicao - 1);
				Checagem.deLimiteDeListaComSobra(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				if (global.instanceOf(sequencia, String)) {
					contexto.pilha.push(sequencia.slice(0, indice) + Util.obterRepresentacaoTextual(elemento) + sequencia.slice(indice));
				} else if (global.instanceOf(sequencia, Array)) {
					sequencia = sequencia.clone();
					sequencia.splice(indice, 0, elemento);
					contexto.pilha.push(sequencia);
				}
			} else if (global.instanceOf(posicao, Array)) {
				posicao = posicao.clone();
				sequencia = sequencia.clone();
				sequenciaInicial = sequencia;
				Checagem.deValorMinimo(posicao.length, 2, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
				posicaoFinal = posicao.pop();
				posicao.each(function (posicaoLocal, contador) {
					indice = (posicaoLocal - 1);
					Checagem.deTipo(posicaoLocal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
					Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
					Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
					sequenciaPai = sequencia;
					sequencia = sequencia[indice];
				});
				indiceDaSequenciaFilho = indice;
				indice = (posicaoFinal - 1);
				Checagem.deTipo(posicaoFinal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
				Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).ou(sequencia, String).checar();
				Checagem.deLimiteDeListaComSobra(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				if (global.instanceOf(sequencia, String)) {
					sequencia = (sequencia.slice(0, indice) + Util.obterRepresentacaoTextual(elemento) + sequencia.slice(indice));
					sequenciaPai[indiceDaSequenciaFilho] = sequencia;
					contexto.pilha.push(sequenciaInicial);
				} else if (global.instanceOf(sequencia, Array)) {
					sequencia = sequencia.clone();
					sequencia.splice(indice, 0, elemento);
					sequenciaPai[indiceDaSequenciaFilho] = sequencia;
					contexto.pilha.push(sequenciaInicial);
				}
			}
		},

		"inserirNoInício": function (contexto) {
			var elementoInserido = contexto.pilha.tirar();
			var sequencia = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([sequencia, elementoInserido], [Array, Palavra]).ou([sequencia, elementoInserido], [Array, Array]).ou([sequencia, elementoInserido], [String, Palavra]).ou([sequencia, elementoInserido], [String, Array]).checar();
			if (global.instanceOf(sequencia, String)) {
				sequencia = Util.obterRepresentacaoTextual(sequencia);
				sequencia = Util.obterRepresentacaoTextual(elementoInserido) + sequencia;
			} else if (global.instanceOf(sequencia, Array)) {
				sequencia = Array.clone(sequencia);
				sequencia.unshift(elementoInserido);
			}
			contexto.pilha.push(sequencia);
		},

		"inserirNoFim": function (contexto) {
			var elementoInserido = contexto.pilha.tirar();
			var sequencia = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([sequencia, elementoInserido], [Array, Palavra]).ou([sequencia, elementoInserido], [Array, Array]).ou([sequencia, elementoInserido], [String, Palavra]).ou([sequencia, elementoInserido], [String, Array]).checar();
			if (global.instanceOf(sequencia, String)) {
				sequencia = Util.obterRepresentacaoTextual(sequencia);
				sequencia = sequencia + Util.obterRepresentacaoTextual(elementoInserido);
			} else if (global.instanceOf(sequencia, Array)) {
				sequencia = Array.clone(sequencia);
				sequencia.push(elementoInserido);
			}
			contexto.pilha.push(sequencia);
		},

		"gerarLista": function (contexto) {
			var quantidadeDeElementos = contexto.pilha.tirar();
			var lista = [];
			Checagem.deTipoDeParametro(quantidadeDeElementos, Number).checar();
			while (quantidadeDeElementos > 0) {
				lista.unshift(contexto.pilha.tirar());
				quantidadeDeElementos -= 1;
			}
			contexto.pilha.push(lista);
		},

		"obterElemento": function (contexto) {
			var posicao = contexto.pilha.tirar();
			var sequencia = contexto.pilha.tirar();
			var indice;
			var posicaoFinal;
			Checagem.deTiposDeParametros([sequencia, posicao], [Array, Array]).ou([sequencia, posicao], [Array, Number]).ou([sequencia, posicao], [String, Number]).checar();
			if (global.instanceOf(posicao, Number)) {
				indice = (posicao - 1);
				Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				contexto.pilha.push(sequencia[indice]);
			} else if (global.instanceOf(posicao, Array)) {
				posicao = posicao.clone();
				Checagem.deValorMinimo(posicao.length, 2, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
				posicaoFinal = posicao.pop();
				posicao.each(function (posicaoLocal, contador) {
					indice = (posicaoLocal - 1);
					Checagem.deTipo(posicaoLocal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
					Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
					Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
					sequencia = sequencia[indice];
				});
				indice = (posicaoFinal - 1);
				Checagem.deTipo(posicaoFinal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
				Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).ou(sequencia, String).checar();
				Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				contexto.pilha.push(sequencia[indice]);
			}
		},

		"obterTamanho": function (contexto) {
			var sequencia = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(sequencia, Array).ou(sequencia, String).checar();
			contexto.pilha.push(sequencia.length);
		},

		"paraCada": function (contexto) {
			var comandos = contexto.pilha.tirar();
			var elementos = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([elementos, comandos], [Array, Array]).ou([elementos, comandos], [String, Array]).checar();
			comandos = comandos.clone();
			elementos = global.instanceOf(elementos, Array) ? elementos.clone() : elementos.split("");
			var contextoComContaGiro = contexto.criarContextoFilhoDeLacoDeRepeticao();
			var contextosDeMapeamento = [];
			elementos.each(function (elemento) {
				contextosDeMapeamento.push(contextoComContaGiro.criarContextoFilhoDeParaCada(elemento));
			});
			var atualizacaoDeContaGiro = new AtividadeInterna(function (meuContexto) {
				meuContexto.contarGiro();
			});
			var construirMapa = new AtividadeInterna(function (meuContexto) {
				var mapa = [];
				contextosDeMapeamento.each(function (contextoDeMapeamento) {
					mapa.push(contextoDeMapeamento.pilha.tirar());
				});
				meuContexto.pilha.push(mapa);
			});
			var indice;
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, construirMapa);
			for (indice = (elementos.length - 1); indice >= 0; indice--) {
				Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, atualizacaoDeContaGiro);
				Webis.pilhaDeExecucao.adicionarBloco(contextosDeMapeamento[indice], comandos);
			}
		},

		"primeiro": function (contexto) {
			var sequencia = contexto.pilha.tirar();
			var indice = 0;
			Checagem.deTipoDeParametro(sequencia, Array).ou(sequencia, String).checar();
			Checagem.deValorMinimo(sequencia.length, 1, Checagem.obterMensagemDeSequenciaVazia()).checar();
			contexto.pilha.push(sequencia[indice]);
		},

		"rartelos": function (contexto) {
			var sequencia = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(sequencia, Array).ou(sequencia, String).checar();
			if (global.instanceOf(sequencia, String)) {
				sequencia = sequencia.split("");
			}
			contexto.pilha.push.apply(contexto.pilha, sequencia.reverse());
		},

		"removerElemento": function (contexto) {
			var posicao = contexto.pilha.tirar();
			var sequencia = contexto.pilha.tirar();
			var indice;
			var elemento;
			var indiceDaSequenciaFilho;
			var posicaoFinal;
			var sequenciaInicial;
			var sequenciaPai;
			Checagem.deTiposDeParametros([sequencia, posicao], [Array, Array]).ou([sequencia, posicao], [Array, Number]).ou([sequencia, posicao], [String, Number]).checar();
			if (global.instanceOf(posicao, Number)) {
				indice = (posicao - 1);
				Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				if (global.instanceOf(sequencia, String)) {
					contexto.pilha.push(sequencia.slice(0, indice) + sequencia.slice(indice + 1));
				} else if (global.instanceOf(sequencia, Array)) {
					sequencia = sequencia.clone();
					sequencia.splice(indice, 1);
					contexto.pilha.push(sequencia);
				}
			} else if (global.instanceOf(posicao, Array)) {
				posicao = posicao.clone();
				sequencia = sequencia.clone();
				sequenciaInicial = sequencia;
				Checagem.deValorMinimo(posicao.length, 2, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
				posicaoFinal = posicao.pop();
				posicao.each(function (posicaoLocal, contador) {
					indice = (posicaoLocal - 1);
					Checagem.deTipo(posicaoLocal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
					Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
					Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
					sequenciaPai = sequencia;
					sequencia = sequencia[indice];
				});
				indiceDaSequenciaFilho = indice;
				indice = (posicaoFinal - 1);
				Checagem.deTipo(posicaoFinal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
				Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).ou(sequencia, String).checar();
				Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				if (global.instanceOf(sequencia, String)) {
					sequencia = (sequencia.slice(0, indice) + sequencia.slice(indice + 1));
					sequenciaPai[indiceDaSequenciaFilho] = sequencia;
					contexto.pilha.push(sequenciaInicial);
				} else if (global.instanceOf(sequencia, Array)) {
					sequencia = sequencia.clone();
					sequencia.splice(indice, 1);
					sequenciaPai[indiceDaSequenciaFilho] = sequencia;
					contexto.pilha.push(sequenciaInicial);
				}
			}
		},

		"soletrar": function (contexto) {
			var sequencia = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(sequencia, Array).ou(sequencia, String).checar();
			if (global.instanceOf(sequencia, String)) {
				sequencia = sequencia.split("");
			}
			contexto.pilha.push.apply(contexto.pilha, sequencia);
		},

		"substituirElemento": function (contexto) {
			var posicao = contexto.pilha.tirar();
			var elemento = contexto.pilha.tirar();
			var sequencia = contexto.pilha.tirar();
			var indice;
			var indiceDaSequenciaFilho;
			var posicaoFinal;
			var sequenciaInicial;
			var sequenciaPai;
			Checagem.deTiposDeParametros([sequencia, elemento, posicao], [Array, Palavra, Array]).ou([sequencia, elemento, posicao], [Array, Palavra, Number]).ou([sequencia, elemento, posicao], [Array, Array, Array]).ou([sequencia, elemento, posicao], [Array, Array, Number]).ou([sequencia, elemento, posicao], [String, Palavra, Number]).ou([sequencia, elemento, posicao], [String, Array, Number]).checar();
			if (global.instanceOf(posicao, Number)) {
				indice = (posicao - 1);
				Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				if (global.instanceOf(sequencia, String)) {
					contexto.pilha.push(sequencia.slice(0, indice) + Util.obterRepresentacaoTextual(elemento) + sequencia.slice(indice + 1));
				} else if (global.instanceOf(sequencia, Array)) {
					sequencia = sequencia.clone();
					sequencia.splice(indice, 1, elemento);
					contexto.pilha.push(sequencia);
				}
			} else if (global.instanceOf(posicao, Array)) {
				posicao = posicao.clone();
				sequencia = sequencia.clone();
				sequenciaInicial = sequencia;
				Checagem.deValorMinimo(posicao.length, 2, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
				posicaoFinal = posicao.pop();
				posicao.each(function (posicaoLocal, contador) {
					indice = (posicaoLocal - 1);
					Checagem.deTipo(posicaoLocal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
					Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).checar();
					Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
					sequenciaPai = sequencia;
					sequencia = sequencia[indice];
				});
				indiceDaSequenciaFilho = indice;
				indice = (posicaoFinal - 1);
				Checagem.deTipo(posicaoFinal, Number, Checagem.obterMensagemDeListaDeIndicesInvalida()).checar();
				Checagem.deTipo(sequencia, Array, Checagem.obterMensagemDeDimensaoDeListaInvalida()).ou(sequencia, String).checar();
				Checagem.deLimiteDeLista(sequencia, indice, Checagem.obterMensagemDeIndiceForaDosLimites()).checar();
				if (global.instanceOf(sequencia, String)) {
					sequencia = (sequencia.slice(0, indice) + Util.obterRepresentacaoTextual(elemento) + sequencia.slice(indice + 1));
					sequenciaPai[indiceDaSequenciaFilho] = sequencia;
					contexto.pilha.push(sequenciaInicial);
				} else if (global.instanceOf(sequencia, Array)) {
					sequencia = sequencia.clone();
					sequencia.splice(indice, 1, elemento);
					sequenciaPai[indiceDaSequenciaFilho] = sequencia;
					contexto.pilha.push(sequenciaInicial);
				}
			}
		},

		"último": function (contexto) {
			var sequencia = contexto.pilha.tirar();
			var indice = (sequencia.length - 1);
			Checagem.deTipoDeParametro(sequencia, Array).ou(sequencia, String).checar();
			Checagem.deValorMinimo(sequencia.length, 1, Checagem.obterMensagemDeSequenciaVazia()).checar();
			contexto.pilha.push(sequencia[indice]);
		}
	});
}(this));
