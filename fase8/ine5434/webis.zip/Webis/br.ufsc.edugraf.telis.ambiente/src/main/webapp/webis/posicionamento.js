/*global AtividadeInterna*/
/*global Ator*/
/*global Checagem*/
/*global TabelaDeSimbolos*/
/*global Webis*/

(function (global) {
	"use strict";

	function reduzirGraus(graus) {
		graus = (graus % 360);
		return (graus < 0) ? graus + 360 : graus;
	}

	function paraGraus(radianos) {
		var anguloEmGraus = (radianos * 180 / Math.PI);
		return reduzirGraus(anguloEmGraus);
	}

	function paraRadianos(graus) {
		graus = reduzirGraus(graus);
		return (graus * Math.PI / 180);
	}

	function fixarDirecao(angulo) {
		Ator.rotacao = reduzirGraus(angulo);
		Ator.direcao.x = Math.cos(paraRadianos(Ator.rotacao));
		Ator.direcao.y = Math.sin(paraRadianos(Ator.rotacao));
	}

	function fixarPosicaoEVelocidade(posicao, tempoDeDeslocamento) {
		Ator.velocidade.x = (posicao.x - Ator.posicao.x) / tempoDeDeslocamento;
		Ator.velocidade.y = (posicao.y - Ator.posicao.y) / tempoDeDeslocamento;
		Ator.posicao.x = posicao.x;
		Ator.posicao.y = posicao.y;
	}

	function fixarPosicaoEZerarVelocidade(posicao) {
		Ator.velocidade.x = 0;
		Ator.velocidade.y = 0;
		Ator.posicao.x = posicao.x;
		Ator.posicao.y = posicao.y;
	}

	function calcularPosicao(deslocamento) {
		var posicao = {};
		posicao.x = (Ator.direcao.x * deslocamento) + Ator.posicao.x;
		posicao.y = (Ator.direcao.y * deslocamento) + Ator.posicao.y;
		return posicao;
	}

	function moverNoEcossistema() {
		global.postMessage({comando: "MOVER", posicao: Ator.posicao, direcao: Ator.direcao, velocidade: Ator.velocidade, identificadorDoAtor: Ator.identificador});
	}

	function andar(contexto, distancia) {
		if (Ator.comSom) {
			var pixelsPorCentesimo = (distancia < 0) ? -Ator.tamanhoDoPasso : Ator.tamanhoDoPasso;
			var passos = Math.floor(distancia / pixelsPorCentesimo);
			var pixelsDoUltimoPasso = (distancia - (passos * pixelsPorCentesimo));
			Webis.pilhaDeExecucao.fixarJanelaDeTempo(100);
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, new AtividadeInterna(function () {
				fixarPosicaoEZerarVelocidade(calcularPosicao(pixelsDoUltimoPasso));
				moverNoEcossistema();
				Webis.pilhaDeExecucao.restaurarJanelaDeTempo();
			}));
			var atualizacaoDePosicao = function () {
				fixarPosicaoEVelocidade(calcularPosicao(pixelsPorCentesimo), 1);
				moverNoEcossistema();
			};
			var contador;
			for (contador = 0; contador < passos; contador += 1) {
				Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, new AtividadeInterna(atualizacaoDePosicao));
			}
		} else {
			fixarPosicaoEZerarVelocidade(calcularPosicao(distancia));
			moverNoEcossistema();
		}
	}

	Object.merge(TabelaDeSimbolos, {
		"andarPara": function (contexto) {
			var posicao = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(posicao, Array).checar();
			Checagem.deValor(posicao.length, 2, Checagem.obterMensagemDeListaDePosicaoInvalida()).checar();
			posicao = posicao.clone();
			var y = posicao.tirar();
			var x = posicao.tirar();
			Checagem.deTipos([x, y], [Number, Number], Checagem.obterMensagemDeListaDePosicaoInvalida()).checar();
			var catetoOposto = (y - Ator.posicao.y);
			var catetoAdjacente = (x - Ator.posicao.x);
			var direcao = (catetoAdjacente >= 0) ? paraGraus(Math.atan(catetoOposto / catetoAdjacente)) : paraGraus(Math.atan(catetoOposto / catetoAdjacente) + Math.PI);
			var distancia = Math.sqrt(Math.pow(catetoAdjacente, 2) + Math.pow(catetoOposto, 2));
			fixarDirecao(direcao);
			andar(contexto, distancia);
		},

		"direita": function (contexto) {
			var angulo = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(angulo, Number).checar();
			fixarDirecao(Ator.rotacao - angulo);
			moverNoEcossistema();
		},

		"fixarDireção": function (contexto) {
			var angulo = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(angulo, Number).checar();
			fixarDirecao(angulo);
			moverNoEcossistema();
		},

		"fixarVelocidade": function (contexto) {
			var velocidade = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(velocidade, Number).checar();
			Checagem.deValorMinimoExclusive(velocidade, 0, Checagem.obterMensagemDeVelocidadeInvalida()).checar();
			Ator.tamanhoDoPasso = velocidade;
		},

		"frente": function (contexto) {
			var deslocamento = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(deslocamento, Number).checar();
			andar(contexto, deslocamento);
		},

		"obterDireção": function (contexto) {
			contexto.pilha.push(Math.round(Ator.rotacao));
		},

		"obterPosição": function (contexto) {
			var posicao = [Math.round(Ator.posicao.x), Math.round(Ator.posicao.y)];
			contexto.pilha.push(posicao);
		}
	});
}(this));
