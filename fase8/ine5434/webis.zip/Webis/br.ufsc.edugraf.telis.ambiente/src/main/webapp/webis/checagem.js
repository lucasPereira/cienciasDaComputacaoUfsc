/*global Checagem*/
/*global Class*/
/*global ExcecaoWebis*/
/*global Palavra*/
/*global Simbolo*/

(function (global) {
	"use strict";

	var ChecagemDeTiposDeParametros = new Class({
		initialize: function () {
			this.tiposCorretos = true;
			this.tiposDesejados = [];
		},

		deTipoDeParametros: function (objetos, tipos) {
			this.tiposCorretos = true;
			this.tiposDesejados.push(tipos);
			objetos.each(function (objeto, indice) {
				if (!global.instanceOf(objeto, tipos[indice]) && !(tipos[indice] === Palavra && (global.instanceOf(objeto, Simbolo) || global.instanceOf(objeto, String) || global.instanceOf(objeto, Number) || global.instanceOf(objeto, Boolean)))) {
					this.tiposCorretos = false;
				}
			}, this);
			return this;
		},

		ou: function (objetos, tipos) {
			if (this.tiposCorretos) {
				this.tiposDesejados.push(tipos);
				return this;
			}
			return this.deTipoDeParametros(objetos, tipos);
		},

		checar: function () {
			if (!this.tiposCorretos) {
				throw new ExcecaoWebis(Checagem.obterMensagemDeTiposDeParametrosInvalidos(this.tiposDesejados));
			}
		}
	});

	var ChecagemDeTipoDeParametro = new Class({
		initialize: function () {
			this.tiposCorretos = true;
			this.tiposDesejados = [];
		},

		deTipoDeParametros: function (objeto, tipo) {
			this.tiposCorretos = true;
			this.tiposDesejados.push([tipo]);
			if (!global.instanceOf(objeto, tipo) && !(tipo === Palavra && (global.instanceOf(objeto, Simbolo) || global.instanceOf(objeto, String) || global.instanceOf(objeto, Number) || global.instanceOf(objeto, Boolean)))) {
				this.tiposCorretos = false;
			}
			return this;
		},

		ou: function (objeto, tipo) {
			if (this.tiposCorretos) {
				this.tiposDesejados.push([tipo]);
				return this;
			}
			return this.deTipoDeParametros(objeto, tipo);
		},

		checar: function () {
			if (!this.tiposCorretos) {
				throw new ExcecaoWebis(Checagem.obterMensagemDeTiposDeParametrosInvalidos(this.tiposDesejados));
			}
		}
	});

	var ChecagemDeTipos = new Class({
		initialize: function (mensagem) {
			this.tiposCorretos = true;
			this.mensagem = mensagem;
		},

		deTipos: function (objetos, tipos) {
			this.tiposCorretos = true;
			objetos.each(function (objeto, indice) {
				if (!global.instanceOf(objeto, tipos[indice])) {
					this.tiposCorretos = false;
				}
			}, this);
			return this;
		},

		ou: function (objetos, tipos) {
			if (this.tiposCorretos) {
				return this;
			}
			this.deTipos(objetos, tipos);
			return this;
		},

		checar: function () {
			if (!this.tiposCorretos) {
				throw new ExcecaoWebis(this.mensagem);
			}
		}
	});

	var ChecagemDeTipo = new Class({
		initialize: function (mensagem) {
			this.tiposCorretos = true;
			this.mensagem = mensagem;
		},

		deTipo: function (objeto, tipo) {
			this.tiposCorretos = true;
			if (!global.instanceOf(objeto, tipo)) {
				this.tiposCorretos = false;
			}
			return this;
		},

		ou: function (objeto, tipo) {
			if (this.tiposCorretos) {
				return this;
			}
			this.deTipo(objeto, tipo);
			return this;
		},

		checar: function () {
			if (!this.tiposCorretos) {
				throw new ExcecaoWebis(this.mensagem);
			}
		}
	});

	var ChecagemDeValor = new Class({
		initialize: function (mensagem) {
			this.mensagem = mensagem;
			this.valorCorreto = false;
		},

		deValor: function (valorRecebido, valorEsperado) {
			this.valorCorreto = ((valorEsperado === valorRecebido) || this.valorCorreto);
			return this;
		},

		checar: function () {
			if (!this.valorCorreto) {
				throw new ExcecaoWebis(this.mensagem);
			}
		}
	});

	var ChecagemDeLimites = new Class({
		initialize: function (mensagem) {
			this.mensagem = mensagem;
			this.valorCorreto = false;
		},

		deIntervalo: function (valor, inferior, superior) {
			this.valorCorreto = ((valor >= inferior && valor <= superior) || this.valorCorreto);
			return this;
		},

		deValorMinimo: function (valor, valorMinimo) {
			this.valorCorreto = ((valor >= valorMinimo) || this.valorCorreto);
			return this;
		},

		deValorMinimoExclusive: function (valor, valorMinimo) {
			this.valorCorreto = ((valor > valorMinimo) || this.valorCorreto);
			return this;
		},

		deValorMaximo: function (valor, valorMaximo) {
			this.valorCorreto = ((valor <= valorMaximo) || this.valorCorreto);
			return this;
		},

		deValorMaximoExclusive: function (valor, valorMaximo) {
			this.valorCorreto = ((valor < valorMaximo) || this.valorCorreto);
			return this;
		},

		checar: function () {
			if (!this.valorCorreto) {
				throw new ExcecaoWebis(this.mensagem);
			}
		}
	});

	var Checagem = {
		deTiposDeParametros: function (objetos, tipos) {
			return new ChecagemDeTiposDeParametros().deTipoDeParametros(objetos, tipos);
		},

		deTipoDeParametro: function (objeto, tipo) {
			return new ChecagemDeTipoDeParametro().deTipoDeParametros(objeto, tipo);
		},

		deTipos: function (objetos, tipos, mensagem) {
			return new ChecagemDeTipos(mensagem).deTipos(objetos, tipos);
		},

		deTipo: function (objeto, tipo, mensagem) {
			return new ChecagemDeTipo(mensagem).deTipo(objeto, tipo);
		},

		deValor: function (valorRecebido, valorEsperado, mensagem) {
			return new ChecagemDeValor(mensagem).deValor(valorRecebido, valorEsperado);
		},

		deIntervalo: function (valor, inferior, superior, mensagem) {
			return new ChecagemDeLimites(mensagem).deIntervalo(valor, inferior, superior);
		},

		deLimiteDeLista: function (lista, indice, mensagem) {
			return new ChecagemDeLimites(mensagem).deIntervalo(indice, 0, (lista.length - 1));
		},

		deLimiteDeListaComSobra: function (lista, indice, mensagem) {
			return new ChecagemDeLimites(mensagem).deIntervalo(indice, 0, lista.length);
		},

		deValorMinimo: function (valor, valorMinimo, mensagem) {
			return new ChecagemDeLimites(mensagem).deValorMinimo(valor, valorMinimo);
		},

		deValorMaximo: function (valor, valorMaximo, mensagem) {
			return new ChecagemDeLimites(mensagem).deValorMaximo(valor, valorMaximo);
		},

		deValorMinimoExclusive: function (valor, valorMinimo, mensagem) {
			return new ChecagemDeLimites(mensagem).deValorMinimoExclusive(valor, valorMinimo);
		},

		deValorMaximoExclusive: function (valor, valorMaximo, mensagem) {
			return new ChecagemDeLimites(mensagem).deValorMaximoExclusive(valor, valorMaximo);
		},

		obterTiposDosElementos: function (elementos) {
			var tipos = elementos.map(function (elemento) {
				return elemento.tipo;
			});
			return tipos;
		},

		obterTiposDosElementosTextual: function (elementos) {
			return String.formatar("[%@]", this.obterTiposDosElementos(elementos).juntar("] ["));
		},

		obterTiposTextual: function (todosTipos) {
			var tiposTextual = todosTipos.map(function (tipos) {
				return tipos.juntar("] [");
			});
			tiposTextual = tiposTextual.juntar("] ou [");
			return String.formatar("[%@]", tiposTextual);
		},

		obterMensagemDeTiposDeParametrosInvalidos: function (tiposVariaveis) {
			var mensagem = "Parâmetros inválidos na pilha. Deveriam ser: %@.";
			var nomesDosTipos = this.obterTiposTextual(tiposVariaveis);
			return String.formatar(mensagem, nomesDosTipos);
		},

		obterMensagemDePalavraNaoEncontrada: function (palavra) {
			return String.formatar("Palavra não econtrada: %@.", palavra);
		},

		obterMensagemDeErroLexico: function (simboloRecebido) {
			return String.formatar("Erro léxico. Símbolo inválido recebido: %@.", simboloRecebido);
		},

		obterMensagemDeErroSintatico: function (simboloEsperado, simboloRecebido) {
			return String.formatar("Erro sintático. O símbolo esperado era %@, mas o símbolo recebido foi %@.", simboloEsperado, simboloRecebido);
		},

		obterMensagemDeParametrosInsuficientes: function () {
			return "Número de parâmetros insuficiente na pilha.";
		},

		obterMensagemDeDefinicaoDeModeloInvalida: function () {
			return "A lista com as agendas locais é inválida.";
		},

		obterMensagemDeUsoDeContarGiroInvalido: function () {
			return "contarGiro não deve ser usado fora de laço de repetição.";
		},

		obterMensagemDeAvaliacaoInvalida: function () {
			return "A avaliação da condição deve ser um valor lógico.";
		},

		obterMensagemDeEstruturaDeListaParaAssociarInvalida: function () {
			return "Listas devem ter a mesma estrutura para serem associadas.";
		},

		obterMensagemDeTamanhoDeListasInvalido: function () {
			return "Listas devem ter o mesmo tamanho para serem operadas.";
		},

		obterMensagemDeSequenciaVazia: function () {
			return "Sequência vazia.";
		},

		obterMensagemDeIndiceForaDosLimites: function () {
			return "Índice fora dos limites.";
		},

		obterMensagemDeDimensaoDeListaInvalida: function () {
			return "A dimensão da lista deve ser compátivel com o tamanho lista de índices. A lista de índices deve ter pelo menos dois itens e não deve conter mais itens do que a dimensão da lista multidimensional.";
		},

		obterMensagemDeListaDeIndicesInvalida: function () {
			return "A lista de índices deve conter apenas números.";
		},

		obterMensagemDeListasDeOperacaoInvalida: function () {
			return "A listas deve ter pelo menos um elemento para ser operada.";
		},

		obterMensagemDeListaDePosicaoInvalida: function () {
			return "A lista de posições deve conter dois números.";
		},

		obterMensagemDeListaComIntervalosInvalida: function () {
			return "A lista com intervalos deve conter dois números.";
		},

		obterMensagemDeVelocidadeInvalida: function () {
			return "A velocidade deve ser maior que zero.";
		}
	};

	global.Checagem = Checagem;
}(this));
