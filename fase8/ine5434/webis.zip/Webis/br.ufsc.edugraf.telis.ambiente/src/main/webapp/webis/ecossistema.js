/*global AtorMarionete*/
/*global AtorMarioneteBurro*/
/*global AtorMarionetePadrao*/
/*global Grafico2D*/
/*global Grafico2DBurro*/
/*global Grafico2DPadrao*/
/*global GraficoBurro*/
/*global GraficoPadrao*/
/*global Modernizr*/
/*global Som3D*/
/*global Som3DBurro*/
/*global Som3DPadrao*/
/*global SomBurro*/
/*global SomPadrao*/
/*global Teclado*/
/*global Visao*/
/*global AudioContext*/
/*global webkitAudioContext*/
/*global mozAudioContext*/
/*global oAudioContext*/
/*global msAudioContext*/

(function (global) {
	"use strict";

	var Ecossistema = {
		inicializar: function () {
			this.quantidadeDeAtores = 0;
			this.modelos = {};
			this.atores = {};
			this.inicializarOrganismos();
			this.aplique = this.criarAtor("aplique", "webis/modelo.js");
		},

		inicializarOrganismos: function () {
			var possuiSom = (Modernizr.audio && this.possuiWebAudio());
			var possuiGrafico = Modernizr.canvas;
			var possuiWorkers = Modernizr.webworkers;
			global.Grafico2D = (possuiGrafico) ? Grafico2DPadrao : Grafico2DBurro;
			global.Grafico = (possuiGrafico) ? GraficoPadrao : GraficoBurro;
			global.Som3D = (possuiSom) ? Som3DPadrao : Som3DBurro;
			global.Som = (possuiSom) ? SomPadrao : SomBurro;
			global.AtorMarionete = (possuiWorkers) ? AtorMarionetePadrao : AtorMarioneteBurro;
			Teclado.inicializar();
			Som3D.inicializar();
			Grafico2D.inicializar();
		},

		possuiWebAudio: function () {
			return ((typeof webkitAudioContext === "function") || (typeof mozAudioContext === "function") || (typeof oAudioContext === "function") || (typeof msAudioContext === "function") || (typeof AudioContext === "function"));
		},

		criarAtor: function (identificadorDoAtor, enderecoDoWorker) {
			var ator = new AtorMarionete(enderecoDoWorker);
			ator.tratarMensagem(this.receberMensagemDeAtor, this);
			ator.tratarErro(this.receberErroDeAtor, this);
			this.atores[identificadorDoAtor] = ator;
			this.quantidadeDeAtores += 1;
			return ator;
		},

		receberMensagemDeAtor: function (mensagem) {
			var dados = mensagem.data;
			var comando = dados.comando;
			if (this[comando] !== undefined) {
				this[comando](dados);
			} else {
				Visao.depurar("Ecossistema", Visao.fornecerMensagemDeComandoInexistente(comando));
			}
		},

		receberErroDeAtor: function (erro) {
			var escopo = "Ator";
			var tipo = erro.name;
			var mensagem = erro.message;
			var arquivo = erro.filename;
			var linha = erro.lineno;
			Visao.depurar(escopo, Visao.fornecerMensagemDeExcecao(tipo, mensagem, arquivo, linha));
		},

		"INCLUIR_MODELO": function (dados) {
			var nomeDoModelo = dados.nomeDoModelo;
			var agendas = dados.agendas;
			this.modelos[nomeDoModelo] = agendas;
		},

		"NOVO": function (dados) {
			var nomeDoModelo = dados.nomeDoModelo;
			var posicaoNoCodigo = dados.posicaoNoCodigo;
			if (this.modelos[nomeDoModelo] === undefined) {
				Visao.mostrarMensagemDeErro(Visao.fornecerMensagemDeModeloInexistente(nomeDoModelo), posicaoNoCodigo);
			} else {
				var parametros = dados.parametros;
				var identificadorDoAtor = (nomeDoModelo + this.quantidadeDeAtores);
				var agendas = this.modelos[nomeDoModelo];
				var atorMarionete = this.criarAtor(identificadorDoAtor, "webis/novoAtor.js");
				atorMarionete.enviarMensagem({comando: "INICIAR_ATOR", agendas: agendas, parametros: parametros, identificadorDoAtor: identificadorDoAtor});
			}
		},

		"SUICIDAR": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			this.atores[identificadorDoAtor].suicidar();
		},

		"DIZER": function (dados) {
			var listaDita = dados.listaDita;
			Object.each(this.atores, function (atorMarionete, identificadorDoAtor) {
				atorMarionete.enviarMensagem({comando: "RECEBER_ESTIMULO", listaDita: listaDita});
			});
		},

		"MOVER": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			var posicao = dados.posicao;
			var direcao = dados.direcao;
			var velocidade = dados.velocidade;
			this.atores[identificadorDoAtor].mover(posicao, direcao, velocidade);
		},

		"FIXAR_SOM": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			var uri = dados.uri;
			var posicaoNoCodigo = dados.posicaoNoCodigo;
			Som3D.carregarSom(uri, function (som) {
				this.atores[identificadorDoAtor].tocar(som, false);
			}.bind(this), posicaoNoCodigo);
		},

		"FIXAR_SOM_CONTINUO": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			var uri = dados.uri;
			var posicaoNoCodigo = dados.posicaoNoCodigo;
			Som3D.carregarSom(uri, function (som) {
				this.atores[identificadorDoAtor].tocar(som, true);
			}.bind(this), posicaoNoCodigo);
		},

		"COM_SOM": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			this.atores[identificadorDoAtor].comSom();
		},

		"SEM_SOM": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			this.atores[identificadorDoAtor].semSom();
		},

		"CALIBRAR_SOM": function (dados) {
			var calibragemDeSom = dados.calibragemDeSom;
			Som3D.calibrarSom(calibragemDeSom);
		},

		"PEGAR_MICROFONE": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			Som3D.pegarMicrofone(this.atores[identificadorDoAtor]);
		},

		"VISIVEL": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			this.atores[identificadorDoAtor].visivel();
		},

		"INVISIVEL": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			this.atores[identificadorDoAtor].invisivel();
		},

		"CARIMBAR": function (dados) {
			var identificadorDoAtor = dados.identificadorDoAtor;
			this.atores[identificadorDoAtor].carimbar();
		},

		"MOSTRAR": function (dados) {
			var mensagem = dados.mensagem;
			Visao.mostrarMensagem(mensagem);
		},

		"REPORTAR_ERRO": function (dados) {
			var erro = dados.erro;
			Visao.mostrarMensagemDeErro(erro.mensagem, erro.posicaoNoCodigo);
		},

		"DEPURAR": function (dados) {
			var escopo = dados.escopo;
			var tipo = dados.tipo;
			var mensagem = dados.mensagem;
			var arquivo = dados.arquivo;
			var linha = dados.linha;
			Visao.depurar(escopo, Visao.fornecerMensagemDeExcecao(tipo, mensagem, arquivo, linha));
		},

		"RETORNO_LEITURA_DA_PILHA": function (dados) {}
	};

	global.Ecossistema = Ecossistema;
}(this));
