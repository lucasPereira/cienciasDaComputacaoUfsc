/*global TabelaDeSimbolos*/

(function () {
	"use strict";

	Object.merge(TabelaDeSimbolos, {
		"obterNúmeroDeElementosNaPilha": function (contexto) {
			contexto.pilha.push(contexto.pilha.length);
		}
	});
}());
