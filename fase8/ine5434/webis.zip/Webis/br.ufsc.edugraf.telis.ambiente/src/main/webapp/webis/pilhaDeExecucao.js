/*global Class*/
/*global EstadoEncerrado*/
/*global EstadoExecucao*/
/*global EstadoInterrompido*/
/*global ExcecaoWebis*/
/*global Webis*/

(function (global) {
	"use strict";

	var EstadoNaoIniciado = new Class({
		iniciar: function (pilha) {
			pilha.estado = new EstadoExecucao();
			if (pilha.pilhaDeComandos.length > 0) {
				pilha.executar();
			} else {
				pilha.encerrar();
			}
		},

		interromper: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoNaoIniciado.interromper().");
		},

		executar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoNaoIniciado.executar().");
		},

		retomar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoNaoIniciado.retomar().");
		},

		encerrar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoNaoIniciado.encerrar().");
		}
	});

	var EstadoExecucao = new Class({
		iniciar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoExecucao.iniciar().");
		},

		executar: function (pilha) {
			var execucaoSincrona = pilha.pilhaDeComandos.shift();
			execucaoSincrona();
			if (pilha.pilhaDeComandos.length > 0 && global.instanceOf(pilha.estado, EstadoExecucao)) {
				pilha.temporizador = global.setTimeout(function () {
					pilha.executar();
				}, pilha.janelaDeTempo);
				pilha.tempoPassadoDoTimeout = 0;
				pilha.momentoDoDisparoDoTimeout = Date.now();
			} else if (global.instanceOf(pilha.estado, EstadoExecucao)) {
				pilha.encerrar();
			}
		},

		interromper: function (pilha) {
			pilha.estado = new EstadoInterrompido();
			Webis.executandoInterrupcao = true;
			pilha.temporizador = global.clearTimeout(pilha.temporizador);
			pilha.momentoDaInterrupcao = Date.now();
		},

		retomar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoExecucao.retormar().");
		},

		encerrar: function (pilha) {
			pilha.estado = new EstadoEncerrado();
			pilha.temporizador = global.clearTimeout(pilha.temporizador);
			pilha.funcaoDeRetorno(pilha.excecaoLancada);
		}
	});

	var EstadoInterrompido = new Class({
		iniciar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoInterrompido.iniciar().");
		},

		executar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoInterrompido.executar().");
		},

		interromper: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoInterrompido.interromper().");
		},

		retomar: function (pilha) {
			pilha.estado = new EstadoExecucao();
			var momentoDaRetomadaDaExecucao = Date.now();
			var tempoDeDuracaoDaInterrupcao = momentoDaRetomadaDaExecucao - pilha.momentoDaInterrupcao;
			var tempoPassadoDoTimeoutAnterior = pilha.momentoDaInterrupcao - pilha.momentoDoDisparoDoTimeout;
			pilha.tempoPassadoDoTimeout += (tempoPassadoDoTimeoutAnterior + tempoDeDuracaoDaInterrupcao);
			var tempoRestanteDoTimeout = (pilha.janelaDeTempo - pilha.tempoPassadoDoTimeout);
			if (tempoRestanteDoTimeout <= 0) {
				pilha.executar();
			} else {
				pilha.temporizador = global.setTimeout(function () {
					pilha.executar();
				}, tempoRestanteDoTimeout);
				pilha.momentoDoDisparoDoTimeout = momentoDaRetomadaDaExecucao;
			}
			Webis.executandoInterrupcao = false;
		},

		encerrar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoInterrompido.encerrar().");
		}
	});

	var EstadoEncerrado = new Class({
		iniciar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoEncerrado.iniciar().");
		},

		executar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoEncerrado.executar().");
		},

		interromper: function () {
			Webis.executandoInterrupcao = true;
		},

		retomar: function () {
			Webis.executandoInterrupcao = false;
		},

		encerrar: function () {
			throw new ExcecaoWebis("Erro na PilhaDeExecucao. EstadoEncerrado.encerrar().");
		}
	});

	var PilhaDeExecucao = new Class({
		janelaDeTempoPadrao: 0,

		initialize: function (funcaoDeRetorno) {
			this.pilhaDeComandos = [];
			this.temporizador = undefined;
			this.excecaoLancada = undefined;
			this.momentoDoDisparoDoTimeout = 0;
			this.momentoDaInterrupcao = 0;
			this.tempoPassadoDoTimeout = 0;
			this.janelaDeTempo = 0;
			this.estado = new EstadoNaoIniciado();
			this.funcaoDeRetorno = (funcaoDeRetorno !== undefined) ? funcaoDeRetorno : function () {};
		},

		iniciar: function () {
			this.estado.iniciar(this);
		},

		executar: function () {
			this.estado.executar(this);
		},

		interromper: function () {
			this.estado.interromper(this);
		},

		retomar: function () {
			this.estado.retomar(this);
		},

		encerrar: function () {
			this.estado.encerrar(this);
		},

		adicionarBloco: function (contexto, comandos) {
			var bloco = [];
			comandos.each(function (item) {
				bloco.push(function () {
					try {
						item.executar(contexto);
					} catch (excecao) {
						this.excecaoLancada = excecao;
						this.excecaoLancada.posicaoNoCodigo = Webis.posicaoDoSimboloExecutado;
						if (excecao.tipo === ExcecaoWebis.tipo) {
							global.postMessage({comando: "REPORTAR_ERRO", erro: this.excecaoLancada});
						} else {
							Webis.depurar("PilhaDeExecucao", excecao);
						}
						this.encerrar();
					}
				}.bind(this));
			}, this);
			this.pilhaDeComandos.unshift.apply(this.pilhaDeComandos, bloco);
		},

		adicionarAtividadeInterna: function (contexto, atividade) {
			this.adicionarBloco(contexto, [atividade]);
		},

		fixarJanelaDeTempo: function (novaJanelaDeTempo) {
			if (novaJanelaDeTempo >= 0) {
				this.janelaDeTempo = novaJanelaDeTempo;
			}
		},

		restaurarJanelaDeTempo: function () {
			this.janelaDeTempo = this.janelaDeTempoPadrao;
		}
	});

	global.PilhaDeExecucao = PilhaDeExecucao;
}(this));
