/*global AtividadeInterna*/
/*global Checagem*/
/*global ContextoDeLacoDeRepeticao*/
/*global TabelaDeSimbolos*/
/*global Webis*/

(function () {
	"use strict";

	Object.merge(TabelaDeSimbolos, {
		"contarGiro": function (contexto) {
			Checagem.deTipos([contexto], [ContextoDeLacoDeRepeticao], Checagem.obterMensagemDeUsoDeContarGiroInvalido()).checar();
			contexto.pilha.push(contexto.fornecerGiro());
		},

		"entãoSenão": function (contexto) {
			var blocoSenao = contexto.pilha.tirar();
			var blocoEntao = contexto.pilha.tirar();
			var condicao = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([condicao, blocoEntao, blocoSenao], [Array, Array, Array]).ou([condicao, blocoEntao, blocoSenao], [Boolean, Array, Array]).ou([condicao, blocoEntao, blocoSenao], [Number, Array, Array]).checar();
			var avaliacaoDeCondicao = new AtividadeInterna(function () {
				condicao.avaliar(contexto);
			});
			var execucao = new AtividadeInterna(function () {
				if (contexto.pilha.tirar()) {
					Webis.pilhaDeExecucao.adicionarBloco(contexto, blocoEntao);
				} else {
					Webis.pilhaDeExecucao.adicionarBloco(contexto, blocoSenao);
				}
			});
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, execucao);
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, avaliacaoDeCondicao);
		},

		"enquantoVerdade": function (contexto) {
			var contextoComContaGiro = contexto.criarContextoFilhoDeLacoDeRepeticao();
			var bloco = contexto.pilha.tirar();
			var condicao = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([condicao, bloco], [Array, Array]).ou([condicao, bloco], [Boolean, Array]).ou([condicao, bloco], [Number, Array]).checar();
			var atualizacaoDeContarGiro = new AtividadeInterna(function () {
				contextoComContaGiro.contarGiro();
			});
			var avaliacaoDeCondicao = new AtividadeInterna(function () {
				condicao.avaliar(contextoComContaGiro);
			});
			var execucao = new AtividadeInterna(function () {
				if (contextoComContaGiro.pilha.tirar()) {
					Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, execucao);
					Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, avaliacaoDeCondicao);
					Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, atualizacaoDeContarGiro);
					Webis.pilhaDeExecucao.adicionarBloco(contextoComContaGiro, bloco);
				}
			});
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, execucao);
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, avaliacaoDeCondicao);
		},

		"executar": function (contexto) {
			Webis.pilhaDeExecucao.adicionarBloco(contexto, contexto.pilha.tirar());
		},

		"seVerdade": function (contexto) {
			var bloco = contexto.pilha.tirar();
			var condicao = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([condicao, bloco], [Array, Array]).ou([condicao, bloco], [Boolean, Array]).ou([condicao, bloco], [Number, Array]).checar();
			var avaliacaoDeCondicao = new AtividadeInterna(function () {
				condicao.avaliar(contexto);
			});
			var execucao = new AtividadeInterna(function () {
				if (contexto.pilha.tirar()) {
					Webis.pilhaDeExecucao.adicionarBloco(contexto, bloco);
				}
			});
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, execucao);
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, avaliacaoDeCondicao);
		},

		"seFalso": function (contexto) {
			var bloco = contexto.pilha.tirar();
			var condicao = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([condicao, bloco], [Array, Array]).ou([condicao, bloco], [Boolean, Array]).ou([condicao, bloco], [Number, Array]).checar();
			var avaliacaoDeCondicao = new AtividadeInterna(function () {
				condicao.avaliar(contexto);
			});
			var execucao = new AtividadeInterna(function () {
				if (!contexto.pilha.tirar()) {
					Webis.pilhaDeExecucao.adicionarBloco(contexto, bloco);
				}
			});
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, execucao);
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, avaliacaoDeCondicao);
		},

		"vezesRepetir": function (contexto) {
			var contextoComContaGiro = contexto.criarContextoFilhoDeLacoDeRepeticao();
			var quantidadeDeVezes = contexto.pilha.tirar();
			var bloco = contexto.pilha.tirar();
			Checagem.deTiposDeParametros([bloco, quantidadeDeVezes], [Array, Number]).checar();
			var atualizacaoDeContaGiro = new AtividadeInterna(function () {
				contextoComContaGiro.contarGiro();
			});
			var indice;
			for (indice = 1; indice <= quantidadeDeVezes; indice = indice + 1) {
				Webis.pilhaDeExecucao.adicionarAtividadeInterna(contextoComContaGiro, atualizacaoDeContaGiro);
				Webis.pilhaDeExecucao.adicionarBloco(contextoComContaGiro, bloco);
			}
		}
	});
}());
