/*global Class*/
/*global Crafty*/
/*global Ecossistema*/
/*global Grafico*/
/*global Grafico2D*/
/*global Simbolo*/
/*global Som*/
/*global Som3D*/
/*global XMLHttpRequest*/
/*global Worker*/
/*global AudioContext*/
/*global webkitAudioContext*/
/*global mozAudioContext*/
/*global oAudioContext*/
/*global msAudioContext*/
/*global console*/
/*global document*/
/*global location*/

(function (global) {
	"use strict";

	var Teclado = {
		tabelaDeTeclas: {},

		inicializar: function () {
			global.addEventListener("keydown", this.tratarTeclaPressionada.bind(this));
			global.addEventListener("keyup", this.tratarTeclaSolta.bind(this));
		},

		tratarTeclaPressionada: function (evento) {
			var simboloDeEstimuloTeclado = new Simbolo("TECLADO");
			var teclasModificadoras = this.calcularTeclasModificadoras(evento);
			var tecla = evento.keyCode;
			var nomeDoEvento = null;
			if (this.tabelaDeTeclas[tecla] !== undefined && this.tabelaDeTeclas[tecla].pressionada) {
				nomeDoEvento = "teclaRepetida";
			} else {
				this.tabelaDeTeclas[tecla] = {pressionada: true};
				nomeDoEvento = "teclaPressionada";
			}
			var listaDita = [simboloDeEstimuloTeclado, nomeDoEvento, tecla, teclasModificadoras];
			Ecossistema.DIZER({listaDita: listaDita});
		},

		tratarTeclaSolta: function (evento) {
			var simboloDeEstimuloTeclado = new Simbolo("TECLADO");
			var teclasModificadoras = this.calcularTeclasModificadoras(evento);
			var tecla = evento.keyCode;
			this.tabelaDeTeclas[tecla] = {pressionada: false};
			var listaDita = [simboloDeEstimuloTeclado, "teclaSolta", tecla, teclasModificadoras];
			Ecossistema.DIZER({listaDita: listaDita});
		},

		calcularTeclasModificadoras: function (evento) {
			var teclasModificadoras = 0;
			teclasModificadoras += (evento.shiftKey) ? 1 : 0;
			teclasModificadoras += (evento.crtlKey) ? 2 : 0;
			teclasModificadoras += (evento.altKey) ? 8 : 0;
			return teclasModificadoras;
		}
	};

	var Visao = {
		mostrarMensagem: function (mensagem) {
			var mensagens = document.querySelector("ul#mensagens");
			var mensagemInserida = document.createElement("li");
			mensagemInserida.innerHTML = mensagem;
			mensagens.insertBefore(mensagemInserida, mensagens.firstChild);
			mensagemInserida.tabIndex = -1;
			mensagemInserida.focus();
		},

		mostrarMensagemDeErro: function (mensagem, posicaoNoCodigo) {
			var linha = posicaoNoCodigo.linha;
			var coluna = posicaoNoCodigo.coluna;
			var parametros = String.formatar("?linha=%@&coluna=%@", linha, coluna);
			var uriDoErro = location.pathname.replace("/aplique.html", parametros);
			var mensagemFinal = String.formatar('%@ <a href="%@">Linha: %@. Coluna: %@.</a>', mensagem, uriDoErro, linha, coluna);
			this.mostrarMensagem(mensagemFinal);
		},

		depurar: function (escopo, mensagem) {
			console.log(String.formatar("[%@] %@", escopo, mensagem));
		},

		fornecerMensagemDeExcecao: function (tipo, mensagem, arquivo, linha) {
			return String.formatar("%@: %@. %@: %@.", tipo, mensagem, arquivo, linha);
		},

		fornecerMensagemDeModeloInexistente: function (nomeDoModelo) {
			return String.formatar("Não foi possível criar o ator. O modelo %@ não existe.", nomeDoModelo);
		},

		fornecerMensagemDeComandoInexistente: function (comando) {
			return String.formatar("Comando %@ não encontrado.", comando);
		},

		fornecerMensagemDeSomNaoCarregado: function (uri) {
			return String.formatar('Não foi possível carregar o som <a href="%@">%@</a>. Certifique-se de que o endereço esteja correto.', uri, uri);
		}
	};

	var Som3DPadrao = {
		contexto: null,

		atorComMicrofone: null,

		calibragemDeSom: 0.01,

		inicializar: function () {
			this.contexto = this.criarContextoDeAudio();
			this.contexto.listener.setPosition(0, 0, 0);
			this.contexto.listener.setOrientation(0, 1, 0, 0, 0, 1);
			this.contexto.listener.setVelocity(0, 0, 0);
		},

		moverOuvinte: function (posicao, direcao, velocidade) {
			this.contexto.listener.setPosition(posicao.x, posicao.y, posicao.z);
			this.contexto.listener.setOrientation(direcao.x, direcao.y, direcao.z, 0, 0, 1);
			this.contexto.listener.setVelocity(velocidade.x, velocidade.y, velocidade.z);
		},

		calibrarSom: function (calibragemDeSom) {
			this.calibragemDeSom = calibragemDeSom;
		},

		pegarMicrofone: function (ator) {
			if (this.atorComMicrofone !== null) {
				this.atorComMicrofone.largarMicrofone();
			}
			this.atorComMicrofone = ator;
			this.atorComMicrofone.pegarMicrofone();
		},

		carregarSom: function (uri, funcaoDeRetorno, posicaoNoCodigo) {
			var requisicao = new XMLHttpRequest();
			var somExterno = /^http(s)?:\/\//.test(uri);
			var somInterno = (uri.match("/som/") !== null);
			var uriOriginal = uri;
			uri = (somExterno && !somInterno) ? ("../../../som?endereco=" + uri) : uri;
			requisicao.open("GET", uri, true);
			requisicao.responseType = "arraybuffer";
			requisicao.addEventListener("load", function () {
				this.contexto.decodeAudioData(requisicao.response, funcaoDeRetorno, function () {
					this.reportarErroDeCarregamentoDeSom(uriOriginal, posicaoNoCodigo);
				}.bind(this));
			}.bind(this));
			requisicao.addEventListener("error", function () {
				this.reportarErroDeCarregamentoDeSom(uriOriginal, posicaoNoCodigo);
			}.bind(this));
			requisicao.send();
		},

		reportarErroDeCarregamentoDeSom: function (uriOriginal, posicaoNoCodigo) {
			Visao.mostrarMensagemDeErro(Visao.fornecerMensagemDeSomNaoCarregado(uriOriginal), posicaoNoCodigo);
		},

		transformarVetorWebisParaVetorSom3D: function (vetorWebis) {
			var vetorSom3D = {};
			vetorSom3D.x = vetorWebis.x * this.calibragemDeSom;
			vetorSom3D.y = vetorWebis.y * this.calibragemDeSom;
			vetorSom3D.z = vetorWebis.z * this.calibragemDeSom;
			return vetorSom3D;
		},

		criarContextoDeAudio: function () {
			if (typeof webkitAudioContext === "function") {
				return new webkitAudioContext();
			} else if (typeof mozAudioContext === "function") {
				return new mozAudioContext();
			} else if (typeof oAudioContext === "function") {
				return new oAudioContext();
			} else if (typeof msAudioContext === "function") {
				return new msAudioContext();
			} else if (typeof AudioContext === "function") {
				return new AudioContext();
			} else {
				return null;
			}
		}
	};

	var Grafico2DPadrao = {
		contexto: null,

		canvas: null,

		inicializar: function () {
			Crafty.init(900, 600);
			Crafty.background("rgb(127, 127, 127)");
			Crafty.e("Canvas");
			this.canvas = document.querySelector("canvas");
			this.contexto = this.canvas.getContext("2d");
		},

		transformarVetorWebisParaVetorGrafico2D: function (vetorWebis, tamanho) {
			var vetorGrafico2D = {};
			vetorGrafico2D.x = vetorWebis.x + (this.canvas.width / 2) + (tamanho.largura / 2);
			vetorGrafico2D.y = -vetorWebis.y + (this.canvas.height / 2) - (tamanho.altura / 2);
			vetorGrafico2D.z = 0;
			return vetorGrafico2D;
		}
	};

	var SomPadrao = new Class({
		initialize: function () {
			this.som = null;
			this.fonteDeSom = null;
			this.ajusteEspacial = null;
			this.temporizadorDeDesligamento = null;
			this.mudo = true;
			this.tocando = false;
			this.repeticao = false;
			this.carregandoMicrofone = false;
			this.vivo = true;
		},

		mover: function (posicaoWebis, direcaoWebis, velocidadeWebis) {
			var posicaoSom3D = Som3D.transformarVetorWebisParaVetorSom3D(posicaoWebis);
			var direcaoSom3D = Som3D.transformarVetorWebisParaVetorSom3D(direcaoWebis);
			var velocidadeSom3D = Som3D.transformarVetorWebisParaVetorSom3D(velocidadeWebis);
			if (!this.mudo && this.tocando) {
				this.ajusteEspacial.setPosition(posicaoSom3D.x, posicaoSom3D.y, posicaoSom3D.z);
				this.ajusteEspacial.setOrientation(direcaoSom3D.x, direcaoSom3D.y, direcaoSom3D.z);
				this.ajusteEspacial.setVelocity(velocidadeSom3D.x, velocidadeSom3D.y, velocidadeSom3D.z);
			}
			if (this.carregandoMicrofone) {
				Som3D.moverOuvinte(posicaoSom3D, direcaoSom3D, velocidadeSom3D);
			}
		},

		tocar: function (posicaoWebis, direcaoWebis, velocidadeWebis, som, repeticao) {
			this.parar();
			this.som = som;
			this.repeticao = (repeticao && this.vivo);
			if (!this.mudo) {
				global.clearTimeout(this.temporizadorDeDesligamento);
				this.fonteDeSom = Som3D.contexto.createBufferSource();
				this.ajusteEspacial = Som3D.contexto.createPanner();
				this.fonteDeSom.connect(this.ajusteEspacial);
				this.ajusteEspacial.connect(Som3D.contexto.destination);
				this.fonteDeSom.buffer = this.som;
				this.fonteDeSom.loop = this.repeticao;
				this.fonteDeSom.noteOn(0);
				this.tocando = true;
				this.mover(posicaoWebis, direcaoWebis, velocidadeWebis);
				if (!this.repeticao) {
					var duracaoDoSom = (this.fonteDeSom.buffer.duration * 1000);
					this.temporizadorDeDesligamento = global.setTimeout(this.parar.bind(this), duracaoDoSom);
				}
			}
		},

		parar: function () {
			if (this.tocando) {
				this.tocando = false;
				this.fonteDeSom.noteOff(0);
			}
		},

		comSom: function (posicaoWebis, direcaoWebis, velocidadeWebis) {
			this.mudo = false;
			if (this.som && !this.tocando) {
				this.tocar(posicaoWebis, direcaoWebis, velocidadeWebis, this.som, this.repeticao);
			}
		},

		semSom: function () {
			this.mudo = true;
			this.parar();
		},

		pegarMicrofone: function () {
			this.carregandoMicrofone = true;
		},

		largarMicrofone: function () {
			this.carregandoMicrofone = false;
		},

		suicidar: function () {
			this.vivo = false;
			var duracaoDoSom = (this.fonteDeSom !== null) ? (this.fonteDeSom.buffer.duration * 1000) : 0;
			this.temporizadorDeDesligamento = global.setTimeout(this.parar.bind(this), duracaoDoSom);
		}
	});

	var GraficoPadrao = new Class({
		initialize: function (posicaoWebis) {
			this.tamanho = {altura: 50, largura: 50};
			this.rotacao = 90;
			this.cor = "rgb(" + [Math.floor(Math.random() * 256), Math.floor(Math.random() * 256), Math.floor(Math.random() * 256)].join(",") + ")";
			this.entidadeCrafty = Crafty.e("2D, Canvas, Color");
			this.entidadeCrafty.init();
			this.entidadeCrafty.w = this.tamanho.largura;
			this.entidadeCrafty.h = this.tamanho.altura;
			this.entidadeCrafty.rotation = this.rotacao;
			this.invisivel();
			this.mover(posicaoWebis);
			this.entidadeCrafty.color(this.cor);
		},

		mover: function (posicaoWebis) {
			var posicaoGrafico2D = Grafico2D.transformarVetorWebisParaVetorGrafico2D(posicaoWebis, this.tamanho);
			this.entidadeCrafty.x = posicaoGrafico2D.x;
			this.entidadeCrafty.y = posicaoGrafico2D.y;
			this.entidadeCrafty.z = posicaoGrafico2D.z;
		},

		visivel: function () {
			this.entidadeCrafty.visible = true;
		},

		invisivel: function () {
			this.entidadeCrafty.visible = false;
		},

		carimbar: function (posicaoWebis) {
			this.entidadeCrafty.clone();
		},

		suicidar: function () {
			this.entidadeCrafty.destroy();
			delete this.entidadeCrafty;
		}
	});

	var AtorMarionetePadrao = new Class({
		initialize: function (endereco) {
			this.trabalhador = new Worker(endereco);
			this.posicao = {x: 0, y: 0, z: 0};
			this.direcao = {x: 0, y: 1, z: 0};
			this.velocidade = {x: 0, y: 0, z: 0};
			this.som = new Som();
			this.grafico = new Grafico(this.posicao);
		},

		tratarMensagem: function (tratador, escopo) {
			this.trabalhador.addEventListener("message", tratador.bind(escopo));
		},

		tratarErro: function (tratador, escopo) {
			this.trabalhador.addEventListener("error", tratador.bind(escopo));
		},

		enviarMensagem: function (mensagem) {
			this.trabalhador.postMessage(mensagem);
		},

		mover: function (posicao, direcao, velocidade) {
			this.posicao = posicao;
			this.direcao = direcao;
			this.velocidade = velocidade;
			this.som.mover(this.posicao, this.direcao, this.velocidade);
			this.grafico.mover(this.posicao);
		},

		tocar: function (som, repeticao) {
			this.som.tocar(this.posicao, this.direcao, this.velocidade, som, repeticao);
		},

		comSom: function () {
			this.som.comSom(this.posicao, this.direcao, this.velocidade);
		},

		semSom: function () {
			this.som.semSom();
		},

		pegarMicrofone: function () {
			this.som.pegarMicrofone();
		},

		largarMicrofone: function () {
			this.som.largarMicrofone();
		},

		visivel: function () {
			this.grafico.visivel();
		},

		invisivel: function () {
			this.grafico.invisivel();
		},

		carimbar: function () {
			this.grafico.carimbar();
		},

		suicidar: function () {
			this.trabalhador.terminate();
			this.som.suicidar(this.posicao, this.direcao, this.velocidade);
			this.grafico.suicidar();
		}
	});

	var Som3DBurro = {
		contexto: null,

		calibragemDeSom: null,

		inicializar: function () {},

		moverOuvinte: function () {},

		calibrarSom: function () {},

		carregarSom: function () {},

		transformarVetorWebisParaVetorSom3D: function () {}
	};

	var Grafico2DBurro = {
		contexto: null,

		canvas: null,

		inicializar: function () {},

		transformarVetorWebisParaVetorGrafico2D: function () {}
	};

	var SomBurro = new Class({
		initialize: function () {},

		mover: function () {},

		tocar: function () {},

		parar: function () {},

		comSom: function () {},

		semSom: function () {},

		pegarMicrofone: function () {},

		largarMicrofone: function () {},

		suicidar: function () {}
	});

	var GraficoBurro = new Class({
		initialize: function () {},

		mover: function () {},

		visivel: function () {},

		invisivel: function () {},

		carimbar: function () {},

		suicidar: function () {}
	});

	var AtorMarioneteBurro = new Class({
		initialize: function () {},

		enviarMensagem: function () {},

		mover: function () {},

		tocar: function () {},

		comSom: function () {},

		semSom: function () {},

		pegarMicrofone: function () {},

		largarMicrofone: function () {},

		visivel: function () {},

		invisivel: function () {},

		carimbar: function () {},

		suicidar: function () {}
	});

	global.AtorMarionetePadrao = AtorMarionetePadrao;
	global.Som3DPadrao = Som3DPadrao;
	global.Grafico2DPadrao = Grafico2DPadrao;
	global.SomPadrao = SomPadrao;
	global.GraficoPadrao = GraficoPadrao;
	global.AtorMarioneteBurro = AtorMarioneteBurro;
	global.Som3DBurro = Som3DBurro;
	global.Grafico2DBurro = Grafico2DBurro;
	global.SomBurro = SomBurro;
	global.GraficoBurro = GraficoBurro;
	global.Teclado = Teclado;
	global.Visao = Visao;
}(this));
