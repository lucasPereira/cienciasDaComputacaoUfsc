/*global Ator*/
/*global TabelaDeSimbolos*/

(function (global) {
	"use strict";

	function enviarMensagemParaOEcossistema(mensagem) {
		global.postMessage({comando: mensagem, identificadorDoAtor: Ator.identificador});
	}

	Object.merge(TabelaDeSimbolos, {
		"carimbar": function (contexto) {
			enviarMensagemParaOEcossistema("CARIMBAR");
		},

		"invisível": function (contexto) {
			Ator.visivel = false;
			enviarMensagemParaOEcossistema("INVISIVEL");
		},

		"visível": function (contexto) {
			Ator.visivel = true;
			enviarMensagemParaOEcossistema("VISIVEL");
		}
	});
}(this));
