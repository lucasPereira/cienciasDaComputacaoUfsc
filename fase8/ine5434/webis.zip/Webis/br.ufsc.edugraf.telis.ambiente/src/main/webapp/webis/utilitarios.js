/*global AtividadeInterna*/
/*global Checagem*/
/*global TabelaDeSimbolos*/
/*global Webis*/

(function (global) {
	"use strict";

	Object.merge(TabelaDeSimbolos, {
		"descansar": function (contexto) {
			var tempoEmSegundos = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(tempoEmSegundos, Number).checar();
			var restaurarJanelaDeTempo = new AtividadeInterna(function () {
				Webis.pilhaDeExecucao.restaurarJanelaDeTempo();
			});
			Webis.pilhaDeExecucao.fixarJanelaDeTempo(tempoEmSegundos * 1000);
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(contexto, restaurarJanelaDeTempo);
		},

		"gerarAleatório": function (contexto) {
			var limites = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(limites, Array).ou(limites, Number).checar();
			if (global.instanceOf(limites, Number)) {
				limites = [limites, 1];
			}
			Checagem.deValor(limites.length, 2, Checagem.obterMensagemDeListaComIntervalosInvalida()).checar();
			Checagem.deTipo(limites[0], Number, Checagem.obterMensagemDeListaComIntervalosInvalida()).checar();
			Checagem.deTipo(limites[1], Number, Checagem.obterMensagemDeListaComIntervalosInvalida()).checar();
			var limiteSuperior = Math.max.apply(null, limites);
			var limiteInferior = Math.min.apply(null, limites);
			contexto.pilha.push(Math.floor(Math.random() * (limiteSuperior - limiteInferior + 1)) + Math.ceil(limiteInferior));
		}
	});
}(this));
