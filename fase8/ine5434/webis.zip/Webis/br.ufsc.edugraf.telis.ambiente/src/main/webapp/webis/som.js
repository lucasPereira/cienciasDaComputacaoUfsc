/*global Ator*/
/*global Checagem*/
/*global TabelaDeSimbolos*/
/*global Webis*/

(function (global) {
	"use strict";

	Object.merge(TabelaDeSimbolos, {
		"calibrarSom": function (contexto) {
			var calibragemDeSom = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(calibragemDeSom, Number).checar();
			global.postMessage({comando: "CALIBRAR_SOM", calibragemDeSom: calibragemDeSom});
		},

		"comSom": function (contexto) {
			Ator.comSom = true;
			global.postMessage({comando: "COM_SOM", identificadorDoAtor: Ator.identificador});
		},

		"fixarSom": function (contexto) {
			var uri = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(uri, String).checar();
			global.postMessage({comando: "FIXAR_SOM", uri: uri, identificadorDoAtor: Ator.identificador, posicaoNoCodigo: Webis.posicaoDoSimboloExecutado});
		},

		"fixarSomContínuo": function (contexto) {
			var uri = contexto.pilha.tirar();
			Checagem.deTipoDeParametro(uri, String).checar();
			global.postMessage({comando: "FIXAR_SOM_CONTINUO", uri: uri, identificadorDoAtor: Ator.identificador, posicaoNoCodigo: Webis.posicaoDoSimboloExecutado});
		},

		"pegarMicrofone": function (contexto) {
			global.postMessage({comando: "PEGAR_MICROFONE", identificadorDoAtor: Ator.identificador});
		},

		"semSom": function (contexto) {
			Ator.comSom = false;
			global.postMessage({comando: "SEM_SOM", identificadorDoAtor: Ator.identificador});
		}
	});
}(this));
