/*global AtividadeInterna*/
/*global Checagem*/
/*global Class*/
/*global TabelaDeAgendas*/
/*global TabelaDeSimbolos*/
/*global Util*/
/*global Webis*/

(function (global) {
	"use strict";

	var Agenda = new Class({
		initialize: function (comandos) {
			this.tipo = "Agenda";
			this.comandos = comandos;
		},

		executar: function (contexto) {
			var meuContexto = contexto.criarContextoFilhoDeAgenda();
			var copiarPilha = new AtividadeInterna(function () {
				contexto.pilha.push.apply(contexto.pilha, meuContexto.pilha);
			});
			Webis.pilhaDeExecucao.adicionarAtividadeInterna(meuContexto, copiarPilha);
			Webis.pilhaDeExecucao.adicionarBloco(meuContexto, this.comandos);
		},

		comoTexto: function () {
			return String.formatar("agenda: %@", Util.obterRepresentacaoTextual(this.comandos));
		},

		comoTextoWebis: function () {
			return String.formatar("agenda: %@", Util.obterRepresentacaoTextualWebis(this.comandos));
		}
	});

	Agenda.extend({
		tipo: "Agenda"
	});

	Object.merge(TabelaDeAgendas, {
		"iniciar": new Agenda([])
	});

	Object.merge(TabelaDeSimbolos, {
		"incluirAgenda": function (contexto) {
			var agenda = contexto.pilha.tirar(contexto);
			var nome = contexto.pilha.tirar(contexto);
			Checagem.deTiposDeParametros([nome, agenda], [String, Array]).checar();
			TabelaDeAgendas[nome] = new Agenda(agenda);
		}
	});

	global.Agenda = Agenda;
}(this));
