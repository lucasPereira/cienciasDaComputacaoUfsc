package models

import akka.actor.Actor

// ator responsável pela geração e validação de tokens
class GerenciadorDeTokens extends Actor {
  import Dados._
  import Msgs._
  
  // próximo token a ser gerado
  var idToken = 1
  
  // armazena os tokens já gerados
  var tokensGerados: List[Token] = List()

  // método que define o comportamento do ator
  override def receive = {
    
    // alguém solicitou que um novo token fosse gerado
    case GereNovoToken => {
      val token = Token(idToken)
      sender ! TokenGerado(token)
      tokensGerados = token :: tokensGerados
      idToken += 1
    }
    
    // algumém solicitou que o token t fosse validado
    // Se o token t for válido então quem solicitou a validação
    // receberá a mensagem TokenValido e, caso contrário,
    // receberá a mensagem TokenInvalido
    case ValideToken(t) => {
      if (tokensGerados.contains(t))
        sender ! TokenValido(t)
      else
        sender ! TokenInvalido(t)
    }
  }
}