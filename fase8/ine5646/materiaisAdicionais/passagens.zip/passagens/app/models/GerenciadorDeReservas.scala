package models

import akka.actor.Actor

// ator responsável por gerenciar as reservas
class GerenciadorDeReservas extends Actor {
  import Dados._
  import Msgs._

  //Map[assento,reserva]
  var lugares: Map[Int, Reserva] = Map(1 -> Reserva(1,None), 2 -> Reserva(2, None), 3 -> Reserva(3, None), 4 -> Reserva(4, None))

  override def receive = {

    // alguém solicitou que o assento fosse reservado para token.
    // caso o assento já estiver reservado então quem solicitou receberá a mensagem ReservaRejeitada.
    // caso o assento estiver livre (valor None) então a reserva será feita e quem soliciou receberá a mensagem ReservaConfirmada 
    case EfetueReserva(token, assento) => {
      val novaReserva = Reserva(assento, Some(token))
      val reserva = lugares(assento)
      reserva.optToken match {
        case Some(_) => sender ! ReservaRejeitada(novaReserva)
        case None => {
          lugares = lugares + (assento -> novaReserva)
          sender ! ReservaConfirmada(novaReserva)
        }
      }
    }

    // alguém solicitou que o assento reservado ao token fosse liberado
    // caso não haja token (valor None) para o assento então quem solicitou receberá a mensagem ReservaInexistente
    // caso o assento esteja reservado para outro token então quem solicitou receberá a mensagem ReservaDeOutroUsuario
    // caso o assento esteja reservado para o token então o assento volta a ficar disponível (Reserva(assento,None)) e
    //quem solicitou receberá a mensagem ReservaLiberada
    case LibereReserva(token, assento) => {
      val reservaASerRemovida = Reserva(assento, Some(token))
      val reserva = lugares(assento)
      reserva match {
        case Reserva(_, None) => sender ! ReservaInexistente(reservaASerRemovida)
        case Reserva(assento, Some(Token(id))) if id != token.id => sender ! ReservaDeOutroUsuario(reservaASerRemovida)
        case Reserva(assento, Some(token)) => {
          lugares = lugares + (assento -> Reserva(assento, None))
          sender ! ReservaLiberada(reserva)
        }
      }
    }

    // alguém solicitou que fosse verificada a situação de um assento
    // se o assento não existir (não houver uma Reserva associada à chave assento) então quem solicitou receberá a mensagem AssentoInexistente
    // caso não haja token (valor None) associado à reserva então quem solicitou receberá a mensagem AssentoDisponivel
    // caso contrário (indicado por "_") quem solicitou receberá a mensagem AssentoReservado
    case VerifiqueAssento(assento) => {
      if (!lugares.isDefinedAt(assento))
        sender ! AssentoInexistente(assento)
      else {
        val reserva = lugares(assento)
        reserva.optToken match {
          case None => sender ! AssentoDisponivel(assento)
          case _ => sender ! AssentoJaReservado(assento)
        }
      }
    }
    
    // alguém solicitou que fossem enviadas todas as reservas.
    //Obs: se reserva for None o assento está livre; se for Some(_) então o assento está reservado par algum token
    case EnvieReservas => {
      sender ! RecebaReservas(lugares.values.toList)
    }
    
  }
}