package models

// o objeto Msgs define as mensagens enviadas para os atores e pelos atores
object Msgs {
  import Dados._
  
  case object GereNovoToken
  case class TokenGerado(token: Token)
  case class ValideToken(token: Token)
  
  // um trait Scala é equivalente ao conceito de interface de Java
  trait SituacaoToken
  case class TokenValido(token: Token) extends SituacaoToken
  case class TokenInvalido(token: Token) extends SituacaoToken

  case class EfetueReserva(t: Token, assento: Int)
  case class LibereReserva(t: Token, assento: Int)
  
  case class VerifiqueAssento(assento: Int)
  case object EnvieReservas
  case class RecebaReservas(reservas: List[Reserva])

  trait SituacaoAssento
  case class AssentoJaReservado(assento: Int) extends SituacaoAssento
  case class AssentoDisponivel(assento: Int) extends SituacaoAssento
  case class AssentoInexistente(assento: Int) extends SituacaoAssento

  trait SituacaoReserva
  case class ReservaConfirmada(r: Reserva) extends SituacaoReserva
  case class ReservaRejeitada(r: Reserva) extends SituacaoReserva  
  case class ReservaLiberada(r: Reserva) extends SituacaoReserva
  case class ReservaInexistente(r: Reserva) extends SituacaoReserva
  case class ReservaDeOutroUsuario(r: Reserva) extends SituacaoReserva
}