package models

// o objeto Dados define os dados do problema.
object Dados {
  // um token é caracterizado pelo seu id
  // obs: em uma aplicação real o token seria mais sofisticado e conteria, por exemplo, dados do usuário, data de criação, etc
  case class Token(id: Int)
  
  // uma reserva identifica o assento e o token associado
  // se o token for None o assento está livre e se for Some(Token(n)) estará reservado para o token com id igual a n
  case class Reserva(assento: Int, optToken: Option[Token])
}