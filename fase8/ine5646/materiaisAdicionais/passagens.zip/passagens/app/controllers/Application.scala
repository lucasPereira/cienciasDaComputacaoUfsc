package controllers

import scala.concurrent.Future
import scala.concurrent.duration.DurationInt
import akka.actor.Props
import akka.pattern.ask
import akka.util.Timeout
import models.Dados.Token
import models.Dados.Reserva
import models.GerenciadorDeReservas
import models.GerenciadorDeTokens
import models.Msgs._
import play.api.Play.current
import play.api.libs.concurrent.Akka
import play.api.libs.concurrent.Execution.defaultContext
import play.api.libs.json.Json
import play.api.libs.json.Json.toJsFieldJsValueWrapper
import play.api.mvc.Action
import play.api.mvc.Controller
import models.Msgs.RecebaReservas
import play.api.libs.json.JsValue

object Application extends Controller {
  // ator responsável por gerenciar tokens
  val gerenciadorDeTokens = Akka.system.actorOf(Props[GerenciadorDeTokens])

  // ator responsável por gerenciar reservas
  val gerenciadorDeReservas = Akka.system.actorOf(Props[GerenciadorDeReservas])

  // timeout: tempo que um future esperará por uma resposta do ator
  // utiliza-se implicit para não precisar ficar passando este parâmetro onde ele é necessário
  implicit val timeout = Timeout(2.second)

  // executionContext:  onde (thread) o future será executado
  // utiliza-se implicit para não ficar passando este parâmetro onde ele é necessário
  implicit val executionContext = defaultContext

  val tabelaMsgsFazerReserva = Map(
    0 -> "token inválido e assento inexistente",
    1 -> "token inválido",
    2 -> "assento inexistente",
    3 -> "reserva efetuada",
    4 -> "reserva rejeitada (assento já reservado)")

  val tabelaMsgsLiberarReserva = Map(
    0 -> "token inválido e assento inexistente",
    1 -> "token inválido",
    2 -> "assento inexistente",
    3 -> "reserva liberada",
    4 -> "o assento não estava reservado",
    5 -> "a reserva pertence a outro usuário")

  val tabelaMsgsSituacaoAssento = Map(
    0 -> "assento já está reservado",
    1 -> "assento está disponível",
    2 -> "não existe assento com o número solicitado")

  // mostra a página da aplicação
  //TODO : o conteúdo desta página deve ser alterado para definir a camada 1 da aplicação
  def index = Action {
    Ok(views.html.index())
  }

  //
  // o usuário solicitou que fosse gerado um novo token
  // 
  // o uso do método async faz com que o método soliciteToken seja executado rapidamente. Assim,
  // mesmo que o ator demore muito tempo para responder a thread que está executando este método 
  // logo ficará liberada para atender uma nova requisição HTTP.

  def soliciteToken = Action.async {

    // Descrição das variáveis:

    // futureTokenGerado
    // Conterá, em algum momento no futuro, a mensagem (objeto da classe) TokenGerado que será enviada pelo 
    // ator gerenciadorDeTokens como resposta à mensagem GereNovoToken que lhe foi enviada.

    // futureJSON
    // Conterá, em algum momento no futuro, o objeto JSON construído a partir do token enviado pelo ator.
    // Exemplo de objeto JSON: {"id" : "3"}

    // futureResposta
    // Conterá, em algum momento no futuro, a resposta HTTP a ser enviada ao browser. Esta resposta
    // contém o objeto JSON gerado.

    val futureTokenGerado = ask(gerenciadorDeTokens, GereNovoToken).mapTo[TokenGerado]

    val futureJSON = futureTokenGerado.map(tokenGerado => Json.obj("id" -> tokenGerado.token.id.toString))

    val futureResposta = futureJSON.map(objetoJSON => Ok(objetoJSON))

    futureResposta
  }

  
  
  //
  // o usuário solicitou que o assento fosse reservado para o token.
  // a reserva só poderá ser feita se as seguintes condições forem satisfeitas: 
  //      a) o token for válido; 
  //      b) o assento existir; 
  //      c) o assento estiver livre
  //

  def soliciteReserva(idToken: Int, assento: Int) = Action.async {

    // descrição das variáveis:
    
    // futureValideToken
    // Em algum momento futuro conterá a resposta (objeto da classe SituacaoToken) enviada pelo
    // ator gerenciadorDeTokens
    
    // futureValideAssento
    // Em algum momento futuro conterá a resposta (objeto da classe SituacaoAssento) enviada pelo
    // ator gerenciadorDeReservas
    
    // futureSitTokenSitAssento
    // Em algum momento futuro conterá a situação do token e do assento. A variável existe porque
    // é necessário obter a resposta dos dois atores que, por definição, são independentes e podem
    // produzir suas respostas em momentos diferentes. Quando esta variável tiver um valor temos
    // certeza que os dois atores já enviaram suas respostas.
    
    // futureOptCodErro
    // Em algum momento no futuro conterá ou um código de erro (indicando que a consulta não é
    // válida) ou nada (None) indicando que a reserva pode ser feita
    
    // futureCodFinal
    // Em algum momento no futuro conterá o código final da operação (seja código de erro ou de sucesso)
    
    // As duas verificações são feitas em paralelo
    val futureValideToken = ask(gerenciadorDeTokens, ValideToken(Token(idToken))).mapTo[SituacaoToken]
    val futureValideAssento = ask(gerenciadorDeReservas, VerifiqueAssento(assento)).mapTo[SituacaoAssento]

    

    val futureSitTokenSitAssento = for {
      sitToken <- futureValideToken
      sitAssento <- futureValideAssento
    } yield (sitToken, sitAssento)

    
    
    val futureOptCodErro = futureSitTokenSitAssento map (sitToken_sitAssento => sitToken_sitAssento match {
      // caso o token seja inválido e o assento seja inexistente então o código de erro é 0
      case (TokenInvalido(_), AssentoInexistente(_)) => Some(0)
      // caso apenas o token seja inválido então o código de erro é 1
      case (TokenInvalido(_), _) => Some(1)
      // caso apenso o assento seja inexistente então o código de erro é 2
      case (_, AssentoInexistente(_)) => Some(2)
      // caso contrário, ou seja o token é válido e o assento existe, então não há código de erro
      case _ => None
    })

    val futureCodFinal = futureOptCodErro flatMap (optCodigo => optCodigo match {
      case Some(codigoDeErro) => Future.successful(codigoDeErro)
      case None => {
        // a variável abaixo conterá, em algum momento no futuro, a resposta enviada pelo ator gerenciadorDeReservas
        val futSituacaoReserva = ask(gerenciadorDeReservas, EfetueReserva(Token(idToken), assento)).mapTo[SituacaoReserva]
        
        // quando a resposta chegar então analise-a e defina qual é o código que representa o resultado da operação de reserva
        futSituacaoReserva.map(situacao => situacao match {
          case ReservaConfirmada(_) => 3
          case ReservaRejeitada(_) => 4
        })

      }
    })

    // quando o código final da operação for conhecido então gere a resposta a ser enviada para o browser
    futureCodFinal map (codigo => gereResposta(codigo, tabelaMsgsFazerReserva))
  }

  // a resposta HTTP será uma "página" (gerada pelo objeto Ok) contendo um objeto JSON (variável obj)
  private def gereResposta(codigo: Int, tabelaMsgs: Map[Int, String]) = {
    val obj = Json.obj("cod" -> codigo.toString, "descricao" -> tabelaMsgs(codigo))
    Ok(obj)
  }

  // o usuário solcitou a liberação da reserva de um assento
  // o algoritmo segue a mesma estratégia do método soliciteReserva
  def libereReserva(idToken: Int, assento: Int) = Action.async {

    val futValideToken = ask(gerenciadorDeTokens, ValideToken(Token(idToken))).mapTo[SituacaoToken]
    val futValideAssento = ask(gerenciadorDeReservas, VerifiqueAssento(assento)).mapTo[SituacaoAssento]

    val futSitTokenSitAssento = for {
      sitToken <- futValideToken
      sitAssento <- futValideAssento
    } yield (sitToken, sitAssento)

    val futureOptCodigoErro = futSitTokenSitAssento map (sitToken_sitAssento => sitToken_sitAssento match {
      case (TokenInvalido(_), AssentoInexistente(_)) => Some(0)
      case (TokenInvalido(_), _) => Some(1)
      case (_, AssentoInexistente(_)) => Some(2)
      case _ => None
    })

    val futureCodFinal = futureOptCodigoErro flatMap (optCodigo => optCodigo match {
      case Some(codigoErro) => Future.successful(codigoErro)
      case None => {
        val futSituacaoReserva = ask(gerenciadorDeReservas, LibereReserva(Token(idToken), assento)).mapTo[SituacaoReserva]
        futSituacaoReserva.map(situacao => situacao match {
          case ReservaLiberada(_) => 3
          case ReservaInexistente(_) => 4
          case ReservaDeOutroUsuario(_) => 5
        })
      }
    })

    futureCodFinal map (codigo => gereResposta(codigo, tabelaMsgsLiberarReserva))
  }

  // o usuário solicitou que fosse verificada a situação de um assento
  def verifiqueAssento(assento: Int) = Action.async {
    // a variável abaixo conterá, em algum momento no futuro, a resposta enviada pelo ator gerenciadordeReservas
    val futureSituacao = ask(gerenciadorDeReservas, VerifiqueAssento(assento)).mapTo[SituacaoAssento]

    // quando a resposta chegar, analise-a para decidir qual objeto JSON deve ser enviado como resposta HTTP ao browser.
    val futureCodigo = futureSituacao.map(situacao => situacao match {
      case AssentoJaReservado(_) => 0
      case AssentoDisponivel(_) => 1
      case AssentoInexistente(_) => 2
    })

    futureCodigo map (codigo => gereResposta(codigo, tabelaMsgsSituacaoAssento))
  }

  // o usuário solicitou todas as reservas
  def getReservas = Action.async {

    // o método m converte, recursivamente, uma lista de Reserva em uma lista de objetos JSON
    def m(l: List[Reserva]): List[JsValue] = l match {
      // caso a lisa seja vazia então retorne uma lista vazia
      case List() => List()
      // caso o primeiro dado da lista for uma reserva sem token (None) então o primeiro dado da lista resultante será um objeto JSON com id igual a zero.
      // o resto da lista será convertida aplicando-se a função m
      case Reserva(assento, None) :: resto => Json.obj("assento" -> assento.toString, "id" -> "0") :: m(resto)
      // caso o primerio dado da lista for uma reserva com token então o primeiro dado da lista resultante será um objeto JSON com os dados da reserva.
      // o resto da lista será convertida aplicando-se a função m
      case Reserva(assento, Some(Token(id))) :: resto => Json.obj("assento" -> assento.toString, "id" -> id.toString) :: m(resto)
    }

    // a variável abaixo conterá, em algum momento no futuro, a resposta enviada pelo ator gerenciadordeReservas
    val futReservas = ask(gerenciadorDeReservas, EnvieReservas).mapTo[RecebaReservas]

    // quando a variável futReservas contiver a resposta enviada pelo ator então retorne o objeto JSON com as reservas
    futReservas.map(r => Ok(Json.obj("reservas" -> m(r.reservas))))
  }
}