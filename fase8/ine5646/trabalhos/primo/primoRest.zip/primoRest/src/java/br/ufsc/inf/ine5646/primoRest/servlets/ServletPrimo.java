package br.ufsc.inf.ine5646.primoRest.servlets;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.WebResource;
import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.Type;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.UriBuilder;

public class ServletPrimo extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest requisicao, HttpServletResponse resposta) throws ServletException, IOException {
        resposta.setContentType("text/html;charset=utf-8");
        PrintWriter saida = resposta.getWriter();
        String numero = requisicao.getParameter("numero");
        String servidor = requisicao.getParameter("servidor");
        Integer porta = Integer.parseInt(requisicao.getParameter("porta"));
        String servico = requisicao.getParameter("servico");
        String clienteDivisores = UriBuilder.fromUri(servico)
                .scheme("http")
                .host(servidor)
                .port(porta)
                .path(numero)
                .build().toString();
        Client cliente = Client.create();
        WebResource recurso = cliente.resource(clienteDivisores);
        String divisoresJson = recurso.get(String.class);
        Gson conversor = new Gson();
        Type tipo = new TypeToken<List<Integer>>(){}.getType();
        List<Integer> divisores = conversor.fromJson(divisoresJson, tipo);
        Boolean primo = (divisores.size() == 2);
        String primoOuNaoPrimo = (primo) ? "o número é primo" : "o número não é primo";
        try {
            saida.println("<!DOCTYPE html>");
            saida.println("<html lang=\"pt-br\">");
            saida.println("<head>");
            saida.println("<meta charset=\"utf-8\" />");
            saida.println("<title>Primo</title>");
            saida.println("<style type=\"text/css\">h1, h2 { font-family: sans-serif; font-weight: normal; } strong { color: #C34; }</style>");
            saida.println("</head>");
            saida.println("<body>");
            saida.println("<h1>Número: <strong>" + numero + "</strong></h1>");
            saida.println("<h2>Cliente divisores: <strong>" + clienteDivisores + "</strong></h2>");
            saida.println("<h2>Divisores: <strong>" + divisoresJson + "</strong></h2>");
            saida.println("<h1>Resposta: <strong>" + primoOuNaoPrimo + "</strong></h1>");
            saida.println("</body>");
            saida.println("</html>");
        } finally {            
            saida.close();
        }
    }
}
