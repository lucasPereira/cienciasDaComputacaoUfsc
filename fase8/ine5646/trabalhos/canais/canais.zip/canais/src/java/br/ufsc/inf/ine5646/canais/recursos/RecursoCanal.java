package br.ufsc.inf.ine5646.canais.recursos;

import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/canal/{identificador}")
public class RecursoCanal {
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String fornecerJson(@PathParam("identificador") String identificadorDoCanal) {
        String servico = "http://tvcabobd.leandro.komosinski.vms.ufsc.br:9000/canal/" + identificadorDoCanal;
        Client cliente = ClientBuilder.newClient();
        Response resposta = cliente.target(servico).request().get();
        String canal = resposta.readEntity(String.class);
        return canal;
    }
}
