package br.ufsc.inf.ine5646.canais;

import br.ufsc.inf.ine5646.canais.recursos.RecursoCanal;
import br.ufsc.inf.ine5646.canais.recursos.RecursoRaiz;
import java.util.Set;
import javax.ws.rs.core.Application;

@javax.ws.rs.ApplicationPath("/*")
public class Canais extends Application {
    @Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> resources = new java.util.HashSet<Class<?>>();
        resources.add(RecursoRaiz.class);
        resources.add(RecursoCanal.class);
        return resources;
    }
}
