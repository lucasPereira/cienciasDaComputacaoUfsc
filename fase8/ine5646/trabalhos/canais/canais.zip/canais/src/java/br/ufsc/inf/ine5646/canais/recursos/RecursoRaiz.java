package br.ufsc.inf.ine5646.canais.recursos;

import java.net.URI;
import javax.ws.rs.PathParam;
import javax.ws.rs.Path;
import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

@Path("/")
public class RecursoRaiz {
    @Context
    UriInfo informacaoDeUri;
    
    @GET
    @Produces(MediaType.TEXT_HTML)
    public Response fornecerJson(@PathParam("identificador") String identificadorDoCanal) {
        URI redirecionamento = informacaoDeUri.getBaseUriBuilder().path("index.jsp").build();
        return Response.seeOther(redirecionamento).build();
    }
}
